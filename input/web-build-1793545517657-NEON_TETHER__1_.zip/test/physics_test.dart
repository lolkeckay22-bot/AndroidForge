import 'dart:math';
import 'package:flutter_test/flutter_test.dart';
import 'package:neon_tether/arena/rope_node.dart';
import 'package:neon_tether/core/constants.dart';
import 'package:neon_tether/physics/geometry.dart';
import 'package:neon_tether/physics/pendulum.dart';
import 'package:neon_tether/player/player.dart';

void main() {
  test('rope never stretches beyond its length', () {
    final p = Player()..x = 200..y = 0;
    p.node = RopeNode(0, 0, 0, NodeKind.normal);
    p.len = 200;
    for (var i = 0; i < 1200; i++) {
      Pendulum.integrate(p, K.step);
      final d = sqrt(p.x * p.x + p.y * p.y);
      expect(d, lessThanOrEqualTo(200.5));
    }
  });

  test('swing keeps most of its energy (inertia)', () {
    final p = Player()..x = 150..y = 100;
    final n = RopeNode(0, 0, 0, NodeKind.normal);
    p.node = n;
    p.len = sqrt(150 * 150 + 100 * 100);
    var maxSpeed = 0.0;
    for (var i = 0; i < 480; i++) {
      Pendulum.integrate(p, K.step);
      maxSpeed = max(maxSpeed, p.speed);
    }
    expect(maxSpeed, greaterThan(300));
  });

  test('speed is kept after release', () {
    final p = Player()..x = 0..y = 0..vx = 400..vy = 0;
    for (var i = 0; i < 60; i++) {
      Pendulum.integrate(p, K.step);
    }
    expect(p.vx, greaterThan(350));
  });

  test('reeling in raises tangential speed', () {
    final p = Player()..x = 200..y = 0..vy = 300;
    p.node = RopeNode(0, 0, 0, NodeKind.normal);
    p.len = 200;
    final before = p.speed;
    for (var i = 0; i < 60; i++) {
      Pendulum.reel(p, 100, K.step);
      Pendulum.integrate(p, K.step);
    }
    expect(p.len, lessThan(200));
    expect(p.speed, greaterThan(before * 0.9));
  });

  test('segment crossing detects and misses correctly', () {
    expect(Geo.segHit(0, 0, 10, 0, 5, -5, 5, 5), closeTo(0.5, 1e-6));
    expect(Geo.segHit(0, 0, 10, 0, 20, -5, 20, 5), -1);
    expect(Geo.segHit(0, 0, 0, 0, 5, -5, 5, 5), -1);
  });
}
