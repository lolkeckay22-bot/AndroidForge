package com.neontether.game

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
