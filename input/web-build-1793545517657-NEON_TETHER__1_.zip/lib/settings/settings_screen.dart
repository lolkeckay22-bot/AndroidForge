import 'package:flutter/material.dart';
import '../audio/audio_service.dart';
import '../core/constants.dart';
import '../ui/menu_scaffold.dart';
import '../ui/neon_widgets.dart';
import 'settings.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = GameSettings.I;
    return MenuScaffold(
      title: 'SETTINGS',
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 680),
          child: AnimatedBuilder(
            animation: s,
            builder: (_, __) => SingleChildScrollView(
              padding: const EdgeInsets.all(14),
              child: NeonPanel(
                child: Column(children: [
                  _row('MUSIC', NeonToggle(value: s.music, onChanged: (v) {
                    s.setMusic(v);
                    AudioService.applySettings();
                  })),
                  _row('SOUND EFFECTS', NeonToggle(value: s.sfx, color: Pal.pink, onChanged: s.setSfx)),
                  _row('VOLUME', Expanded(child: NeonSlider(value: s.volume, onChanged: (v) {
                    s.setVolume(v);
                  }, color: Pal.cyan)), expand: true),
                  _row('CONTROL SENSITIVITY', Expanded(child: NeonSlider(value: s.sensitivity, color: Pal.pink, onChanged: s.setSensitivity)), expand: true),
                  Padding(
                    padding: const EdgeInsets.only(top: 4, bottom: 10),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text('Higher = bigger tap-assist radius and stronger reel-in.',
                          style: neonStyle(11, al(Pal.white, 0.45), glow: 0, spacing: 0.5, w: FontWeight.w400)),
                    ),
                  ),
                  _row('EFFECTS QUALITY', Wrap(spacing: 8, children: [
                    for (final e in const [(0, 'LOW'), (1, 'MED'), (2, 'HIGH'), (3, 'AUTO')])
                      NeonChip(label: e.$2, selected: s.quality == e.$1, onTap: () => s.setQuality(e.$1)),
                  ])),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _row(String label, Widget control, {bool expand = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [
          SizedBox(width: 210, child: Text(label, style: neonStyle(14, al(Pal.white, 0.85), glow: 0, spacing: 2))),
          if (expand) control else Expanded(child: Align(alignment: Alignment.centerRight, child: control)),
        ]),
      );
}
