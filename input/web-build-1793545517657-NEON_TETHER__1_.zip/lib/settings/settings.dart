import 'package:flutter/foundation.dart';
import '../save/save_system.dart';

/// 0 low, 1 medium, 2 high, 3 auto
class GameSettings extends ChangeNotifier {
  GameSettings._();
  static final GameSettings I = GameSettings._();

  bool music = true;
  bool sfx = true;
  double volume = 0.8;
  int quality = 3;
  double sensitivity = 0.5; // tap-assist radius + reel strength

  void load() {
    music = SaveSystem.getBool('s_music', true);
    sfx = SaveSystem.getBool('s_sfx', true);
    volume = SaveSystem.getDouble('s_volume', 0.8);
    quality = SaveSystem.getInt('s_quality', 3);
    sensitivity = SaveSystem.getDouble('s_sens', 0.5);
  }

  void _save() {
    SaveSystem.setBool('s_music', music);
    SaveSystem.setBool('s_sfx', sfx);
    SaveSystem.setDouble('s_volume', volume);
    SaveSystem.setInt('s_quality', quality);
    SaveSystem.setDouble('s_sens', sensitivity);
    notifyListeners();
  }

  void setMusic(bool v) { music = v; _save(); }
  void setSfx(bool v) { sfx = v; _save(); }
  void setVolume(double v) { volume = v; _save(); }
  void setQuality(int v) { quality = v; _save(); }
  void setSensitivity(double v) { sensitivity = v; _save(); }
}
