import 'dart:ui';
import '../core/constants.dart';
import '../save/save_system.dart';
import '../statistics/statistics.dart';

class Skin {
  final String name;
  final Color color;
  final Color trail;
  final int needSwings;
  const Skin(this.name, this.color, this.trail, this.needSwings);
}

class Skins {
  static const list = <Skin>[
    Skin('CYAN', Pal.cyan, Pal.cyan, 0),
    Skin('MAGENTA', Pal.pink, Pal.pink, 50),
    Skin('VIOLET', Pal.purple, Pal.cyan, 200),
    Skin('SOLAR', Pal.gold, Pal.red, 500),
    Skin('GHOST', Pal.white, Pal.purple, 1000),
  ];

  static int get selected => SaveSystem.getInt('skin_sel');
  static void select(int i) => SaveSystem.setInt('skin_sel', i);
  static Skin get current => list[selected.clamp(0, list.length - 1)];

  static bool unlocked(int i) =>
      i == 0 || (SaveSystem.getInt('skin_mask') >> i) & 1 == 1 ||
      Statistics.swings >= list[i].needSwings;

  /// Persist unlocks (call after stats update).
  static void refreshUnlocks() {
    var mask = SaveSystem.getInt('skin_mask');
    for (var i = 0; i < list.length; i++) {
      if (Statistics.swings >= list[i].needSwings) mask |= 1 << i;
    }
    SaveSystem.setInt('skin_mask', mask);
  }
}
