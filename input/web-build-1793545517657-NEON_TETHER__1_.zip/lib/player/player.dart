import 'dart:math';
import 'dart:typed_data';
import '../arena/rope_node.dart';

class Player {
  double x = 0, y = 0, vx = 0, vy = 0;
  RopeNode? node;
  double len = 0;
  double invuln = 0;

  // trail ring buffer (x,y pairs)
  static const int trailCap = 32;
  final Float32List trail = Float32List(trailCap * 2);
  int trailHead = 0;
  int trailCount = 0;

  void pushTrail() {
    trail[trailHead * 2] = x;
    trail[trailHead * 2 + 1] = y;
    trailHead = (trailHead + 1) % trailCap;
    if (trailCount < trailCap) trailCount++;
  }

  void clearTrail() {
    trailCount = 0;
    trailHead = 0;
  }

  double get speed => sqrt(vx * vx + vy * vy);
}
