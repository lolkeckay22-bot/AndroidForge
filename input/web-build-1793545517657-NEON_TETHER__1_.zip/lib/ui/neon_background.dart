import 'dart:math';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../core/constants.dart';

/// Animated menu background: drifting glowing nodes joined by thin lines.
class NeonBackground extends StatefulWidget {
  const NeonBackground({super.key, required this.child});
  final Widget child;
  @override
  State<NeonBackground> createState() => _NeonBackgroundState();
}

class _NeonBackgroundState extends State<NeonBackground> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 60))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Positioned.fill(
        child: RepaintBoundary(
          child: CustomPaint(painter: _BgPainter(_c)),
        ),
      ),
      Positioned.fill(child: widget.child),
    ]);
  }
}

class _BgPainter extends CustomPainter {
  _BgPainter(this.anim) : super(repaint: anim);
  final Animation<double> anim;
  static const int n = 34;
  static final List<List<double>> _pts = () {
    final r = Random(7);
    return List.generate(n, (_) => [r.nextDouble(), r.nextDouble(), 0.3 + r.nextDouble(), r.nextDouble()]);
  }();
  final Paint _p = Paint();
  final Paint _l = Paint()..style = PaintingStyle.stroke..strokeWidth = 1;
  static const cols = [Pal.cyan, Pal.pink, Pal.purple];

  @override
  void paint(Canvas canvas, Size size) {
    _p.shader = ui.Gradient.linear(Offset.zero, Offset(0, size.height), [Pal.bg2, Pal.bg]);
    canvas.drawRect(Offset.zero & size, _p);
    _p.shader = null;
    final t = anim.value * 60;
    final xs = List<double>.filled(n, 0), ys = List<double>.filled(n, 0);
    for (var i = 0; i < n; i++) {
      final d = _pts[i][2];
      xs[i] = ((_pts[i][0] * size.width + t * 14 * d) % (size.width + 40)) - 20;
      ys[i] = _pts[i][1] * size.height + sin(t * 0.6 * d + i) * 16;
    }
    final maxD = size.width * 0.17;
    for (var i = 0; i < n; i++) {
      for (var j = i + 1; j < n; j++) {
        final dx = xs[i] - xs[j], dy = ys[i] - ys[j];
        final d2 = dx * dx + dy * dy;
        if (d2 < maxD * maxD) {
          final f = 1 - sqrt(d2) / maxD;
          _l.color = al(Pal.cyan, 0.22 * f);
          canvas.drawLine(Offset(xs[i], ys[i]), Offset(xs[j], ys[j]), _l);
        }
      }
    }
    for (var i = 0; i < n; i++) {
      final c = cols[(_pts[i][3] * 3).floor() % 3];
      final r = 2 + _pts[i][2] * 3;
      _p.color = al(c, 0.12);
      canvas.drawCircle(Offset(xs[i], ys[i]), r * 3.2, _p);
      _p.color = al(c, 0.9);
      canvas.drawCircle(Offset(xs[i], ys[i]), r, _p);
    }
  }

  @override
  bool shouldRepaint(covariant _BgPainter old) => false;
}
