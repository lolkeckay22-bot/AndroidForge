import 'package:flutter/material.dart';
import '../core/constants.dart';
import 'neon_background.dart';
import 'neon_widgets.dart';

Route<T> fadeRoute<T>(Widget page) => PageRouteBuilder<T>(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 220),
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
    );

class MenuScaffold extends StatelessWidget {
  const MenuScaffold({super.key, required this.title, required this.child, this.showBack = true});
  final String title;
  final Widget child;
  final bool showBack;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pal.bg,
      body: NeonBackground(
        child: SafeArea(
          child: Stack(children: [
            Positioned.fill(
              child: Padding(
                padding: const EdgeInsets.only(top: 56),
                child: child,
              ),
            ),
            Positioned(
              top: 8,
              left: 12,
              right: 12,
              child: Row(children: [
                if (showBack)
                  NeonButton(
                    label: '',
                    icon: Icons.arrow_back_ios_new_rounded,
                    width: 52,
                    height: 44,
                    onTap: () => Navigator.of(context).maybePop(),
                  ),
                const SizedBox(width: 16),
                Text(title, style: neonStyle(22, Pal.cyan, spacing: 6)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
