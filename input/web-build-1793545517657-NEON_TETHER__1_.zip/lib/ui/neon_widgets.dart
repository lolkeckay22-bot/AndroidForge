import 'package:flutter/material.dart';
import '../core/constants.dart';

TextStyle neonStyle(double size, Color c, {double spacing = 3, FontWeight w = FontWeight.w700, double glow = 12}) =>
    TextStyle(
      fontSize: size,
      color: c,
      fontWeight: w,
      letterSpacing: spacing,
      decoration: TextDecoration.none,
      shadows: glow > 0 ? [Shadow(color: al(c, 0.8), blurRadius: glow)] : null,
    );

class NeonButton extends StatefulWidget {
  const NeonButton({
    super.key,
    required this.label,
    required this.onTap,
    this.color = Pal.cyan,
    this.width = 240,
    this.height = 54,
    this.icon,
    this.filled = false,
    this.fontSize = 18,
  });
  final String label;
  final VoidCallback onTap;
  final Color color;
  final double width, height, fontSize;
  final IconData? icon;
  final bool filled;

  @override
  State<NeonButton> createState() => _NeonButtonState();
}

class _NeonButtonState extends State<NeonButton> {
  bool _down = false;
  @override
  Widget build(BuildContext context) {
    final c = widget.color;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) => setState(() => _down = false),
      onTapCancel: () => setState(() => _down = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _down ? 0.94 : 1,
        duration: const Duration(milliseconds: 90),
        child: Container(
          width: widget.width,
          height: widget.height,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: al(c, widget.filled || _down ? 0.28 : 0.07),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: c, width: 1.6),
            boxShadow: [BoxShadow(color: al(c, _down ? 0.7 : 0.4), blurRadius: _down ? 22 : 14)],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.icon != null) ...[
                Icon(widget.icon, color: c, size: widget.fontSize + 4),
                const SizedBox(width: 10),
              ],
              if (widget.label.isNotEmpty)
                Text(widget.label, style: neonStyle(widget.fontSize, Pal.white, glow: 8)),
            ],
          ),
        ),
      ),
    );
  }
}

class NeonToggle extends StatelessWidget {
  const NeonToggle({super.key, required this.value, required this.onChanged, this.color = Pal.cyan});
  final bool value;
  final ValueChanged<bool> onChanged;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => onChanged(!value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        width: 62,
        height: 32,
        padding: const EdgeInsets.all(3),
        alignment: value ? Alignment.centerRight : Alignment.centerLeft,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: al(color, value ? 0.25 : 0.05),
          border: Border.all(color: value ? color : al(Pal.white, 0.3), width: 1.5),
          boxShadow: value ? [BoxShadow(color: al(color, 0.4), blurRadius: 12)] : null,
        ),
        child: Container(
          width: 24,
          height: 24,
          decoration: BoxDecoration(shape: BoxShape.circle, color: value ? color : al(Pal.white, 0.4)),
        ),
      ),
    );
  }
}

class NeonChip extends StatelessWidget {
  const NeonChip({super.key, required this.label, required this.selected, required this.onTap, this.color = Pal.cyan});
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: al(color, selected ? 0.25 : 0.04),
          border: Border.all(color: selected ? color : al(Pal.white, 0.25), width: 1.4),
        ),
        child: Text(label, style: neonStyle(13, selected ? Pal.white : al(Pal.white, 0.6), glow: selected ? 6 : 0, spacing: 2)),
      ),
    );
  }
}

class NeonSlider extends StatelessWidget {
  const NeonSlider({super.key, required this.value, required this.onChanged, this.color = Pal.cyan});
  final double value;
  final ValueChanged<double> onChanged;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return SliderTheme(
      data: SliderThemeData(
        trackHeight: 3,
        activeTrackColor: color,
        inactiveTrackColor: al(Pal.white, 0.2),
        thumbColor: color,
        overlayColor: al(color, 0.2),
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 9),
      ),
      child: Slider(value: value.clamp(0.0, 1.0), onChanged: onChanged),
    );
  }
}

/// Panel with neon border.
class NeonPanel extends StatelessWidget {
  const NeonPanel({super.key, required this.child, this.color = Pal.cyan, this.padding = const EdgeInsets.all(18)});
  final Widget child;
  final Color color;
  final EdgeInsets padding;
  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
          color: al(Pal.bg, 0.82),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: al(color, 0.8), width: 1.4),
          boxShadow: [BoxShadow(color: al(color, 0.25), blurRadius: 20)],
        ),
        child: child,
      );
}
