import 'hazard.dart';

/// Glowing line between two enemies. Crossing it scores; it recharges after [cool].
class EnemyLink {
  EnemyLink(this.a, this.b);
  final Hazard a, b;
  double cool = 0;
  double flash = 0;
}
