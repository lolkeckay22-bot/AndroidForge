import 'dart:math';

/// Enemy / mine. Sine-patrol (amp>0), free drift (vx,vy) or static.
class Hazard {
  Hazard(this.x, this.baseY, this.r,
      {this.amp = 0, this.speed = 0, this.phase = 0, this.vx = 0, this.vy = 0})
      : y = baseY,
        drifting = vx != 0 || vy != 0;
  double x;
  final double baseY, r, amp, speed, phase;
  double y, vx, vy;
  final bool drifting;
  double spin = 0;

  bool get moving => amp > 0 || drifting;

  void update(double t, double dt) {
    spin += dt * 2.2;
    if (amp > 0) y = baseY + amp * sin(speed * t + phase);
  }

  /// Free drift with bouncing off the arena bounds.
  void drift(double dt, double minX, double maxX, double minY, double maxY) {
    x += vx * dt;
    y += vy * dt;
    if (x < minX + r) { x = minX + r; vx = vx.abs(); }
    if (x > maxX - r) { x = maxX - r; vx = -vx.abs(); }
    if (y < minY + r) { y = minY + r; vy = vy.abs(); }
    if (y > maxY - r) { y = maxY - r; vy = -vy.abs(); }
  }
}
