import 'package:shared_preferences/shared_preferences.dart';

/// Thin persistent key/value layer (survives app restarts & reboots).
class SaveSystem {
  static SharedPreferences? _p;

  static Future<void> init() async {
    _p = await SharedPreferences.getInstance();
  }

  static int getInt(String k, [int d = 0]) => _p?.getInt(k) ?? d;
  static double getDouble(String k, [double d = 0]) => _p?.getDouble(k) ?? d;
  static bool getBool(String k, [bool d = false]) => _p?.getBool(k) ?? d;

  static void setInt(String k, int v) => _p?.setInt(k, v);
  static void setDouble(String k, double v) => _p?.setDouble(k, v);
  static void setBool(String k, bool v) => _p?.setBool(k, v);
}
