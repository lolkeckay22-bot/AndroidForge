import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../core/game_mode.dart';
import '../ui/menu_scaffold.dart';
import '../ui/neon_widgets.dart';
import 'statistics.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final t = Statistics.playSeconds;
    final rows = <(String, String, Color)>[
      ('RUNS PLAYED', '${Statistics.games}', Pal.cyan),
      ('TIME PLAYED', '${t ~/ 3600}h ${(t % 3600) ~/ 60}m', Pal.cyan),
      ('TOTAL SWINGS', '${Statistics.swings}', Pal.pink),
      ('DISTANCE', '${Statistics.distance} m', Pal.pink),
      ('LIVES LOST', '${Statistics.deaths}', Pal.red),
      for (final m in GameMode.values) ('BEST ${m.title}', '${Statistics.best(m)}', m.color),
    ];
    return MenuScaffold(
      title: 'STATISTICS',
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(14),
            child: NeonPanel(
              child: Column(children: [
                for (final r in rows)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 7),
                    child: Row(children: [
                      Expanded(child: Text(r.$1, style: neonStyle(14, al(Pal.white, 0.7), glow: 0, spacing: 2))),
                      Text(r.$2, style: neonStyle(20, r.$3, spacing: 1)),
                    ]),
                  ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
