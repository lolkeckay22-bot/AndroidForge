import '../core/game_mode.dart';
import '../save/save_system.dart';

class Statistics {
  static int get games => SaveSystem.getInt('st_games');
  static int get swings => SaveSystem.getInt('st_swings');
  static int get deaths => SaveSystem.getInt('st_deaths');
  static int get playSeconds => SaveSystem.getInt('st_time');
  static int get distance => SaveSystem.getInt('st_dist');
  static int best(GameMode m) => SaveSystem.getInt('best_${m.name}');

  /// Returns true if a new record was set.
  static bool recordRun({
    required GameMode mode,
    required int score,
    required double seconds,
    required double distanceUnits,
    required int swingCount,
    required int deathCount,
  }) {
    SaveSystem.setInt('st_games', games + 1);
    SaveSystem.setInt('st_swings', swings + swingCount);
    SaveSystem.setInt('st_deaths', deaths + deathCount);
    SaveSystem.setInt('st_time', playSeconds + seconds.round());
    SaveSystem.setInt('st_dist', distance + (distanceUnits / 10).round());
    if (score > best(mode)) {
      SaveSystem.setInt('best_${mode.name}', score);
      return true;
    }
    return false;
  }
}
