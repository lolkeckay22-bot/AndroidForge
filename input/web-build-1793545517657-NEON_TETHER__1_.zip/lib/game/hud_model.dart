import 'package:flutter/foundation.dart';

enum Phase { ready, playing, dying, over }

/// Low-frequency model the Flutter HUD listens to (updated ~10 Hz, not per frame).
class HudModel extends ChangeNotifier {
  int score = 0;
  int lives = 3;
  int maxLives = 3;
  double seconds = 0;
  double ropeFrac = 0; // 0..1 how much rope is out
  bool attached = false;
  Phase phase = Phase.ready;
  int stage = 1;
  int stageLines = 0;
  int stageTarget = 4;
  String banner = '';

  void push() => notifyListeners();
}
