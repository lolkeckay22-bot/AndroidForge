import 'dart:math';
import 'dart:ui';

import '../arena/rope_node.dart';
import '../core/constants.dart';
import '../core/game_mode.dart';
import '../player/player.dart';
import 'hud_model.dart';
import 'neon_game.dart';

/// All Canvas drawing. Reuses Paint/Path objects; no per-frame heavy allocation.
class GameRenderer {
  final Paint _fill = Paint();
  final Paint _line = Paint()
    ..style = PaintingStyle.stroke
    ..strokeCap = StrokeCap.round;
  final Path _path = Path();
  Shader? _bgShader;
  double _bgH = 0;

  void draw(Canvas c, NeonGame g) {
    final w = g.size.x, h = g.size.y;
    if (_bgShader == null || _bgH != h) {
      _bgH = h;
      _bgShader = Gradient.linear(Offset.zero, Offset(0, h), [Pal.bg2, Pal.bg]);
    }
    _fill
      ..shader = _bgShader
      ..style = PaintingStyle.fill;
    c.drawRect(Rect.fromLTWH(0, 0, w, h), _fill);
    _fill.shader = null;

    _background(c, g, w, h);

    final s = g.pxScale;
    c.save();
    c.scale(s);
    c.translate(-g.camLeft + g.shakeX, g.shakeY);
    _world(c, g);
    c.restore();
  }

  // ---------------- background ----------------
  void _background(Canvas c, NeonGame g, double w, double h) {
    final s = g.pxScale;
    // parallax grid
    final step = 90 * s;
    _line
      ..strokeWidth = 1
      ..color = al(Pal.cyan, 0.05);
    final off = -((g.camLeft * 0.35 * s) % step);
    for (double x = off; x < w; x += step) {
      c.drawLine(Offset(x, 0), Offset(x, h), _line);
    }
    for (double y = 0; y < h; y += step) {
      c.drawLine(Offset(0, y), Offset(w, y), _line);
    }
    // stars
    final n = g.quality.stars;
    _fill.style = PaintingStyle.fill;
    for (var i = 0; i < n; i++) {
      final d = g.stars[i * 3 + 2];
      var x = (g.stars[i * 3] * w - g.camLeft * 0.12 * d * s) % w;
      if (x < 0) x += w;
      final y = g.stars[i * 3 + 1] * h;
      _fill.color = al(Pal.white, 0.15 + 0.35 * d);
      c.drawCircle(Offset(x, y), 0.8 + d * 1.1, _fill);
    }
  }

  // ---------------- glow helpers ----------------
  void _glowCircle(Canvas c, double x, double y, double r, Color col, int layers,
      {double intensity = 1, bool core = true}) {
    _fill.style = PaintingStyle.fill;
    for (var i = layers; i >= 1; i--) {
      _fill.color = al(col, 0.11 * intensity / (i * 0.8));
      c.drawCircle(Offset(x, y), r * (1 + i * 0.85), _fill);
    }
    if (core) {
      _fill.color = al(col, 0.95 * intensity.clamp(0.0, 1.0));
      c.drawCircle(Offset(x, y), r, _fill);
      _fill.color = al(Pal.white, 0.9 * intensity.clamp(0.0, 1.0));
      c.drawCircle(Offset(x, y), r * 0.42, _fill);
    }
  }

  void _glowLine(Canvas c, Offset a, Offset b, Color col, int layers, double width, {double alpha = 1}) {
    _line.style = PaintingStyle.stroke;
    for (var i = layers - 1; i >= 1; i--) {
      _line
        ..strokeWidth = width * (1 + i * 2.2)
        ..color = al(col, 0.10 * alpha);
      c.drawLine(a, b, _line);
    }
    _line
      ..strokeWidth = width
      ..color = al(col, 0.9 * alpha);
    c.drawLine(a, b, _line);
  }

  // ---------------- world ----------------
  void _world(Canvas c, NeonGame g) {
    final q = g.quality;
    final layers = q.glowLayers;
    final left = g.camLeft - 60;
    final right = g.camLeft + g.viewW + 60;
    final arena = g.arena;
    final pl = g.pl;

    // floor
    if (arena.bounded) {
      _glowLine(c, Offset(left, K.floorY), Offset(right, K.floorY), Pal.cyan, layers, 2, alpha: 0.6);
    } else {
      _fill
        ..style = PaintingStyle.fill
        ..color = al(Pal.red, 0.16);
      c.drawRect(Rect.fromLTRB(left, K.floorY, right, K.viewH + 40), _fill);
      _glowLine(c, Offset(left, K.floorY), Offset(right, K.floorY), Pal.red, layers, 2.5);
    }
    // arena walls
    if (arena.bounded) {
      _glowLine(c, Offset(arena.minX, -20), Offset(arena.minX, K.viewH + 20), Pal.cyan, layers, 2, alpha: 0.7);
      _glowLine(c, Offset(arena.maxX, -20), Offset(arena.maxX, K.viewH + 20), Pal.cyan, layers, 2, alpha: 0.7);
      _glowLine(c, Offset(arena.minX, 0), Offset(arena.maxX, 0), Pal.cyan, layers, 2, alpha: 0.35);
    } else {
      // chaser wall
      _fill
        ..style = PaintingStyle.fill
        ..color = al(Pal.red, 0.13);
      c.drawRect(Rect.fromLTRB(left - 400, -20, g.chaserX, K.viewH + 40), _fill);
      _glowLine(c, Offset(g.chaserX, -20), Offset(g.chaserX, K.viewH + 40), Pal.red, layers, 3);
    }

    // connecting thin lines
    _line
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = al(Pal.cyan, 0.12);
    for (final n in arena.nodes) {
      if (n.x < left - 300 || n.x > right) continue;
      final nx = n.next;
      if (nx != null) c.drawLine(Offset(n.x, n.y), Offset(nx.x, nx.y), _line);
    }

    // enemy lines
    final lineCol = g.lethal ? Pal.pink : Pal.purple;
    for (final l in arena.links) {
      if (max(l.a.x, l.b.x) < left || min(l.a.x, l.b.x) > right) continue;
      final a = Offset(l.a.x, l.a.y), b = Offset(l.b.x, l.b.y);
      if (l.cool <= 0) {
        _glowLine(c, a, b, lineCol, layers, 2.2);
      } else {
        _line
          ..strokeWidth = 1
          ..color = al(lineCol, 0.12);
        c.drawLine(a, b, _line);
      }
      if (l.flash > 0) {
        _glowLine(c, a, b, Pal.white, 2, 4, alpha: l.flash / 0.4);
      }
    }

    // enemies / hazards
    final enemyCol = g.lethal ? Pal.red : Pal.purple;
    for (final hz in arena.hazards) {
      if (hz.x < left || hz.x > right) continue;
      _drawHazard(c, hz.x, hz.y, hz.r, hz.spin, hz.moving, enemyCol);
    }

    // nodes
    for (final n in arena.nodes) {
      if (n.x < left || n.x > right) continue;
      _drawNode(c, g, n, layers);
    }

    // reach ring
    if (pl.node == null && g.runPhase == Phase.playing) {
      _line
        ..strokeWidth = 1
        ..color = al(Pal.white, 0.05);
      c.drawCircle(Offset(pl.x, pl.y), K.reach, _line);
    }

    // trail
    _drawTrail(c, g, pl);

    // rope
    final node = pl.node;
    if (node != null) _drawRope(c, pl, node, layers);

    // particles
    g.parts.render(c);

    // player
    if (g.runPhase != Phase.dying && g.runPhase != Phase.over) {
      final blink = pl.invuln > 0 && ((pl.invuln * 12).floor() % 2 == 0);
      if (!blink) {
        _glowCircle(c, pl.x, pl.y, K.playerR, g.skin.color, layers);
      }
    }
  }

  void _drawNode(Canvas c, NeonGame g, RopeNode n, int layers) {
    final col = n.kind.color;
    if (!n.active) {
      _line
        ..strokeWidth = 1
        ..color = al(col, 0.18);
      c.drawCircle(Offset(n.x, n.y), 8, _line);
      return;
    }
    final pl = g.pl;
    final dx = n.x - pl.x, dy = n.y - pl.y;
    final inReach = dx * dx + dy * dy <= K.reach * K.reach;
    final base = 7.0 + n.pulse * 4;
    final t = g.simT;
    final breathe = 1 + 0.08 * sin(t * 3 + n.id);
    _glowCircle(c, n.x, n.y, base * breathe, col, layers, intensity: inReach ? 1 : 0.55);
    if (inReach && identical(pl.node, n) == false) {
      _line
        ..strokeWidth = 1.2
        ..color = al(col, 0.35);
      c.drawCircle(Offset(n.x, n.y), 15 + 2 * sin(t * 4 + n.id), _line);
    }
    if (n.kind == NodeKind.danger) {
      _line
        ..strokeWidth = 2
        ..color = al(Pal.white, 0.9);
      c.drawLine(Offset(n.x - 4, n.y - 4), Offset(n.x + 4, n.y + 4), _line);
      c.drawLine(Offset(n.x - 4, n.y + 4), Offset(n.x + 4, n.y - 4), _line);
    }
    if (n.kind == NodeKind.fragile && n.holdT > 0) {
      final f = (n.holdT / 1.1).clamp(0.0, 1.0);
      _line
        ..strokeWidth = 2.5
        ..color = al(Pal.red, 0.4 + 0.6 * f);
      c.drawArc(Rect.fromCircle(center: Offset(n.x, n.y), radius: 14), -pi / 2, 2 * pi * f, false, _line);
    }
  }

  void _drawHazard(Canvas c, double x, double y, double r, double spin, bool drone, Color col) {
    _fill
      ..style = PaintingStyle.fill
      ..color = al(col, 0.16);
    c.drawCircle(Offset(x, y), r * 1.9, _fill);
    _fill.color = al(col, 0.35);
    c.drawCircle(Offset(x, y), r, _fill);
    _line
      ..strokeWidth = 2
      ..color = al(col, 0.95);
    c.drawCircle(Offset(x, y), r, _line);
    for (var i = 0; i < 6; i++) {
      final a = spin * (drone ? -1.6 : 1) + i * pi / 3;
      final ca = cos(a), sa = sin(a);
      c.drawLine(Offset(x + ca * r, y + sa * r), Offset(x + ca * r * 1.55, y + sa * r * 1.55), _line);
    }
    _fill.color = al(drone ? Pal.pink : Pal.white, 0.9);
    c.drawCircle(Offset(x, y), r * 0.3, _fill);
  }

  void _drawRope(Canvas c, Player pl, RopeNode n, int layers) {
    final dx = pl.x - n.x, dy = pl.y - n.y;
    final d = sqrt(dx * dx + dy * dy);
    final slack = pl.len - d;
    final col = n.kind.color;
    _line.style = PaintingStyle.stroke;
    _path.reset();
    _path.moveTo(n.x, n.y);
    if (slack > 3) {
      _path.quadraticBezierTo((n.x + pl.x) / 2, (n.y + pl.y) / 2 + slack * 0.6, pl.x, pl.y);
    } else {
      _path.lineTo(pl.x, pl.y);
    }
    for (var i = layers - 1; i >= 1; i--) {
      _line
        ..strokeWidth = 2 + i * 4.5
        ..color = al(col, 0.09);
      c.drawPath(_path, _line);
    }
    _line
      ..strokeWidth = 2.2
      ..color = al(col, 0.75);
    c.drawPath(_path, _line);
    _line
      ..strokeWidth = 0.9
      ..color = al(Pal.white, 0.95);
    c.drawPath(_path, _line);
  }

  void _drawTrail(Canvas c, NeonGame g, Player pl) {
    final cnt = min(pl.trailCount, g.quality.trailLen);
    if (cnt < 2) return;
    _line.style = PaintingStyle.stroke;
    var idx = (pl.trailHead - 1 + Player.trailCap) % Player.trailCap;
    var px = pl.x, py = pl.y;
    for (var i = 0; i < cnt; i++) {
      final tx = pl.trail[idx * 2], ty = pl.trail[idx * 2 + 1];
      final f = 1 - i / cnt;
      _line
        ..strokeWidth = 1 + 5.5 * f
        ..color = al(g.skin.trail, 0.65 * f * f);
      c.drawLine(Offset(px, py), Offset(tx, ty), _line);
      px = tx;
      py = ty;
      idx = (idx - 1 + Player.trailCap) % Player.trailCap;
    }
  }
}
