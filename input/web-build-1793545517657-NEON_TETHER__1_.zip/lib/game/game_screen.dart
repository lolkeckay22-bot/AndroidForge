import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../core/constants.dart';
import '../core/game_mode.dart';
import '../statistics/statistics.dart';
import '../ui/neon_widgets.dart';
import 'hud_model.dart';
import 'neon_game.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.mode});
  final GameMode mode;
  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with WidgetsBindingObserver {
  late final NeonGame game = NeonGame(widget.mode);
  bool _paused = false;
  bool _over = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    game.onGameOver = () {
      if (mounted) setState(() => _over = true);
    };
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    game.commitRun();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed && !_over) _pause();
  }

  void _pause() {
    if (_paused || _over) return;
    game.setHalted(true);
    if (mounted) setState(() => _paused = true);
  }

  void _resume() {
    game.setHalted(false);
    setState(() => _paused = false);
  }

  void _restart() {
    game.setHalted(false);
    game.begin();
    setState(() {
      _paused = false;
      _over = false;
    });
  }

  void _exit() {
    game.commitRun();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        if (_over) {
          _exit();
        } else if (_paused) {
          _resume();
        } else {
          _pause();
        }
      },
      child: Scaffold(
        backgroundColor: Pal.bg,
        body: Stack(children: [
          Positioned.fill(
            child: Listener(
              behavior: HitTestBehavior.opaque,
              onPointerDown: (e) => game.pointerDown(e.pointer, e.localPosition),
              onPointerUp: (e) => game.pointerUp(e.pointer),
              onPointerCancel: (e) => game.pointerUp(e.pointer),
              child: GameWidget(game: game),
            ),
          ),
          if (!_over) _Hud(game: game, onPause: _pause, onRestart: _restart, onExit: _exit),
          if (_paused) _pauseOverlay(),
          if (_over) _resultsOverlay(),
        ]),
      ),
    );
  }

  Widget _scrim(Widget child) => Positioned.fill(
        child: Container(
          color: al(Pal.bg, 0.78),
          alignment: Alignment.center,
          child: FittedBox(fit: BoxFit.scaleDown, child: child),
        ),
      );

  Widget _pauseOverlay() => _scrim(NeonPanel(
        padding: const EdgeInsets.all(26),
        child: SizedBox(
          width: 300,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('PAUSED', style: neonStyle(32, Pal.cyan, spacing: 8)),
            const SizedBox(height: 22),
            NeonButton(label: 'RESUME', icon: Icons.play_arrow_rounded, width: 280, filled: true, onTap: _resume),
            const SizedBox(height: 12),
            NeonButton(label: 'RESTART', icon: Icons.refresh_rounded, width: 280, color: Pal.pink, onTap: _restart),
            const SizedBox(height: 12),
            NeonButton(label: 'MENU', icon: Icons.home_rounded, width: 280, color: Pal.white, onTap: _exit),
          ]),
        ),
      ));

  Widget _resultsOverlay() {
    final m = widget.mode;
    final rec = game.lastRecord;
    final t = game.runT.round();
    return _scrim(NeonPanel(
      color: m.color,
      padding: const EdgeInsets.all(26),
      child: SizedBox(
        width: 420,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('RUN OVER', style: neonStyle(30, Pal.red, spacing: 8)),
          const SizedBox(height: 14),
          Text('${game.score}', style: neonStyle(64, Pal.white, glow: 22, spacing: 2)),
          Text(m.scoreLabel, style: neonStyle(13, al(Pal.white, 0.6), glow: 0, spacing: 4)),
          const SizedBox(height: 8),
          if (rec) Text('NEW RECORD!', style: neonStyle(18, Pal.gold, spacing: 4)),
          const SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _stat('TIME', '${t ~/ 60}:${(t % 60).toString().padLeft(2, '0')}'),
            _stat('BEST', '${Statistics.best(m)}'),
            _stat('SWINGS', '${game.swings}'),
          ]),
          const SizedBox(height: 22),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            NeonButton(label: 'RETRY', icon: Icons.refresh_rounded, width: 180, filled: true, color: m.color, onTap: _restart),
            const SizedBox(width: 14),
            NeonButton(label: 'MENU', icon: Icons.home_rounded, width: 150, color: Pal.white, onTap: _exit),
          ]),
        ]),
      ),
    ));
  }

  Widget _stat(String l, String v) => Column(children: [
        Text(l, style: neonStyle(11, al(Pal.white, 0.5), glow: 0, spacing: 3)),
        const SizedBox(height: 4),
        Text(v, style: neonStyle(20, Pal.cyan, spacing: 1)),
      ]);
}

class _Hud extends StatelessWidget {
  const _Hud({required this.game, required this.onPause, required this.onRestart, required this.onExit});
  final NeonGame game;
  final VoidCallback onPause, onRestart, onExit;

  @override
  Widget build(BuildContext context) {
    final m = game.mode;
    return SafeArea(
      child: Stack(children: [
        Positioned(
          top: 6,
          left: 12,
          child: IgnorePointer(
            child: AnimatedBuilder(
              animation: game.hud,
              builder: (_, __) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${game.hud.score}', style: neonStyle(34, Pal.white, glow: 14, spacing: 1)),
                Text(m.scoreLabel, style: neonStyle(11, al(Pal.white, 0.55), glow: 0, spacing: 4)),
                if (m == GameMode.survival) ...[
                  Text('STAGE ${game.hud.stage}   ${game.hud.stageLines}/${game.hud.stageTarget}',
                      style: neonStyle(12, Pal.gold, glow: 6, spacing: 3)),
                  const SizedBox(height: 6),
                  Row(children: [
                    for (var i = 0; i < game.hud.maxLives; i++)
                      Container(
                        margin: const EdgeInsets.only(right: 8),
                        width: 14,
                        height: 14,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: i < game.hud.lives ? Pal.red : al(Pal.white, 0.12),
                          boxShadow: i < game.hud.lives ? [BoxShadow(color: al(Pal.red, 0.8), blurRadius: 10)] : null,
                        ),
                      ),
                  ]),
                ],
              ]),
            ),
          ),
        ),
        Positioned(
          top: 10,
          left: 0,
          right: 0,
          child: IgnorePointer(
            child: AnimatedBuilder(
              animation: game.hud,
              builder: (_, __) {
                final t = game.hud.seconds.floor();
                return Column(children: [
                  Text('${t ~/ 60}:${(t % 60).toString().padLeft(2, '0')}',
                      style: neonStyle(22, Pal.cyan, spacing: 3)),
                  if (m == GameMode.cable || m == GameMode.freeplay)
                    Text(m == GameMode.cable ? 'NO DAMAGE' : 'FREEPLAY',
                        style: neonStyle(10, al(Pal.white, 0.4), glow: 0, spacing: 4)),
                  if (game.hud.banner.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 40),
                      child: Text(game.hud.banner, style: neonStyle(20, Pal.gold, spacing: 4)),
                    ),
                  if (game.hud.seconds < 6)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text('TAP = HOOK    RELEASE = LET GO',
                          style: neonStyle(12, al(Pal.white, 0.6), glow: 0, spacing: 3)),
                    ),
                ]);
              },
            ),
          ),
        ),
        Positioned(
          top: 6,
          right: 10,
          child: Row(children: [
            NeonButton(label: '', icon: Icons.refresh_rounded, width: 46, height: 42, color: Pal.pink, onTap: onRestart),
            const SizedBox(width: 8),
            NeonButton(label: '', icon: Icons.home_rounded, width: 46, height: 42, color: Pal.white, onTap: onExit),
            const SizedBox(width: 8),
            NeonButton(label: '', icon: Icons.pause_rounded, width: 46, height: 42, onTap: onPause),
          ]),
        ),
      ]),
    );
  }
}
