import 'dart:math';
import 'dart:typed_data';
import 'dart:ui';

import 'package:flame/game.dart';

import '../arena/arena.dart';
import '../arena/arena_generator.dart';
import '../arena/rope_node.dart';
import '../audio/audio_service.dart';
import '../core/constants.dart';
import '../core/game_mode.dart';
import '../effects/particles.dart';
import '../effects/quality.dart';
import '../physics/geometry.dart';
import '../physics/pendulum.dart';
import '../player/player.dart';
import '../player/skins.dart';
import '../settings/settings.dart';
import '../statistics/statistics.dart';
import 'hud_model.dart';
import 'renderer.dart';

class NeonGame extends FlameGame {
  NeonGame(this.mode);
  final GameMode mode;

  final HudModel hud = HudModel();
  final Arena arena = Arena();
  final Player pl = Player();
  final ParticleSystem parts = ParticleSystem();
  final Quality quality = Quality();
  final GameRenderer _renderer = GameRenderer();
  late ArenaGenerator gen;
  VoidCallback? onGameOver;

  // ---- view ----
  double pxScale = 1;
  double viewW = 1400;
  double camLeft = 0;
  double _camX = 0;
  double shake = 0;
  double shakeX = 0, shakeY = 0;
  final Float32List stars = Float32List(60 * 3);

  // ---- state ----
  bool halted = false;
  Phase runPhase = Phase.ready;
  final Set<int> _pointers = {};
  double _acc = 0;
  double simT = 0;
  double runT = 0;
  double _timeScale = 1;
  double _dyingT = 0;
  double _hudT = 0;
  double _cullT = 0;
  int _trailTick = 0;
  double chaserX = -420;
  double maxX = 0;
  double distance = 0;
  int swings = 0;
  int lives = 1;
  int lostLives = 0;
  int score = 0;
  int nodesHooked = 0;
  int _maxHookId = -1;
  int stage = 1, stageLines = 0, stageTarget = 4;
  double _bannerT = 0;
  bool get lethal => mode == GameMode.swing || mode == GameMode.survival;
  double difficulty = 0;
  bool _committed = false;
  bool lastRecord = false;
  final List<RopeNode> _broken = [];
  final Random _rng = Random();

  Skin skin = Skins.current;

  @override
  Color backgroundColor() => Pal.bg;

  @override
  Future<void> onLoad() async {
    for (var i = 0; i < 60; i++) {
      stars[i * 3] = _rng.nextDouble();
      stars[i * 3 + 1] = _rng.nextDouble();
      stars[i * 3 + 2] = 0.2 + _rng.nextDouble() * 0.8;
    }
    begin();
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    pxScale = size.y / K.viewH;
    viewW = size.x / pxScale;
  }

  // ================= lifecycle =================
  void begin() {
    arena.clear();
    parts.clear();
    _pointers.clear();
    _broken.clear();
    skin = Skins.current;
    gen = ArenaGenerator(mode, DateTime.now().millisecondsSinceEpoch & 0x7fffffff);
    pl
      ..node = null
      ..vx = 0
      ..vy = 0
      ..invuln = 0
      ..clearTrail();
    score = 0;
    swings = 0;
    nodesHooked = 0;
    _maxHookId = -1;
    lostLives = 0;
    runT = 0;
    simT = 0;
    _acc = 0;
    _timeScale = 1;
    _dyingT = 0;
    distance = 0;
    difficulty = 0;
    _committed = false;
    lastRecord = false;
    chaserX = -420;
    halted = false;
    lives = mode == GameMode.survival ? 3 : 1;
    stage = 1;
    stageLines = 0;
    stageTarget = 4;
    _bannerT = 0;
    hud.banner = '';
    if (mode != GameMode.swing) {
      gen.buildCableArena(arena);
      if (mode == GameMode.cable) _spawnEnemies(5, 40);
      if (mode == GameMode.survival) _spawnEnemies(5, 45);
      pl.x = 500;
      pl.y = 300;
      pl.vx = 60;
      pl.vy = -60;
    } else {
      gen.startTrack(arena);
      gen.extend(arena, 1500, 0);
      pl.x = 10;
      pl.y = 330;
      pl.vx = 170;
      pl.vy = -150;
    }
    maxX = pl.x;
    _camX = pl.x + 200;
    camLeft = _camX - viewW / 2;
    runPhase = Phase.playing;
    hud
      ..score = 0
      ..lives = lives
      ..maxLives = lives
      ..seconds = 0
      ..phase = Phase.playing
      ..attached = false
      ..ropeFrac = 0;
    hud.push();
  }

  void setHalted(bool v) {
    halted = v;
    if (v) {
      _pointers.clear();
      _release(sound: false);
      pauseEngine();
    } else {
      resumeEngine();
    }
  }

  /// Persist stats for the current run exactly once.
  void commitRun() {
    if (_committed) return;
    _committed = true;
    if (runT < 3 && score == 0) return;
    lastRecord = Statistics.recordRun(
      mode: mode,
      score: score,
      seconds: runT,
      distanceUnits: distance,
      swingCount: swings,
      deathCount: lostLives,
    );
    Skins.refreshUnlocks();
  }

  // ================= input =================
  void pointerDown(int id, Offset pos) {
    if (halted || runPhase != Phase.playing) return;
    _pointers.add(id);
    final wx = camLeft + pos.dx / pxScale;
    final wy = pos.dy / pxScale;
    _tryHook(wx, wy);
  }

  void pointerUp(int id) {
    _pointers.remove(id);
    if (_pointers.isEmpty) _release();
  }

  void _tryHook(double wx, double wy) {
    final sens = GameSettings.I.sensitivity;
    final tapR = 110 + 220 * sens;
    RopeNode? best;
    var bs = double.infinity;
    for (final n in arena.nodes) {
      if (!n.active || identical(n, pl.node)) continue;
      final px = n.x - pl.x, py = n.y - pl.y;
      final dp2 = px * px + py * py;
      if (dp2 > K.reach * K.reach) continue;
      final tx = n.x - wx, ty = n.y - wy;
      final dt2 = tx * tx + ty * ty;
      if (dt2 > tapR * tapR) continue;
      final s = dt2 + 0.12 * dp2;
      if (s < bs) {
        bs = s;
        best = n;
      }
    }
    if (best == null) {
      if (pl.node == null) {
        parts.ring(wx, wy, 6, 90, 0.35, Pal.red);
        AudioService.sfx('miss', vol: 0.6);
      }
      return;
    }
    _attach(best);
  }

  void _attach(RopeNode n) {
    final dx = pl.x - n.x, dy = pl.y - n.y;
    final d = sqrt(dx * dx + dy * dy);
    pl.node = n;
    pl.len = max(50.0, min(d, K.maxRope));
    n.holdT = 0;
    n.pulse = 1;
    swings++;
    final lim = quality.maxParticles;
    parts.burst(n.x, n.y, 10, n.kind.color, 150, 0.45, lim);
    parts.ring(n.x, n.y, 8, 140, 0.4, n.kind.color);
    AudioService.sfx('attach', vol: 0.8);

    if (n.kind == NodeKind.danger) {
      _hurt(fromNode: true);
      return;
    }
    if (n.id > _maxHookId) {
      _maxHookId = n.id;
      nodesHooked++;
    }
  }

  void _release({bool sound = true}) {
    if (pl.node == null) return;
    if (sound) {
      parts.burst(pl.x, pl.y, 6, skin.color, 110, 0.35, quality.maxParticles, size: 2);
      AudioService.sfx('release', vol: 0.6);
    }
    pl.node = null;
  }

  // ================= damage =================
  void _hurt({bool fromNode = false}) {
    if (pl.invuln > 0 || runPhase != Phase.playing) return;
    lostLives++;
    shake = 14;
    parts.burst(pl.x, pl.y, 26, Pal.red, 330, 0.7, quality.maxParticles, size: 3);
    parts.ring(pl.x, pl.y, 10, 260, 0.5, Pal.red);
    AudioService.sfx('hit');
    _release(sound: false);
    if (mode == GameMode.survival) {
      lives--;
      hud.lives = lives;
      if (lives <= 0) {
        _die();
        return;
      }
      pl.invuln = 2.0;
      if (!fromNode) pl.vy = min(pl.vy, -260);
    } else {
      _die();
    }
  }

  void _spawnEnemies(int count, double speed) {
    arena.hazards.clear();
    arena.links.clear();
    gen.buildEnemies(arena, count, speed, pl.x, pl.y);
  }

  void _crossLines(double ox, double oy) {
    for (final l in arena.links) {
      if (l.cool > 0) continue;
      final t = Geo.segHit(ox, oy, pl.x, pl.y, l.a.x, l.a.y, l.b.x, l.b.y);
      if (t < 0) continue;
      l.cool = 3.0;
      l.flash = 0.4;
      final ix = ox + (pl.x - ox) * t, iy = oy + (pl.y - oy) * t;
      parts.burst(ix, iy, 12, Pal.pink, 220, 0.5, quality.maxParticles);
      parts.ring(ix, iy, 6, 160, 0.45, Pal.pink);
      AudioService.sfx('pickup', vol: 0.7);
      score += 10;
      if (mode == GameMode.survival) {
        stageLines++;
        if (stageLines >= stageTarget) {
          _stageClear();
          return;
        }
      }
    }
  }

  void _stageClear() {
    stage++;
    lives = 3;
    hud.lives = 3;
    score += 50;
    stageLines = 0;
    stageTarget = min(14, 4 + stage * 2);
    pl.invuln = max(pl.invuln, 2.5);
    _spawnEnemies(min(12, 4 + stage), 45.0 + stage * 10);
    hud.banner = 'STAGE ${stage - 1} CLEAR  -  HEARTS RESTORED';
    _bannerT = 2.4;
    parts.ring(pl.x, pl.y, 10, 420, 0.8, Pal.gold);
    AudioService.sfx('pickup');
  }

  void _die() {
    runPhase = Phase.dying;
    _dyingT = 0;
    _timeScale = 0.35;
    _release(sound: false);
    shake = 18;
    parts.burst(pl.x, pl.y, 60, skin.color, 420, 1.0, quality.maxParticles, size: 3.2);
    parts.ring(pl.x, pl.y, 10, 380, 0.8, skin.color);
    AudioService.sfx('gameover');
    hud.phase = Phase.dying;
    hud.push();
  }

  void _finish() {
    runPhase = Phase.over;
    _timeScale = 1;
    commitRun();
    hud
      ..score = score
      ..phase = Phase.over;
    hud.push();
    onGameOver?.call();
  }

  // ================= loop =================
  @override
  void update(double dt) {
    super.update(dt);
    quality.sample(dt);
    if (halted) return;

    final rdt = dt.clamp(0.0, 0.05);
    parts.update(rdt);
    if (_bannerT > 0) {
      _bannerT -= rdt;
      if (_bannerT <= 0) hud.banner = '';
    }
    if (shake > 0) {
      shake = max(0, shake - 40 * rdt);
      shakeX = (_rng.nextDouble() * 2 - 1) * shake;
      shakeY = (_rng.nextDouble() * 2 - 1) * shake;
    } else {
      shakeX = shakeY = 0;
    }

    if (runPhase == Phase.dying) {
      _dyingT += rdt;
      if (_dyingT > 1.1) _finish();
    }

    if (runPhase == Phase.playing || runPhase == Phase.dying) {
      _acc += rdt * _timeScale;
      var steps = 0;
      while (_acc >= K.step && steps < 12) {
        if (runPhase == Phase.playing) _fixed(K.step);
        _acc -= K.step;
        steps++;
      }
      if (steps >= 12) _acc = 0;
      if (runPhase == Phase.playing) runT += rdt;
    }

    _updateWorld(rdt);
    _updateCamera(rdt);

    _hudT += rdt;
    if (_hudT >= 0.1) {
      _hudT = 0;
      hud.score = score;
      hud.seconds = runT;
      hud.lives = lives;
      hud.attached = pl.node != null;
      hud.stage = stage;
      hud.stageLines = stageLines;
      hud.stageTarget = stageTarget;
      hud.ropeFrac = pl.node == null ? 0 : (pl.len / K.maxRope).clamp(0.0, 1.0);
      hud.push();
    }
  }

  void _fixed(double h) {
    simT += h;
    final n = pl.node;
    var pull = 0.0;
    if (n != null) {
      pull = K.pull * (0.7 + 0.6 * GameSettings.I.sensitivity) * (n.kind == NodeKind.boost ? 1.7 : 1.0);
    }
    final ox = pl.x, oy = pl.y;
    Pendulum.integrate(pl, h, pull: pull);
    distance += sqrt((pl.x - ox) * (pl.x - ox) + (pl.y - oy) * (pl.y - oy));

    // fragile nodes crumble under load
    final held = pl.node;
    if (held != null && held.kind == NodeKind.fragile) {
      held.holdT += h;
      if (held.holdT > 1.1) {
        held.active = false;
        held.respawnT = 3.5;
        _broken.add(held);
        parts.burst(held.x, held.y, 16, Pal.purple, 220, 0.6, quality.maxParticles);
        _release(sound: false);
        AudioService.sfx('hit', vol: 0.35);
      }
    }
    for (var i = _broken.length - 1; i >= 0; i--) {
      final b = _broken[i];
      b.respawnT -= h;
      if (b.respawnT <= 0) {
        b.active = true;
        b.holdT = 0;
        _broken.removeAt(i);
      }
    }

    // walls / ceiling / floor
    if (arena.bounded) {
      if (pl.x < arena.minX + K.playerR) {
        pl.x = arena.minX + K.playerR;
        pl.vx = pl.vx.abs() * K.wallRest;
      } else if (pl.x > arena.maxX - K.playerR) {
        pl.x = arena.maxX - K.playerR;
        pl.vx = -pl.vx.abs() * K.wallRest;
      }
    }
    if (pl.y < K.playerR) {
      pl.y = K.playerR;
      pl.vy = pl.vy.abs() * K.wallRest;
    }
    if (pl.y > K.floorY - K.playerR) {
      if (arena.bounded) {
        pl.y = K.floorY - K.playerR;
        pl.vy = -pl.vy.abs() * K.wallRest;
        pl.vx *= 0.985;
        if (pl.vy.abs() < 40) pl.vy = -40;
      } else {
        _hurt();
      }
    }

    if (pl.invuln > 0) pl.invuln = max(0, pl.invuln - h);

    // enemies / hazards
    if (arena.bounded) {
      for (final hz in arena.hazards) {
        hz.drift(h, arena.minX, arena.maxX, 30, K.floorY - 30);
      }
    }
    if (lethal && runPhase == Phase.playing) {
      for (final hz in arena.hazards) {
        if ((hz.x - pl.x).abs() > 80) continue;
        if (!hz.drifting) hz.update(simT, 0);
        final dx = hz.x - pl.x, dy = hz.y - pl.y;
        final rr = hz.r + K.playerR - 1;
        if (dx * dx + dy * dy < rr * rr) {
          _hurt();
          break;
        }
      }
    }

    // enemy lines: crossing = points
    if (arena.links.isNotEmpty) {
      if (runPhase == Phase.playing) _crossLines(ox, oy);
      for (final l in arena.links) {
        if (l.cool > 0) l.cool -= h;
        if (l.flash > 0) l.flash -= h;
      }
    }

    // chaser wall
    if (mode == GameMode.swing && runPhase == Phase.playing) {
      final base = mode == GameMode.swing ? 60 + 120 * difficulty : 40 + 70 * difficulty;
      chaserX += base * h;
      if (pl.x < chaserX + 8) {
        if (mode == GameMode.survival) {
          _hurt();
          if (runPhase == Phase.playing) {
            chaserX = pl.x - 560;
          }
        } else {
          _hurt();
        }
      }
    }

    // score
    if (pl.x > maxX) maxX = pl.x;
    switch (mode) {
      case GameMode.cable:
        break;
      case GameMode.freeplay:
        score = swings;
      case GameMode.swing:
        score = (maxX / 10).floor();
        difficulty = (maxX / 14000).clamp(0.0, 1.0);
      case GameMode.survival:
        difficulty = ((stage - 1) / 8).clamp(0.0, 1.0);
    }

    // trail @60 Hz
    if (++_trailTick >= 2) {
      _trailTick = 0;
      pl.pushTrail();
    }
  }

  void _updateWorld(double dt) {
    // drone positions for rendering (only near camera)
    final r = camLeft + viewW + 100;
    for (final hz in arena.hazards) {
      if (hz.x < camLeft - 100 || hz.x > r) continue;
      hz.update(simT, dt);
    }
    for (final n in arena.nodes) {
      if (n.pulse > 0) n.pulse = max(0, n.pulse - dt * 2.5);
    }
    if (!arena.bounded) {
      final d = mode == GameMode.cable ? 0.0 : difficulty;
      if (gen.lastX < pl.x + 1700) gen.extend(arena, pl.x + 1900, d);
      _cullT += dt;
      if (_cullT > 1.0) {
        _cullT = 0;
        arena.cull(min(pl.x, chaserX) - 900);
      }
    }
  }

  void _updateCamera(double dt) {
    final target = pl.x + pl.vx * 0.22 + (arena.bounded ? 0 : viewW * 0.18);
    final k = 1 - exp(-5.5 * dt);
    _camX += (target - _camX) * k;
    camLeft = _camX - viewW / 2;
    if (arena.bounded) {
      final span = arena.maxX - arena.minX;
      if (span <= viewW) {
        camLeft = arena.minX - (viewW - span) / 2;
      } else {
        camLeft = camLeft.clamp(arena.minX - 30, arena.maxX + 30 - viewW);
      }
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    _renderer.draw(canvas, this);
  }
}
