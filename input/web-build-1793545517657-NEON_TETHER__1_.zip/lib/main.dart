import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'audio/audio_service.dart';
import 'core/constants.dart';
import 'menu/main_menu.dart';
import 'save/save_system.dart';
import 'settings/settings.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(
      [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  await SaveSystem.init();
  GameSettings.I.load();
  await AudioService.init();
  AudioService.startMusic();
  runApp(const NeonTetherApp());
}

class NeonTetherApp extends StatelessWidget {
  const NeonTetherApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NEON / TETHER',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Pal.bg,
        useMaterial3: true,
      ),
      home: const MainMenu(),
    );
  }
}
