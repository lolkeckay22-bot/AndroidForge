import 'dart:math';
import '../core/constants.dart';
import '../player/player.dart';

/// Pendulum / rope physics. Fixed-step, semi-implicit Euler with a
/// position + velocity rope constraint. The rope is *inextensible but slack-able*:
/// it only acts when the player is farther than [Player.len] from the anchor.
class Pendulum {
  /// Reel-in while taut. Shortening the rope conserves angular momentum
  /// (tangential speed scales by oldLen/newLen) -> real speed gain like a skater pulling arms in.
  static void reel(Player p, double rate, double dt) {
    final n = p.node;
    if (n == null || rate <= 0 || p.len <= K.minRope) return;
    final newLen = max(K.minRope, p.len - rate * dt);
    if (newLen >= p.len) return;
    final dx = p.x - n.x, dy = p.y - n.y;
    final d = sqrt(dx * dx + dy * dy);
    if (d > 1e-3 && d >= p.len - 3) {
      final nx = dx / d, ny = dy / d;
      final vr = p.vx * nx + p.vy * ny;
      final k = p.len / newLen;
      final tx = (p.vx - vr * nx) * k;
      final ty = (p.vy - vr * ny) * k;
      p.vx = tx + vr * nx;
      p.vy = ty + vr * ny;
    }
    p.len = newLen;
  }

  /// [pull] = rope pull acceleration toward the anchor (GlintLine-style attraction).
  static void integrate(Player p, double dt, {double pull = 0}) {
    final n = p.node;
    if (n != null && pull > 0) {
      final dx = n.x - p.x, dy = n.y - p.y;
      final d = sqrt(dx * dx + dy * dy);
      if (d > 1) {
        p.vx += dx / d * pull * dt;
        p.vy += dy / d * pull * dt;
      }
    }
    p.vy += K.gravity * dt;
    final damp = 1 - K.drag * dt;
    p.vx *= damp;
    p.vy *= damp;
    final sp2 = p.vx * p.vx + p.vy * p.vy;
    if (sp2 > K.maxSpeed * K.maxSpeed) {
      final k = K.maxSpeed / sqrt(sp2);
      p.vx *= k;
      p.vy *= k;
    }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    constrain(p);
  }

  static void constrain(Player p) {
    final n = p.node;
    if (n == null) return;
    final dx = p.x - n.x, dy = p.y - n.y;
    final d = sqrt(dx * dx + dy * dy);
    if (d > p.len && d > 1e-6) {
      final nx = dx / d, ny = dy / d;
      p.x = n.x + nx * p.len;
      p.y = n.y + ny * p.len;
      final vn = p.vx * nx + p.vy * ny;
      if (vn > 0) {
        p.vx -= vn * nx;
        p.vy -= vn * ny;
      }
    }
  }
}
