/// Segment intersection helper.
class Geo {
  /// Returns t in [0,1] along a->b where it crosses c->d, or -1 if no crossing.
  static double segHit(double ax, double ay, double bx, double by,
      double cx, double cy, double dx, double dy) {
    final d1x = bx - ax, d1y = by - ay, d2x = dx - cx, d2y = dy - cy;
    final den = d1x * d2y - d1y * d2x;
    if (den.abs() < 1e-9) return -1;
    final t = ((cx - ax) * d2y - (cy - ay) * d2x) / den;
    final u = ((cx - ax) * d1y - (cy - ay) * d1x) / den;
    if (t < 0 || t > 1 || u < 0 || u > 1) return -1;
    return t;
  }
}
