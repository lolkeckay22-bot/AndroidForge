import 'dart:ui';

/// Physics / world constants. World units: view height is always [viewH].
class K {
  static const double viewH = 800;
  static const double step = 1 / 120; // fixed physics step
  static const double gravity = 980;
  static const double reach = 430; // max distance to hook a node
  static const double maxRope = 430;
  static const double minRope = 80;
  static const double playerR = 9;
  static const double drag = 0.10; // 1/s, air drag
  static const double maxSpeed = 1500;
  static const double pull = 650; // rope pull acceleration toward anchor
  static const double reelBase = 38; // units/s reel-in (conserves angular momentum)
  static const double reelBoost = 150;
  static const double floorY = 760;
  static const double wallRest = 0.55;
}

Color al(Color c, double o) =>
    c.withAlpha((o.clamp(0.0, 1.0) * 255).round());

class Pal {
  static const bg = Color(0xFF05060F);
  static const bg2 = Color(0xFF0B0F24);
  static const cyan = Color(0xFF00E5FF);
  static const pink = Color(0xFFFF2BD6);
  static const red = Color(0xFFFF2D55);
  static const purple = Color(0xFF9B5CFF);
  static const white = Color(0xFFEAF6FF);
  static const gold = Color(0xFFFFD84A);
}
