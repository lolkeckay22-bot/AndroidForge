import 'dart:ui';
import 'constants.dart';

enum GameMode { cable, freeplay, swing, survival }

extension GameModeInfo on GameMode {
  String get title => switch (this) {
        GameMode.cable => 'CABLE MASTER',
        GameMode.freeplay => 'FREEPLAY',
        GameMode.swing => 'SWING MASTER',
        GameMode.survival => 'SURVIVAL',
      };
  String get desc => switch (this) {
        GameMode.cable => 'Training. Enemies are harmless.\nCross their glowing lines.',
        GameMode.freeplay => 'No enemies. Bounded arena.\nPure rope physics.',
        GameMode.swing => 'Endless world with walls.\nA red wall chases you.',
        GameMode.survival => '3 hearts. Cross lines, dodge enemies.\nClear stages to heal.',
      };
  String get scoreLabel => switch (this) {
        GameMode.cable => 'POINTS',
        GameMode.freeplay => 'SWINGS',
        GameMode.swing => 'DISTANCE',
        GameMode.survival => 'SCORE',
      };
  Color get color => switch (this) {
        GameMode.cable => Pal.cyan,
        GameMode.freeplay => Pal.purple,
        GameMode.swing => Pal.pink,
        GameMode.survival => Pal.red,
      };
}
