import 'dart:ui';
import '../core/constants.dart';

enum NodeKind { normal, boost, fragile, danger }

extension NodeKindColor on NodeKind {
  Color get color => switch (this) {
        NodeKind.normal => Pal.cyan,
        NodeKind.boost => Pal.pink,
        NodeKind.fragile => Pal.purple,
        NodeKind.danger => Pal.red,
      };
}

class RopeNode {
  RopeNode(this.id, this.x, this.y, this.kind);
  final int id;
  final double x, y;
  final NodeKind kind;
  RopeNode? next; // chain link for the thin connecting lines
  bool active = true;
  double holdT = 0; // fragile: time held
  double respawnT = 0;
  double pulse = 0; // visual pulse 0..1
}
