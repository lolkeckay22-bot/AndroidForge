import 'dart:math';
import '../core/constants.dart';
import '../core/game_mode.dart';
import '../enemies/enemy_link.dart';
import '../enemies/hazard.dart';
import 'arena.dart';
import 'rope_node.dart';

/// Builds the fixed Cable Master arena and the procedural endless tracks.
/// Safety rule: the main *chain* (normal/boost, occasional fragile) is always
/// reachable (<= 0.7*reach between neighbours); hazards and red nodes are decoys
/// placed away from the chain, so the player is never trapped.
class ArenaGenerator {
  ArenaGenerator(this.mode, int seed) : rng = Random(seed);
  final GameMode mode;
  final Random rng;
  int _id = 0;
  double _cx = 0, _cy = 200;
  RopeNode? _tail;
  bool _lastFragile = false;
  double get lastX => _cx;

  RopeNode _add(Arena a, double x, double y, NodeKind k) {
    final n = RopeNode(_id++, x, y, k);
    a.nodes.add(n);
    return n;
  }

  // ---------- Cable Master: fixed, bounded arena ----------
  void buildCableArena(Arena a) {
    a.bounded = true;
    a.minX = 0;
    a.maxX = 2400;
    // bottom row ensures you can always re-hook from the floor
    RopeNode? prev;
    for (double x = 120; x < 2300; x += 170) {
      final n = _add(a, x + rng.nextDouble() * 40 - 20, 560 + rng.nextDouble() * 50, NodeKind.normal);
      prev?.next = n;
      prev = n;
    }
    prev = null;
    for (double x = 200; x < 2300; x += 190) {
      final k = rng.nextDouble() < 0.18 ? NodeKind.boost : NodeKind.normal;
      final n = _add(a, x + rng.nextDouble() * 50 - 25, 330 + rng.nextDouble() * 70, k);
      prev?.next = n;
      prev = n;
    }
    prev = null;
    for (double x = 160; x < 2300; x += 230) {
      final k = rng.nextDouble() < 0.25 ? NodeKind.fragile : NodeKind.normal;
      final n = _add(a, x + rng.nextDouble() * 60 - 30, 90 + rng.nextDouble() * 80, k);
      prev?.next = n;
      prev = n;
    }
  }

  /// Drifting enemies joined by scoring lines (bounded arena modes).
  void buildEnemies(Arena a, int count, double speed, double avoidX, double avoidY) {
    final list = <Hazard>[];
    var tries = 0;
    while (list.length < count && tries++ < 400) {
      final x = 150 + rng.nextDouble() * (a.maxX - a.minX - 300);
      final y = 90 + rng.nextDouble() * 520;
      if ((x - avoidX) * (x - avoidX) + (y - avoidY) * (y - avoidY) < 220 * 220) continue;
      if (!_farFromNodes(a, x, y, 60, 9999) || !_farFromHazards(a, x, y, 90)) continue;
      final ang = rng.nextDouble() * 6.2832;
      final sp = speed * (0.6 + rng.nextDouble() * 0.6);
      final hz = Hazard(x, y, 14, vx: cos(ang) * sp, vy: sin(ang) * sp);
      a.hazards.add(hz);
      list.add(hz);
    }
    list.sort((p, q) => p.x.compareTo(q.x));
    for (var i = 0; i + 1 < list.length; i++) {
      a.links.add(EnemyLink(list[i], list[i + 1]));
      if (i + 2 < list.length && rng.nextDouble() < 0.5) {
        a.links.add(EnemyLink(list[i], list[i + 2]));
      }
    }
  }

  // ---------- Endless modes ----------
  void startTrack(Arena a) {
    a.bounded = false;
    _cx = 0;
    _cy = 190;
    _tail = _add(a, _cx, _cy, NodeKind.normal);
  }

  /// Generate chain up to [toX]. [d] = difficulty 0..1.
  void extend(Arena a, double toX, double d) {
    final hostile = mode != GameMode.cable;
    while (_cx < toX) {
      final dx = min(285.0, (165 + rng.nextDouble() * 70) * (1 + 0.18 * d));
      var dy = (rng.nextDouble() * 2 - 1) * (70 + 60 * d);
      var ny = (_cy + dy).clamp(110.0, 440.0);
      dy = ny - _cy;
      final nx = _cx + dx;

      NodeKind kind = NodeKind.normal;
      final r = rng.nextDouble();
      if (!_lastFragile && r < 0.07 + 0.16 * d) {
        kind = NodeKind.fragile;
      } else if (r > 0.9) {
        kind = NodeKind.boost;
      }
      _lastFragile = kind == NodeKind.fragile;
      final n = _add(a, nx, ny, kind);
      _tail?.next = n;

      // bridge node (extra safety + variety)
      if (rng.nextDouble() < 0.45) {
        _add(a, _cx + dx * 0.5 + rng.nextDouble() * 30 - 15,
            (min(_cy, ny) - 40 - rng.nextDouble() * 60).clamp(70.0, 430.0), NodeKind.normal);
      }

      if (hostile) _decoys(a, _cx, _cy, nx, ny, d);

      _tail = n;
      _cx = nx;
      _cy = ny;
    }
  }

  bool _farFromNodes(Arena a, double x, double y, double r, [int recent = 14]) {
    for (var i = a.nodes.length - 1; i >= 0 && i > a.nodes.length - recent; i--) {
      final n = a.nodes[i];
      final ddx = n.x - x, ddy = n.y - y;
      if (ddx * ddx + ddy * ddy < r * r) return false;
    }
    return true;
  }

  /// Drone sweeps a vertical line segment: keep every node & hazard clear of it.
  bool _farFromSweep(Arena a, double x, double by, double amp, double r) {
    final lim = r + 38;
    for (final n in a.nodes) {
      if ((n.x - x).abs() < lim && n.y > by - amp - lim && n.y < by + amp + lim) return false;
    }
    for (final h in a.hazards) {
      if ((h.x - x).abs() < lim + h.r && h.baseY > by - amp - lim - h.r && h.baseY < by + amp + lim + h.r) return false;
    }
    return true;
  }

  bool _farFromHazards(Arena a, double x, double y, double r) {
    for (final h in a.hazards) {
      final dx = h.x - x, dy = h.baseY - y;
      final rr = r + h.r;
      if (dx * dx + dy * dy < rr * rr) return false;
    }
    return true;
  }

  void _decoys(Arena a, double x0, double y0, double x1, double y1, double d) {
    final mx = (x0 + x1) / 2, my = (y0 + y1) / 2;
    // mine
    if (rng.nextDouble() < 0.18 + 0.4 * d) {
      final below = rng.nextBool();
      final y = below ? my + 110 + rng.nextDouble() * 110 : my - 90 - rng.nextDouble() * 60;
      if (_farFromNodes(a, mx, y, 80) && y > 40 && y < K.floorY - 60) {
        a.hazards.add(Hazard(mx, y, 13 + rng.nextDouble() * 8));
      }
    }
    // drone (survival only)
    if (mode == GameMode.survival && rng.nextDouble() < 0.12 + 0.3 * d) {
      final by = (my + 120).clamp(150.0, 560.0);
      final amp = 50 + rng.nextDouble() * 60;
      if (_farFromSweep(a, mx + 40, by, amp, 14)) {
        a.hazards.add(Hazard(mx + 40, by, 14,
            amp: amp, speed: 1.4 + 1.2 * d + rng.nextDouble() * 0.5, phase: rng.nextDouble() * 6.28));
      }
    }
    // red node decoy
    if (rng.nextDouble() < 0.12 + 0.28 * d) {
      final x = mx + rng.nextDouble() * 80 - 40;
      final y = (my + 70 + rng.nextDouble() * 90).clamp(100.0, 560.0);
      if (_farFromNodes(a, x, y, 70) && _farFromHazards(a, x, y, 60)) {
        _add(a, x, y, NodeKind.danger);
      }
    }
  }
}
