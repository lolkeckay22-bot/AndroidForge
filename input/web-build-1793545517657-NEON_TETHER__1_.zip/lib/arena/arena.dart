import '../enemies/enemy_link.dart';
import '../enemies/hazard.dart';
import 'rope_node.dart';

class Arena {
  final List<RopeNode> nodes = [];
  final List<Hazard> hazards = [];
  final List<EnemyLink> links = [];
  double minX = double.negativeInfinity;
  double maxX = double.infinity;
  bool bounded = false;

  void clear() {
    nodes.clear();
    hazards.clear();
    links.clear();
  }

  void cull(double leftX) {
    nodes.removeWhere((n) => n.x < leftX);
    hazards.removeWhere((h) => h.x < leftX);
  }
}
