import '../settings/settings.dart';

/// Effective effect quality. Auto mode (settings.quality == 3) watches frame
/// times and drops quality when the device can't keep up.
class Quality {
  int _auto = 2;
  double _acc = 0;
  int _frames = 0;
  double _cool = 0;

  int get level {
    final q = GameSettings.I.quality;
    return q == 3 ? _auto : q;
  }

  int get maxParticles => const [50, 140, 300][level];
  int get trailLen => const [8, 18, 30][level];
  int get glowLayers => const [1, 2, 3][level];
  int get stars => const [0, 28, 60][level];

  void sample(double rawDt) {
    if (GameSettings.I.quality != 3) return;
    if (rawDt <= 0 || rawDt > 0.25) return;
    _acc += rawDt;
    _frames++;
    _cool -= rawDt;
    if (_frames >= 90) {
      final avg = _acc / _frames;
      if (avg > 1 / 42 && _auto > 0 && _cool <= 0) {
        _auto--;
        _cool = 3;
      } else if (avg < 1 / 75 && _auto < 2 && _cool <= 0) {
        // device has headroom (e.g. 90/120 Hz): allow upgrade slowly
        _auto++;
        _cool = 8;
      }
      _acc = 0;
      _frames = 0;
    }
  }
}
