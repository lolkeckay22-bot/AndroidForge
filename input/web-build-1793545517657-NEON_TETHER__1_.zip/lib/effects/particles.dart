import 'dart:math';
import 'dart:typed_data';
import 'dart:ui';

/// Allocation-free particle + ring pool.
class ParticleSystem {
  static const int cap = 300;
  final Float32List _x = Float32List(cap), _y = Float32List(cap);
  final Float32List _vx = Float32List(cap), _vy = Float32List(cap);
  final Float32List _life = Float32List(cap), _max = Float32List(cap), _size = Float32List(cap);
  final Uint32List _col = Uint32List(cap);
  int _n = 0;
  final Random _r = Random();
  final Paint _paint = Paint();

  // rings
  static const int ringCap = 10;
  final Float32List _rx = Float32List(ringCap), _ry = Float32List(ringCap);
  final Float32List _rr = Float32List(ringCap), _rl = Float32List(ringCap), _rmax = Float32List(ringCap);
  final Float32List _rgrow = Float32List(ringCap);
  final Uint32List _rcol = Uint32List(ringCap);
  int _rn = 0;
  final Paint _ringPaint = Paint()..style = PaintingStyle.stroke;

  void burst(double x, double y, int count, Color c, double speed, double life, int limit,
      {double size = 2.4}) {
    for (var i = 0; i < count; i++) {
      if (_n >= min(cap, limit)) return;
      final a = _r.nextDouble() * 6.2831853;
      final s = speed * (0.25 + _r.nextDouble() * 0.75);
      _x[_n] = x;
      _y[_n] = y;
      _vx[_n] = cos(a) * s;
      _vy[_n] = sin(a) * s;
      _max[_n] = life * (0.6 + _r.nextDouble() * 0.4);
      _life[_n] = _max[_n];
      _size[_n] = size * (0.6 + _r.nextDouble() * 0.7);
      _col[_n] = c.value;
      _n++;
    }
  }

  void ring(double x, double y, double startR, double grow, double life, Color c) {
    if (_rn >= ringCap) {
      // overwrite oldest
      for (var i = 1; i < ringCap; i++) {
        _rx[i - 1] = _rx[i]; _ry[i - 1] = _ry[i]; _rr[i - 1] = _rr[i];
        _rl[i - 1] = _rl[i]; _rmax[i - 1] = _rmax[i]; _rgrow[i - 1] = _rgrow[i];
        _rcol[i - 1] = _rcol[i];
      }
      _rn = ringCap - 1;
    }
    _rx[_rn] = x; _ry[_rn] = y; _rr[_rn] = startR; _rgrow[_rn] = grow;
    _rl[_rn] = life; _rmax[_rn] = life; _rcol[_rn] = c.value;
    _rn++;
  }

  void update(double dt) {
    var i = 0;
    while (i < _n) {
      _life[i] -= dt;
      if (_life[i] <= 0) {
        _n--;
        _x[i] = _x[_n]; _y[i] = _y[_n]; _vx[i] = _vx[_n]; _vy[i] = _vy[_n];
        _life[i] = _life[_n]; _max[i] = _max[_n]; _size[i] = _size[_n]; _col[i] = _col[_n];
        continue;
      }
      _vx[i] *= 1 - 1.8 * dt;
      _vy[i] = _vy[i] * (1 - 1.8 * dt) + 120 * dt;
      _x[i] += _vx[i] * dt;
      _y[i] += _vy[i] * dt;
      i++;
    }
    i = 0;
    while (i < _rn) {
      _rl[i] -= dt;
      if (_rl[i] <= 0) {
        for (var j = i + 1; j < _rn; j++) {
          _rx[j - 1] = _rx[j]; _ry[j - 1] = _ry[j]; _rr[j - 1] = _rr[j];
          _rl[j - 1] = _rl[j]; _rmax[j - 1] = _rmax[j]; _rgrow[j - 1] = _rgrow[j];
          _rcol[j - 1] = _rcol[j];
        }
        _rn--;
        continue;
      }
      _rr[i] += _rgrow[i] * dt;
      i++;
    }
  }

  void clear() {
    _n = 0;
    _rn = 0;
  }

  void render(Canvas c) {
    for (var i = 0; i < _rn; i++) {
      final t = _rl[i] / _rmax[i];
      _ringPaint
        ..strokeWidth = 2.2 * t + 0.5
        ..color = Color(_rcol[i]).withAlpha((t * 200).round());
      c.drawCircle(Offset(_rx[i], _ry[i]), _rr[i], _ringPaint);
    }
    _paint.style = PaintingStyle.fill;
    for (var i = 0; i < _n; i++) {
      final t = _life[i] / _max[i];
      _paint.color = Color(_col[i]).withAlpha((t * 230).round());
      c.drawCircle(Offset(_x[i], _y[i]), _size[i] * (0.4 + 0.6 * t), _paint);
    }
  }
}
