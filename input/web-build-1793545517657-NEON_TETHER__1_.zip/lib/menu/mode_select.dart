import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../core/game_mode.dart';
import '../game/game_screen.dart';
import '../statistics/statistics.dart';
import '../ui/menu_scaffold.dart';
import '../ui/neon_widgets.dart';

class ModeSelect extends StatelessWidget {
  const ModeSelect({super.key});
  @override
  Widget build(BuildContext context) {
    return MenuScaffold(
      title: 'SELECT MODE',
      child: Center(
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: SizedBox(
            width: 900,
            height: 330,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [for (final m in GameMode.values) _card(context, m)],
            ),
          ),
        ),
      ),
    );
  }

  Widget _card(BuildContext context, GameMode m) {
    final c = m.color;
    return GestureDetector(
      onTap: () => Navigator.push(context, fadeRoute(GameScreen(mode: m))),
      child: Container(
        width: 208,
        height: 316,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: al(c, 0.07),
          border: Border.all(color: c, width: 1.6),
          boxShadow: [BoxShadow(color: al(c, 0.35), blurRadius: 22)],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(m.title, style: neonStyle(16, c, spacing: 2)),
          const SizedBox(height: 14),
          Text(m.desc, style: neonStyle(12, al(Pal.white, 0.85), w: FontWeight.w500, spacing: 0.3, glow: 0)),
          const Spacer(),
          Text('BEST', style: neonStyle(12, al(Pal.white, 0.5), glow: 0)),
          Text('${Statistics.best(m)}  ${m.scoreLabel}', style: neonStyle(20, Pal.white, glow: 10, spacing: 1)),
          const SizedBox(height: 14),
          NeonButton(label: 'START', width: double.infinity, height: 46, color: c, filled: true, onTap: () => Navigator.push(context, fadeRoute(GameScreen(mode: m)))),
        ]),
      ),
    );
  }
}
