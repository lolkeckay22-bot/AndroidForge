import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../player/skins.dart';
import '../statistics/statistics.dart';
import '../ui/menu_scaffold.dart';
import '../ui/neon_widgets.dart';

class CustomizeScreen extends StatefulWidget {
  const CustomizeScreen({super.key});
  @override
  State<CustomizeScreen> createState() => _CustomizeScreenState();
}

class _CustomizeScreenState extends State<CustomizeScreen> {
  @override
  Widget build(BuildContext context) {
    return MenuScaffold(
      title: 'CUSTOMIZE',
      child: Center(
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: SizedBox(
            width: 900,
            height: 300,
            child: Column(children: [
              Text('Unlock skins by swinging.  Total swings: ${Statistics.swings}',
                  style: neonStyle(14, al(Pal.white, 0.7), glow: 0, w: FontWeight.w500)),
              const SizedBox(height: 22),
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                for (var i = 0; i < Skins.list.length; i++) _tile(i),
              ]),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _tile(int i) {
    final s = Skins.list[i];
    final ok = Skins.unlocked(i);
    final sel = Skins.selected == i;
    return GestureDetector(
      onTap: ok ? () => setState(() => Skins.select(i)) : null,
      child: Container(
        width: 150,
        height: 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: al(s.color, ok ? 0.08 : 0.02),
          border: Border.all(color: sel ? s.color : al(Pal.white, 0.2), width: sel ? 2.4 : 1.2),
          boxShadow: sel ? [BoxShadow(color: al(s.color, 0.5), blurRadius: 20)] : null,
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: ok ? s.color : al(Pal.white, 0.15),
              boxShadow: ok ? [BoxShadow(color: al(s.color, 0.8), blurRadius: 22, spreadRadius: 2)] : null,
            ),
          ),
          const SizedBox(height: 22),
          Text(s.name, style: neonStyle(15, ok ? Pal.white : al(Pal.white, 0.4), glow: ok ? 8 : 0)),
          const SizedBox(height: 8),
          Text(ok ? (sel ? 'EQUIPPED' : 'TAP TO EQUIP') : 'LOCKED • ${s.needSwings} swings',
              textAlign: TextAlign.center,
              style: neonStyle(11, al(Pal.white, 0.6), glow: 0, spacing: 1)),
        ]),
      ),
    );
  }
}
