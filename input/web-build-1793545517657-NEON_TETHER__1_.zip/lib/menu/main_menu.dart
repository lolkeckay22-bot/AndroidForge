import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../ui/menu_scaffold.dart';
import '../ui/neon_background.dart';
import '../ui/neon_widgets.dart';
import '../settings/settings_screen.dart';
import '../statistics/stats_screen.dart';
import 'customize_screen.dart';
import 'mode_select.dart';

class MainMenu extends StatelessWidget {
  const MainMenu({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pal.bg,
      body: NeonBackground(
        child: SafeArea(
          child: Center(
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: SizedBox(
                width: 900,
                height: 400,
                child: Row(children: [
                  Expanded(child: _logo()),
                  SizedBox(
                    width: 300,
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      NeonButton(
                        label: 'PLAY',
                        icon: Icons.play_arrow_rounded,
                        width: 280,
                        height: 66,
                        fontSize: 26,
                        filled: true,
                        color: Pal.pink,
                        onTap: () => Navigator.push(context, fadeRoute(const ModeSelect())),
                      ),
                      const SizedBox(height: 16),
                      NeonButton(
                        label: 'CUSTOMIZE',
                        icon: Icons.palette_outlined,
                        width: 280,
                        onTap: () => Navigator.push(context, fadeRoute(const CustomizeScreen())),
                      ),
                      const SizedBox(height: 12),
                      NeonButton(
                        label: 'STATS',
                        icon: Icons.bar_chart_rounded,
                        width: 280,
                        color: Pal.purple,
                        onTap: () => Navigator.push(context, fadeRoute(const StatsScreen())),
                      ),
                      const SizedBox(height: 12),
                      NeonButton(
                        label: 'SETTINGS',
                        icon: Icons.tune_rounded,
                        width: 280,
                        color: Pal.white,
                        onTap: () => Navigator.push(context, fadeRoute(const SettingsScreen())),
                      ),
                    ]),
                  ),
                  const SizedBox(width: 30),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _logo() => Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.only(left: 40),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('NEON', style: neonStyle(84, Pal.cyan, spacing: 14, glow: 28)),
            Row(children: [
              Container(width: 54, height: 3, color: Pal.pink),
              const SizedBox(width: 12),
              Text('/', style: neonStyle(54, Pal.pink, glow: 22)),
              const SizedBox(width: 12),
              Container(width: 54, height: 3, color: Pal.pink),
            ]),
            Text('TETHER', style: neonStyle(84, Pal.pink, spacing: 14, glow: 28)),
            const SizedBox(height: 10),
            Text('SWING  •  RELEASE  •  SURVIVE', style: neonStyle(13, al(Pal.white, 0.7), spacing: 5, glow: 0)),
          ]),
        ),
      ]);
}
