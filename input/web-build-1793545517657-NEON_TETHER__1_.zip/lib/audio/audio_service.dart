import 'package:flame_audio/flame_audio.dart';
import '../settings/settings.dart';

class AudioService {
  static bool _ready = false;
  static final Map<String, int> _last = {};
  static const _sfx = ['attach', 'release', 'hit', 'miss', 'gameover', 'pickup'];

  static Future<void> init() async {
    try {
      await FlameAudio.audioCache.loadAll([..._sfx.map((e) => '$e.wav'), 'music.wav']);
      FlameAudio.bgm.initialize();
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  static void sfx(String name, {double vol = 1}) {
    final s = GameSettings.I;
    if (!_ready || !s.sfx) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - (_last[name] ?? 0) < 45) return;
    _last[name] = now;
    try {
      FlameAudio.play('$name.wav', volume: (s.volume * vol).clamp(0.0, 1.0));
    } catch (_) {}
  }

  static void startMusic() {
    final s = GameSettings.I;
    if (!_ready || !s.music) return;
    try {
      FlameAudio.bgm.play('music.wav', volume: s.volume * 0.45);
    } catch (_) {}
  }

  static void stopMusic() {
    if (!_ready) return;
    try {
      FlameAudio.bgm.stop();
    } catch (_) {}
  }

  static void applySettings() {
    final s = GameSettings.I;
    if (!_ready) return;
    if (!s.music) {
      stopMusic();
    } else {
      startMusic();
    }
  }
}
