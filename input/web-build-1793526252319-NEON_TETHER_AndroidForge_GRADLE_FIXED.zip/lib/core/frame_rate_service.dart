import 'dart:io';

import 'package:flutter/services.dart';

/// Requests a preferred Android surface refresh rate. The platform may choose
/// a nearby supported mode or ignore the request; the fixed-step game physics
/// remains independent of display refresh rate.
class FrameRateService {
  static const MethodChannel _channel = MethodChannel('neon_tether/frame_rate');

  static Future<bool> apply(int fps) async {
    if (!Platform.isAndroid || (fps != 60 && fps != 90 && fps != 120)) {
      return false;
    }
    try {
      return await _channel.invokeMethod<bool>('setFrameRate', {'fps': fps}) ?? false;
    } on MissingPluginException {
      return false;
    } on PlatformException {
      return false;
    }
  }
}
