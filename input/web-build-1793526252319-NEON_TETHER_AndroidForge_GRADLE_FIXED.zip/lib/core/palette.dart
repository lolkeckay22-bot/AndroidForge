import 'package:flutter/material.dart';

class NeonPalette {
  static const background = Color(0xFF070A13);
  static const surface = Color(0xFF101729);
  static const surfaceLight = Color(0xFF17233A);
  static const cyan = Color(0xFF39E8FF);
  static const blue = Color(0xFF638BFF);
  static const pink = Color(0xFFFF4FCB);
  static const violet = Color(0xFF9A67FF);
  static const red = Color(0xFFFF5578);
  static const green = Color(0xFF63F4C1);
  static const muted = Color(0xFF8290AA);
  static const white = Color(0xFFEAF5FF);
}
