enum GameMode { cableMaster, swingMaster, survival }

extension GameModeLabel on GameMode {
  String get title => switch (this) {
        GameMode.cableMaster => 'CABLE MASTER',
        GameMode.swingMaster => 'SWING MASTER',
        GameMode.survival => 'SURVIVAL',
      };

  String get subtitle => switch (this) {
        GameMode.cableMaster => 'Свободная практика без урона и таймера.',
        GameMode.swingMaster => 'Бесконечный маршрут. Скорость и дистанция.',
        GameMode.survival => 'Три жизни. Опасности становятся быстрее.',
      };
}
