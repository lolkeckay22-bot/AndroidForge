import 'package:flutter/material.dart';
import '../core/palette.dart';

class NeonButton extends StatelessWidget {
  const NeonButton({super.key, required this.title, required this.subtitle, required this.color, required this.onTap, this.icon});
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  final IconData? icon;

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Ink(
            padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 16),
            decoration: BoxDecoration(
              color: const Color(0xB4101A2D),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: color.withOpacity(.46), width: 1),
              boxShadow: [BoxShadow(color: color.withOpacity(.08), blurRadius: 18, spreadRadius: 1)],
            ),
            child: Row(
              children: [
                Container(
                  width: 43,
                  height: 43,
                  decoration: BoxDecoration(
                    color: color.withOpacity(.12),
                    borderRadius: BorderRadius.circular(13),
                    border: Border.all(color: color.withOpacity(.45)),
                  ),
                  child: Icon(icon ?? Icons.bolt_rounded, color: color, size: 23),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(title, style: TextStyle(color: NeonPalette.white, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.6)),
                    const SizedBox(height: 4),
                    Text(subtitle, style: const TextStyle(color: NeonPalette.muted, fontSize: 11, height: 1.25)),
                  ]),
                ),
                Icon(Icons.arrow_forward_ios_rounded, size: 15, color: color.withOpacity(.8)),
              ],
            ),
          ),
        ),
      );
}

class NeonAction extends StatelessWidget {
  const NeonAction({super.key, required this.label, required this.icon, required this.onTap, this.color = NeonPalette.cyan});
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          height: 48,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: NeonPalette.surface.withOpacity(.9),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(.24)),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 17, color: color),
            const SizedBox(width: 7),
            Text(label, style: const TextStyle(color: NeonPalette.white, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.1)),
          ]),
        ),
      );
}
