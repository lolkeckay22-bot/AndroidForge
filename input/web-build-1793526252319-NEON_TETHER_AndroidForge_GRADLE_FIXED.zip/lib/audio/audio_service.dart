import 'package:flame_audio/flame_audio.dart';
import '../settings/game_settings.dart';

class AudioService {
  AudioService(this.settings);
  final GameSettings settings;
  bool _ready = false;
  bool _musicPlaying = false;
  double? _musicVolume;

  Future<void> initialize() async {
    if (_ready) return;
    try {
      FlameAudio.audioCache.prefix = 'assets/audio/';
      await FlameAudio.audioCache.loadAll(['hook.wav', 'release.wav', 'impact.wav', 'ui.wav', 'ambient.wav']);
      await FlameAudio.bgm.initialize();
      _ready = true;
    } catch (_) {
      // Audio is optional: game logic must never depend on successful audio init.
    }
  }

  Future<void> syncMusic() async {
    if (!_ready) return;
    try {
      if (settings.musicEnabled && settings.masterVolume > 0) {
        final volume = settings.masterVolume * 0.22;
        if (_musicPlaying && _musicVolume != volume) {
          await FlameAudio.bgm.stop();
          _musicPlaying = false;
        }
        if (!_musicPlaying) {
          await FlameAudio.bgm.play('ambient.wav', volume: volume);
          _musicPlaying = true;
          _musicVolume = volume;
        }
      } else if (_musicPlaying) {
        await FlameAudio.bgm.stop();
        _musicPlaying = false;
        _musicVolume = null;
      }
    } catch (_) {
      _musicPlaying = false;
    }
  }

  Future<void> play(String name) async {
    if (!_ready || !settings.sfxEnabled || settings.masterVolume <= 0) return;
    try {
      await FlameAudio.play('$name.wav', volume: settings.masterVolume);
    } catch (_) {
      // Device audio failures are non-fatal.
    }
  }

  Future<void> dispose() async {
    try {
      await FlameAudio.bgm.stop();
      await FlameAudio.bgm.dispose();
    } catch (_) {
      // Some Android audio backends are already disposed at process shutdown.
    }
  }
}
