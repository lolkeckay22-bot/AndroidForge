import 'package:shared_preferences/shared_preferences.dart';

class GameStatistics {
  final int bestSwing;
  final int bestSurvival;
  final int totalRuns;
  final int totalScore;
  final double totalDistance;

  const GameStatistics({
    this.bestSwing = 0,
    this.bestSurvival = 0,
    this.totalRuns = 0,
    this.totalScore = 0,
    this.totalDistance = 0,
  });

  static Future<GameStatistics> load() async {
    final p = await SharedPreferences.getInstance();
    return GameStatistics(
      bestSwing: p.getInt('bestSwing') ?? 0,
      bestSurvival: p.getInt('bestSurvival') ?? 0,
      totalRuns: p.getInt('totalRuns') ?? 0,
      totalScore: p.getInt('totalScore') ?? 0,
      totalDistance: p.getDouble('totalDistance') ?? 0,
    );
  }

  Future<GameStatistics> record({
    required String mode,
    required int score,
    required double distance,
  }) async {
    final p = await SharedPreferences.getInstance();
    final nextSwing = mode == 'swing' && score > bestSwing ? score : bestSwing;
    final nextSurvival = mode == 'survival' && score > bestSurvival ? score : bestSurvival;
    final next = GameStatistics(
      bestSwing: nextSwing,
      bestSurvival: nextSurvival,
      totalRuns: totalRuns + (mode == 'cable' ? 0 : 1),
      totalScore: totalScore + score,
      totalDistance: totalDistance + distance,
    );
    await p.setInt('bestSwing', next.bestSwing);
    await p.setInt('bestSurvival', next.bestSurvival);
    await p.setInt('totalRuns', next.totalRuns);
    await p.setInt('totalScore', next.totalScore);
    await p.setDouble('totalDistance', next.totalDistance);
    return next;
  }
}
