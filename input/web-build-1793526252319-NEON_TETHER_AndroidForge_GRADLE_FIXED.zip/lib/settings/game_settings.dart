import 'package:shared_preferences/shared_preferences.dart';

class GameSettings {
  double masterVolume;
  bool musicEnabled;
  bool sfxEnabled;
  bool highEffects;
  double sensitivity;
  int targetFps;
  String skin;

  GameSettings({
    this.masterVolume = 0.75,
    this.musicEnabled = true,
    this.sfxEnabled = true,
    this.highEffects = true,
    this.sensitivity = 1.0,
    this.targetFps = 60,
    this.skin = 'cyan',
  });

  static Future<GameSettings> load() async {
    final p = await SharedPreferences.getInstance();
    return GameSettings(
      masterVolume: (p.getDouble('masterVolume') ?? 0.75).clamp(0.0, 1.0).toDouble(),
      musicEnabled: p.getBool('musicEnabled') ?? true,
      sfxEnabled: p.getBool('sfxEnabled') ?? true,
      highEffects: p.getBool('highEffects') ?? true,
      sensitivity: (p.getDouble('sensitivity') ?? 1.0).clamp(0.6, 1.6).toDouble(),
      targetFps: [60, 90, 120].contains(p.getInt('targetFps')) ? p.getInt('targetFps')! : 60,
      skin: ['cyan', 'pink', 'blue', 'violet'].contains(p.getString('skin')) ? p.getString('skin')! : 'cyan',
    );
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('masterVolume', masterVolume);
    await p.setBool('musicEnabled', musicEnabled);
    await p.setBool('sfxEnabled', sfxEnabled);
    await p.setBool('highEffects', highEffects);
    await p.setDouble('sensitivity', sensitivity);
    await p.setInt('targetFps', targetFps);
    await p.setString('skin', skin);
  }
}
