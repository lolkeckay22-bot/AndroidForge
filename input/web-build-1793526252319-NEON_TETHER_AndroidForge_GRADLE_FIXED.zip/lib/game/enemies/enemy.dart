import 'dart:math' as math;
import 'package:flame/components.dart';

class EnemyHazard {
  EnemyHazard({required Vector2 position, required this.radius, required this.phase, this.speed = 1})
      : position = position,
        currentPosition = position.clone();

  /// Static world-space base point.
  final Vector2 position;
  /// Reused animated point; updated on the fixed physics clock.
  final Vector2 currentPosition;
  final double radius;
  final double phase;
  final double speed;

  void update(double time) {
    currentPosition.y = position.y + math.sin(time * speed + phase) * 22;
  }
}
