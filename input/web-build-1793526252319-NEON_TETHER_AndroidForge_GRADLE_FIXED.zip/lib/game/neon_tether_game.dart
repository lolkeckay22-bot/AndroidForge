import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flame/game.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flame/components.dart';

import '../core/game_mode.dart';
import '../core/palette.dart';
import '../settings/game_settings.dart';
import 'arena/arena_models.dart';
import 'effects/effect_pool.dart';
import 'enemies/enemy.dart';
import 'physics/player_body.dart';
import 'physics/tether_physics.dart';
import 'player/player_painter.dart';

class GameHudState {
  const GameHudState({
    required this.score,
    required this.elapsed,
    required this.lives,
    required this.speed,
    required this.hooked,
    required this.distance,
    required this.difficulty,
  });
  final int score;
  final double elapsed;
  final int lives;
  final double speed;
  final bool hooked;
  final double distance;
  final int difficulty;
}

class GameResult {
  const GameResult({required this.score, required this.elapsed, required this.distance});
  final int score;
  final double elapsed;
  final double distance;
}

class NeonTetherGame extends FlameGame {
  NeonTetherGame({
    required this.mode,
    required this.settings,
    required this.onRunEnded,
    this.onEffect,
  });

  final GameMode mode;
  final GameSettings settings;
  final ValueChanged<GameResult> onRunEnded;
  final ValueChanged<String>? onEffect;
  final ValueNotifier<GameHudState> hud = ValueNotifier<GameHudState>(
    const GameHudState(score: 0, elapsed: 0, lives: 3, speed: 0, hooked: false, distance: 0, difficulty: 1),
  );

  static const double _fixedDt = 1 / 120;
  final TetherPhysics _physics = TetherPhysics();
  final EffectPool _effects = EffectPool(capacity: 72);
  final List<AnchorNode> _anchors = <AnchorNode>[];
  final List<EnemyHazard> _enemies = <EnemyHazard>[];
  final List<TrailPoint> _trail = <TrailPoint>[];
  final List<Offset> _stars = <Offset>[];

  late PlayerBody player;
  AnchorNode? _attached;
  double _ropeLength = 0;
  double _ropeAge = 0;
  double _lineScoreCooldown = 0;
  double _previousPlayerX = 0;
  double _previousPlayerY = 0;
  double _width = 400;
  double _height = 800;
  double _cameraX = 0;
  double _accumulator = 0;
  double _elapsed = 0;
  double _trailTimer = 0;
  double _hudTimer = 0;
  double _lastScoreGate = 0;
  double _distance = 0;
  double _difficulty = 1;
  int _score = 0;
  int _lives = 3;
  int _nextAnchorId = 1;
  int _anchorIndex = 0;
  int _hits = 0;
  bool _initialized = false;
  bool _paused = false;
  bool _finished = false;
  bool _pointerHeld = false;
  bool _adaptiveLowEffects = false;
  int _slowFrames = 0;
  int _fastFrames = 0;

  bool get _effectsEnabled => settings.highEffects && !_adaptiveLowEffects;

  bool get isPaused => _paused;
  bool get isFinished => _finished;
  bool get hasTether => _attached != null;

  @override
  void onGameResize(Vector2 canvasSize) {
    super.onGameResize(canvasSize);
    _width = math.max(280.0, canvasSize.x).toDouble();
    _height = math.max(480.0, canvasSize.y).toDouble();
    if (!_initialized) {
      _initializeWorld();
      _initialized = true;
    }
  }

  void _initializeWorld() {
    _anchors.clear();
    _enemies.clear();
    _trail.clear();
    _stars.clear();
    _cameraX = 0;
    _elapsed = 0;
    _accumulator = 0;
    _score = 0;
    _distance = 0;
    _difficulty = 1;
    _hits = 0;
    _lives = mode == GameMode.survival ? 3 : 0;
    _lastScoreGate = _width * 0.52;
    _attached = null;
    _ropeLength = 0;
    _ropeAge = 0;
    _lineScoreCooldown = 0;
    _nextAnchorId = 1;
    _anchorIndex = 0;
    _finished = false;
    _paused = false;
    _pointerHeld = false;

    player = PlayerBody(
      position: Vector2(_width * 0.24, _height * 0.43),
      velocity: Vector2(_width * 0.47, -42),
    );

    for (var i = 0; i < 42; i++) {
      final x = ((i * 79) % 997) / 997 * _width;
      final y = ((i * 131 + 47) % 991) / 991 * _height;
      _stars.add(Offset(x, y));
    }

    if (mode == GameMode.cableMaster) {
      final points = <Offset>[
        Offset(_width * .16, _height * .27),
        Offset(_width * .48, _height * .18),
        Offset(_width * .80, _height * .30),
        Offset(_width * .27, _height * .58),
        Offset(_width * .61, _height * .55),
        Offset(_width * .88, _height * .67),
        Offset(_width * .18, _height * .82),
        Offset(_width * .48, _height * .84),
        Offset(_width * .75, _height * .88),
      ];
      for (var i = 0; i < points.length; i++) {
        _anchors.add(AnchorNode(
          id: _nextAnchorId++,
          position: Vector2(points[i].dx, points[i].dy),
          kind: i % 4 == 2 ? AnchorKind.boost : AnchorKind.standard,
        ));
      }
    } else {
      _anchors.add(AnchorNode(
        id: _nextAnchorId++,
        position: Vector2(_width * .50, _height * .24),
        kind: AnchorKind.standard,
      ));
      _anchors.add(AnchorNode(
        id: _nextAnchorId++,
        position: Vector2(_width * .88, _height * .48),
        kind: AnchorKind.boost,
      ));
      _anchors.add(AnchorNode(
        id: _nextAnchorId++,
        position: Vector2(_width * 1.30, _height * .28),
        kind: AnchorKind.standard,
      ));
      _anchorIndex = 3;
      _generateAhead();
    }
    _previousPlayerX = player.position.x;
    _previousPlayerY = player.position.y;
    _publishHud();
  }

  void restart() {
    _initializeWorld();
  }

  void pause() => _paused = true;
  void resume() {
    if (!_finished) _paused = false;
  }

  void disposeHud() => hud.dispose();

  /// Called by the Flutter pointer layer. Coordinates are local to GameWidget.
  void pointerDown(Offset screenPoint) {
    if (_paused || _finished || !_initialized) return;
    _pointerHeld = true;
    final worldPoint = Vector2(screenPoint.dx + _cameraX, screenPoint.dy);
    AnchorNode? selected;
    var bestTouchDistance = double.infinity;
    for (final anchor in _anchors) {
      final d = (anchor.position - worldPoint).length;
      if (d < bestTouchDistance && d < 52 * settings.sensitivity) {
        selected = anchor;
        bestTouchDistance = d;
      }
    }

    // A tap just off a node can still select the closest reachable point in
    // the tapped direction. This makes rapid mobile chaining forgiving.
    if (selected == null) {
      final aimX = worldPoint.x - player.position.x;
      final aimY = worldPoint.y - player.position.y;
      final aimLength = math.max(1.0, math.sqrt(aimX * aimX + aimY * aimY)).toDouble();
      final ax = aimX / aimLength;
      final ay = aimY / aimLength;
      var bestScore = -double.infinity;
      for (final anchor in _anchors) {
        final dx = anchor.position.x - player.position.x;
        final dy = anchor.position.y - player.position.y;
        final distance = math.sqrt(dx * dx + dy * dy);
        if (distance < 76 || distance > 500) continue;
        final alignment = (dx / distance) * ax + (dy / distance) * ay;
        if (alignment < .72) continue;
        final candidateScore = alignment * 2 - distance / 700;
        if (candidateScore > bestScore) {
          bestScore = candidateScore;
          selected = anchor;
        }
      }
    }

    if (selected != null) _attach(selected);
  }

  void pointerMove(Offset screenPoint) {
    if (!_pointerHeld || _paused || _finished || !_initialized) return;
    final worldPoint = Vector2(screenPoint.dx + _cameraX, screenPoint.dy);
    AnchorNode? candidate;
    var bestDistance = double.infinity;
    // During a held drag, snapping to a nearby node is preferred. Otherwise
    // use the finger direction to chain to the next reachable anchor.
    for (final anchor in _anchors) {
      if (identical(anchor, _attached)) continue;
      final d = (anchor.position - worldPoint).length;
      if (d < bestDistance && d < 58 * settings.sensitivity) {
        candidate = anchor;
        bestDistance = d;
      }
    }
    if (candidate == null) {
      final aimX = worldPoint.x - player.position.x;
      final aimY = worldPoint.y - player.position.y;
      final aimLength = math.max(1.0, math.sqrt(aimX * aimX + aimY * aimY)).toDouble();
      final ax = aimX / aimLength;
      final ay = aimY / aimLength;
      var bestScore = -double.infinity;
      for (final anchor in _anchors) {
        if (identical(anchor, _attached)) continue;
        final dx = anchor.position.x - player.position.x;
        final dy = anchor.position.y - player.position.y;
        final distance = math.sqrt(dx * dx + dy * dy);
        if (distance < 76 || distance > 420) continue;
        final alignment = (dx / distance) * ax + (dy / distance) * ay;
        if (alignment < .84) continue;
        final score = alignment * 2 - distance / 650;
        if (score > bestScore) { bestScore = score; candidate = anchor; }
      }
    }
    if (candidate != null && !identical(candidate, _attached)) _attach(candidate);
  }

  void pointerUp() {
    if (!_pointerHeld) return;
    _pointerHeld = false;
    _release();
  }

  void _attach(AnchorNode anchor) {
    if (identical(_attached, anchor)) return;
    final dx = anchor.position.x - player.position.x;
    final dy = anchor.position.y - player.position.y;
    final distance = math.sqrt(dx * dx + dy * dy);
    if (distance > 500 || distance < 55) return;

    _attached = anchor;
    _ropeLength = distance.clamp(90.0, 460.0).toDouble();
    _ropeAge = 0;
    if (anchor.kind == AnchorKind.boost) {
      final inv = 1 / math.max(distance, 1.0).toDouble();
      player.velocity.x += dx * inv * 115;
      player.velocity.y += dy * inv * 115;
    }
    onEffect?.call('hook');
    if (_effectsEnabled) _effects.burst(anchor.position, NeonPalette.cyan, count: 9, speed: 120);
  }

  void _release() {
    if (_attached == null) return;
    _attached = null;
    _ropeLength = 0;
    _ropeAge = 0;
    onEffect?.call('release');
    if (_effectsEnabled) _effects.burst(player.position, NeonPalette.pink, count: 7, speed: 110);
    // Velocity is intentionally untouched: the exit momentum is the reward
    // for releasing at the bottom of the swing.
    if (mode == GameMode.cableMaster) _score += 1;
    _publishHud();
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (!_initialized || _paused || _finished || _width <= 0 || _height <= 0) return;
    _adaptEffects(dt);
    final safeDt = dt.clamp(0.0, 0.05).toDouble();
    _accumulator += safeDt;
    while (_accumulator >= _fixedDt) {
      _fixedUpdate(_fixedDt);
      _accumulator -= _fixedDt;
      if (_finished) break;
    }
    _effects.update(safeDt);
    _trailTimer += safeDt;
    if (_trailTimer >= 0.022) {
      _trailTimer = 0;
      _trail.add(TrailPoint(player.position.clone(), 0.42));
      if (_trail.length > 22) _trail.removeAt(0);
    }
    for (final point in _trail) {
      point.life -= safeDt;
    }
    _trail.removeWhere((p) => p.life <= 0);
    _hudTimer += safeDt;
    if (_hudTimer >= 0.09) {
      _hudTimer = 0;
      _publishHud();
    }
  }

  void _adaptEffects(double frameDt) {
    if (!settings.highEffects) {
      _adaptiveLowEffects = false;
      _slowFrames = 0;
      _fastFrames = 0;
      return;
    }
    if (frameDt > 1 / 45) {
      _slowFrames++;
      _fastFrames = 0;
      if (_slowFrames >= 8) _adaptiveLowEffects = true;
    } else if (frameDt < 1 / 75) {
      _slowFrames = 0;
      if (_adaptiveLowEffects) {
        _fastFrames++;
        if (_fastFrames >= 360) {
          _adaptiveLowEffects = false;
          _fastFrames = 0;
        }
      }
    } else {
      _slowFrames = 0;
      _fastFrames = 0;
    }
  }

  void _fixedUpdate(double dt) {
    _elapsed += dt;
    for (final enemy in _enemies) {
      enemy.update(_elapsed);
    }
    _previousPlayerX = player.position.x;
    _previousPlayerY = player.position.y;
    _lineScoreCooldown = math.max(0.0, _lineScoreCooldown - dt).toDouble();
    if (player.invulnerabilityTimer > 0) {
      player.invulnerabilityTimer = math.max(0.0, player.invulnerabilityTimer - dt).toDouble();
      player.invulnerable = player.invulnerabilityTimer > 0;
    }

    if (_attached != null) {
      _ropeAge += dt;
      _ropeLength = math.max(86.0, _ropeLength - 9.0 * dt).toDouble();
      if (_attached!.kind == AnchorKind.fragile && _ropeAge > 1.25) _release();
    }

    _physics.step(
      body: player,
      dt: dt,
      anchor: _attached?.position,
      ropeLength: _attached == null ? null : _ropeLength,
    );

    if (mode == GameMode.cableMaster) {
      _keepInsidePracticeArena();
      _cameraX = 0;
    } else {
      _cameraX = math.max(0.0, player.position.x - _width * .34).toDouble();
      _generateAhead();
      _difficulty = 1 + _elapsed / 42;
      _distance = math.max(_distance, player.position.x - _width * .24).toDouble();
      if (player.position.x >= _lastScoreGate) {
        _score += (35 + _difficulty * 5).round();
        _lastScoreGate += _width * .78;
      }
      _score = math.max(_score, (_distance / 11).floor()).toInt();
      _checkEnemyLineCrossing();
      _checkHazards();
      if (mode == GameMode.swingMaster) _keepBetweenRails();
      if (player.position.y > _height + 130) {
        if (mode == GameMode.survival) {
          _takeHit();
        } else {
          _finishRun();
        }
      }
    }

    _enemies.removeWhere((e) => mode != GameMode.cableMaster && e.position.x < _cameraX - 160);
    for (final anchor in _anchors) {
      anchor.pulse += dt * (anchor.kind == AnchorKind.boost ? 3.4 : 2.1);
    }
    if (_anchors.isNotEmpty) {
      _anchors.removeWhere((a) => mode != GameMode.cableMaster && a.position.x < _cameraX - 120);
    }
  }

  void _keepBetweenRails() {
    final r = player.radius;
    if (player.position.y < r + 18) {
      player.position.y = r + 18;
      player.velocity.y = player.velocity.y.abs() * .82;
    }
    if (player.position.y > _height - r - 18) {
      player.position.y = _height - r - 18;
      player.velocity.y = -player.velocity.y.abs() * .82;
    }
  }

  void _keepInsidePracticeArena() {
    final r = player.radius;
    if (player.position.x < r || player.position.x > _width - r) {
      player.position.x = player.position.x.clamp(r, _width - r).toDouble();
      player.velocity.x *= -0.78;
    }
    if (player.position.y < r) {
      player.position.y = r;
      player.velocity.y = player.velocity.y.abs() * .65;
    }
    if (player.position.y > _height - r) {
      player.position.y = _height - r;
      player.velocity.y = -math.max(280.0, player.velocity.y.abs() * .68).toDouble();
      _attached = null;
      _ropeLength = 0;
    }
  }

  void _generateAhead() {
    final lastX = _anchors.isEmpty ? _cameraX : _anchors.last.position.x;
    if (lastX > _cameraX + _width * 2.3) return;
    const yPattern = <double>[.24, .49, .31, .66, .22, .44, .59, .29];
    while ((_anchors.isEmpty ? _cameraX : _anchors.last.position.x) <= _cameraX + _width * 2.3) {
      _anchorIndex++;
      final step = math.min(350.0, _width * (.47 + math.min(.05, _difficulty * .008))).toDouble();
      final previous = _anchors.isEmpty ? null : _anchors.last.position;
      final x = ((previous?.x ?? (_cameraX + _width * .5)) + step).toDouble();
      final targetY = _height * yPattern[_anchorIndex % yPattern.length];
      final previousY = previous?.y ?? _height * .43;
      // Keep every generated anchor within a reliable jump radius, even on
      // unusually tall or wide displays. There is always a reachable route.
      final maxVerticalDelta = math.sqrt(math.max(0.0, 430.0 * 430.0 - step * step)).toDouble();
      final minY = math.max(_height * .2, previousY - maxVerticalDelta).toDouble();
      final maxY = math.min(_height * .78, previousY + maxVerticalDelta).toDouble();
      final y = targetY.clamp(minY, maxY).toDouble();
      final kind = _anchorIndex % 7 == 4
          ? AnchorKind.boost
          : (_anchorIndex % 11 == 8 ? AnchorKind.fragile : AnchorKind.standard);
      _anchors.add(AnchorNode(id: _nextAnchorId++, position: Vector2(x, y), kind: kind));

      if (mode == GameMode.survival || mode == GameMode.swingMaster) {
        if (_anchorIndex % (mode == GameMode.survival ? 2 : 3) == 0) {
          final hazardX = x - step * .43;
          final hazardY = _height * (.37 + ((_anchorIndex % 4) * .105));
          _enemies.add(EnemyHazard(
            position: Vector2(hazardX, hazardY.clamp(_height * .2, _height * .78).toDouble()),
            radius: (17.0 + math.min(8.0, _difficulty * 1.6)).toDouble(),
            phase: _anchorIndex * .77,
            speed: 1.0 + _difficulty * .08,
          ));
        }
      }
    }
  }

  void _checkEnemyLineCrossing() {
    if (_lineScoreCooldown > 0 || _enemies.length < 2) return;
    final p0 = Offset(_previousPlayerX, _previousPlayerY);
    final p1 = Offset(player.position.x, player.position.y);
    for (var i = 0; i < _enemies.length - 1; i++) {
      final a = _enemies[i].currentPosition;
      final b = _enemies[i + 1].currentPosition;
      if ((b.x - a.x).abs() > _width * 1.15) continue;
      if (_segmentsCross(p0, p1, Offset(a.x, a.y), Offset(b.x, b.y))) {
        _score += 45;
        _lineScoreCooldown = .72;
        if (_effectsEnabled) _effects.burst(player.position, NeonPalette.pink, count: 8, speed: 135);
        break;
      }
    }
  }

  bool _segmentsCross(Offset p, Offset p2, Offset q, Offset q2) {
    double orient(Offset a, Offset b, Offset c) =>
        (b.dx - a.dx) * (c.dy - a.dy) - (b.dy - a.dy) * (c.dx - a.dx);
    final o1 = orient(p, p2, q);
    final o2 = orient(p, p2, q2);
    final o3 = orient(q, q2, p);
    final o4 = orient(q, q2, p2);
    const epsilon = 0.0001;
    bool onSegment(Offset a, Offset b, Offset c) =>
        c.dx >= math.min(a.dx, b.dx) - epsilon &&
        c.dx <= math.max(a.dx, b.dx) + epsilon &&
        c.dy >= math.min(a.dy, b.dy) - epsilon &&
        c.dy <= math.max(a.dy, b.dy) + epsilon;
    if (o1 * o2 < 0 && o3 * o4 < 0) return true;
    if (o1.abs() <= epsilon && onSegment(p, p2, q)) return true;
    if (o2.abs() <= epsilon && onSegment(p, p2, q2)) return true;
    if (o3.abs() <= epsilon && onSegment(q, q2, p)) return true;
    if (o4.abs() <= epsilon && onSegment(q, q2, p2)) return true;
    return false;
  }

  void _checkHazards() {
    if (mode == GameMode.cableMaster || player.invulnerable) return;
    for (final enemy in _enemies) {
      final p = enemy.currentPosition;
      final dx = player.position.x - p.x;
      final dy = player.position.y - p.y;
      final minimum = player.radius + enemy.radius;
      if (dx * dx + dy * dy < minimum * minimum) {
        if (mode == GameMode.survival) {
          _takeHit();
        } else {
          _bounceOff(p);
          _score = math.max(0, _score - 15).toInt();
        }
        break;
      }
    }
  }

  void _bounceOff(Vector2 hazard) {
    final dx = player.position.x - hazard.x;
    final dy = player.position.y - hazard.y;
    final len = math.max(1.0, math.sqrt(dx * dx + dy * dy)).toDouble();
    final nx = dx / len;
    final ny = dy / len;
    player.velocity.x += nx * 340 + 115;
    player.velocity.y += ny * 340;
    player.position.x += nx * 12;
    player.position.y += ny * 12;
    player.invulnerable = true;
    player.invulnerabilityTimer = .72;
    _attached = null;
    _ropeLength = 0;
    _hits++;
    onEffect?.call('impact');
    if (_effectsEnabled) _effects.burst(player.position, NeonPalette.red, count: 14, speed: 180);
    if (mode == GameMode.swingMaster && _hits >= 5) _finishRun();
  }

  void _takeHit() {
    if (player.invulnerable || _finished) return;
    _lives--;
    _hits++;
    onEffect?.call('impact');
    _attached = null;
    _ropeLength = 0;
    if (_effectsEnabled) _effects.burst(player.position, NeonPalette.red, count: 18, speed: 210);
    if (_lives <= 0) {
      _finishRun();
      return;
    }
    player.position = Vector2(_cameraX + _width * .28, _height * .38);
    player.velocity = Vector2(190 + _difficulty * 14, -85);
    player.invulnerable = true;
    player.invulnerabilityTimer = 1.35;
  }

  void _finishRun() {
    if (_finished) return;
    _finished = true;
    _paused = true;
    _publishHud();
    onRunEnded(GameResult(score: _score, elapsed: _elapsed, distance: _distance));
  }

  void _publishHud() {
    final speed = math.sqrt(player.velocity.x * player.velocity.x + player.velocity.y * player.velocity.y);
    hud.value = GameHudState(
      score: _score,
      elapsed: _elapsed,
      lives: _lives,
      speed: speed,
      hooked: _attached != null,
      distance: _distance,
      difficulty: _difficulty.floor().clamp(1, 99).toInt(),
    );
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    if (_width <= 0 || _height <= 0) return;
    _drawBackdrop(canvas);
    _drawArenaRails(canvas);
    _drawGuideLines(canvas);
    _drawHazards(canvas);
    _drawAnchors(canvas);
    _drawTrail(canvas);
    _drawTether(canvas);
    _effects.render(canvas, _cameraX, _effectsEnabled);
    final playerPoint = Offset(player.position.x - _cameraX, player.position.y);
    final skinColor = _skinColor();
    final blink = player.invulnerable ? (math.sin(_elapsed * 26).abs() * .6) : 0.0;
    PlayerPainter.draw(canvas, playerPoint, player.radius, skinColor,
        glow: _effectsEnabled ? 1 : 0, blink: blink);
    _drawEdgeHints(canvas);
  }

  Color _skinColor() => switch (settings.skin) {
        'pink' => NeonPalette.pink,
        'violet' => NeonPalette.violet,
        'blue' => NeonPalette.blue,
        _ => NeonPalette.cyan,
      };

  void _drawBackdrop(Canvas canvas) {
    final rect = Rect.fromLTWH(0, 0, _width, _height);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF080E1C), Color(0xFF070A13), Color(0xFF111024)],
        ).createShader(rect),
    );
    final gridPaint = Paint()
      ..color = const Color(0xFF263450).withOpacity(.18)
      ..strokeWidth = .65;
    const spacing = 44.0;
    final offset = -(_cameraX % spacing);
    for (var x = offset; x < _width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, _height), gridPaint);
    }
    for (var y = 0.0; y < _height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(_width, y), gridPaint);
    }
    final starPaint = Paint()..color = const Color(0xFFB2D8FF).withOpacity(.27);
    for (final star in _stars) {
      final sx = (star.dx - (_cameraX * .14)) % _width;
      canvas.drawCircle(Offset(sx < 0 ? sx + _width : sx, star.dy), 1.15, starPaint);
    }
    final vignette = Paint()
      ..shader = ui.Gradient.radial(
        Offset(_width * .5, _height * .47),
        math.max(_width, _height).toDouble() * .76,
        [Colors.transparent, const Color(0xCC02040B)],
        [.45, 1],
      );
    canvas.drawRect(rect, vignette);
  }

  void _drawArenaRails(Canvas canvas) {
    if (mode == GameMode.survival) return;
    final color = mode == GameMode.cableMaster ? NeonPalette.cyan : NeonPalette.blue;
    final rect = mode == GameMode.cableMaster
        ? Rect.fromLTWH(7, 7, _width - 14, _height - 14)
        : Rect.fromLTWH(0, 18, _width, _height - 36);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, Radius.circular(mode == GameMode.cableMaster ? 18 : 0)), Paint()
      ..color = color.withOpacity(.34)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5);
  }

  void _drawGuideLines(Canvas canvas) {
    if (_anchors.length < 2) return;
    final path = Path();
    for (var i = 0; i < _anchors.length - 1; i++) {
      final a = _anchors[i].position;
      final b = _anchors[i + 1].position;
      final ax = a.x - _cameraX;
      final bx = b.x - _cameraX;
      if (bx < -40 || ax > _width + 40) continue;
      path.moveTo(ax, a.y);
      path.lineTo(bx, b.y);
    }
    canvas.drawPath(path, Paint()
      ..color = const Color(0xFF3A6385).withOpacity(.18)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke);
  }

  void _drawAnchors(Canvas canvas) {
    for (final anchor in _anchors) {
      final x = anchor.position.x - _cameraX;
      if (x < -50 || x > _width + 50) continue;
      final center = Offset(x, anchor.position.y);
      final color = switch (anchor.kind) {
        AnchorKind.boost => NeonPalette.pink,
        AnchorKind.fragile => NeonPalette.violet,
        AnchorKind.standard => NeonPalette.cyan,
      };
      final pulse = .5 + .5 * math.sin(anchor.pulse);
      if (_effectsEnabled) {
        canvas.drawCircle(center, 18 + pulse * 5, Paint()
          ..color = color.withOpacity(.08)
          ..maskFilter = const ui.MaskFilter.blur(ui.BlurStyle.normal, 9));
      }
      canvas.drawCircle(center, 10 + pulse * 2, Paint()
        ..color = color.withOpacity(.14)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2);
      canvas.drawCircle(center, 5.8, Paint()..color = color.withOpacity(.95));
      canvas.drawCircle(center, 2.0, Paint()..color = Colors.white);
    }
  }

  void _drawHazards(Canvas canvas) {
    // Red enemy-to-enemy beams are score lines: crossing one cleanly awards points.
    for (var i = 0; i < _enemies.length - 1; i++) {
      final a = _enemies[i].currentPosition;
      final b = _enemies[i + 1].currentPosition;
      final ax = a.x - _cameraX;
      final bx = b.x - _cameraX;
      if ((bx - ax).abs() <= _width * 1.15 && bx > -30 && ax < _width + 30) {
        if (_effectsEnabled) {
          canvas.drawLine(Offset(ax, a.y), Offset(bx, b.y), Paint()
            ..color = NeonPalette.red.withOpacity(.11)
            ..strokeWidth = 5
            ..maskFilter = const ui.MaskFilter.blur(ui.BlurStyle.normal, 5));
        }
        canvas.drawLine(Offset(ax, a.y), Offset(bx, b.y), Paint()
          ..color = NeonPalette.red.withOpacity(.28)
          ..strokeWidth = 1.1);
      }
    }
    for (final enemy in _enemies) {
      final p = enemy.currentPosition;
      final x = p.x - _cameraX;
      if (x < -45 || x > _width + 45) continue;
      final center = Offset(x, p.y);
      if (_effectsEnabled) {
        canvas.drawCircle(center, enemy.radius * 1.8, Paint()
          ..color = NeonPalette.red.withOpacity(.12)
          ..maskFilter = const ui.MaskFilter.blur(ui.BlurStyle.normal, 13));
      }
      canvas.drawCircle(center, enemy.radius, Paint()
        ..color = const Color(0xFF301421)
        ..style = PaintingStyle.fill);
      canvas.drawCircle(center, enemy.radius, Paint()
        ..color = NeonPalette.red.withOpacity(.86)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8);
      canvas.drawCircle(center, enemy.radius * .35, Paint()..color = NeonPalette.red);
      canvas.drawCircle(center, 2.2, Paint()..color = Colors.white);
    }
  }

  void _drawTrail(Canvas canvas) {
    for (var i = 0; i < _trail.length; i++) {
      final point = _trail[i];
      final ratio = (point.life / .42).clamp(0.0, 1.0).toDouble();
      final center = Offset(point.position.x - _cameraX, point.position.y);
      canvas.drawCircle(center, 1.5 + ratio * 2.5, Paint()
        ..color = _skinColor().withOpacity(ratio * .42));
    }
  }

  void _drawTether(Canvas canvas) {
    final anchor = _attached;
    if (anchor == null) return;
    final a = Offset(anchor.position.x - _cameraX, anchor.position.y);
    final b = Offset(player.position.x - _cameraX, player.position.y);
    final color = anchor.kind == AnchorKind.boost ? NeonPalette.pink : NeonPalette.cyan;
    if (_effectsEnabled) {
      canvas.drawLine(a, b, Paint()
        ..color = color.withOpacity(.26)
        ..strokeWidth = 8
        ..maskFilter = const ui.MaskFilter.blur(ui.BlurStyle.normal, 7));
    }
    canvas.drawLine(a, b, Paint()
      ..color = color.withOpacity(.96)
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round);
    canvas.drawCircle(a, 7.8, Paint()
      ..color = color.withOpacity(.2)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4);
  }

  void _drawEdgeHints(Canvas canvas) {
    if (mode == GameMode.cableMaster) return;
    AnchorNode? target;
    for (final candidate in _anchors) {
      if (candidate.position.x > player.position.x + 15) { target = candidate; break; }
    }
    if (target == null) return;
    final dx = target.position.x - _cameraX;
    if (dx > _width - 18) {
      final y = target.position.y.clamp(42.0, _height - 42.0).toDouble();
      final path = Path()
        ..moveTo(_width - 18, y)
        ..lineTo(_width - 29, y - 8)
        ..lineTo(_width - 29, y + 8)
        ..close();
      canvas.drawPath(path, Paint()..color = NeonPalette.cyan.withOpacity(.55));
    }
  }
}
