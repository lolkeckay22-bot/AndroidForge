import 'dart:math' as math;
import 'dart:ui';
import 'package:flame/components.dart';

class NeonParticle {
  NeonParticle(this.position, this.velocity, this.life, this.maxLife, this.color);
  Vector2 position;
  Vector2 velocity;
  double life;
  final double maxLife;
  final Color color;
}

/// Reuses a bounded particle array. No per-frame object churn after warm-up.
class EffectPool {
  EffectPool({this.capacity = 64}) : particles = List<NeonParticle?>.filled(capacity, null);

  final int capacity;
  final List<NeonParticle?> particles;
  int _cursor = 0;

  void burst(Vector2 origin, Color color, {int count = 10, double speed = 190}) {
    for (var i = 0; i < count; i++) {
      final angle = (i / count) * 6.2831853;
      final velocity = Vector2(math.cos(angle) * speed, math.sin(angle) * speed);
      particles[_cursor] = NeonParticle(origin.clone(), velocity, 0.44, 0.44, color);
      _cursor = (_cursor + 1) % capacity;
    }
  }

  void update(double dt) {
    for (var i = 0; i < capacity; i++) {
      final p = particles[i];
      if (p == null || p.life <= 0) continue;
      p.life -= dt;
      p.position.x += p.velocity.x * dt;
      p.position.y += p.velocity.y * dt;
      final damping = math.pow(0.94, dt * 60).toDouble();
      p.velocity.x *= damping;
      p.velocity.y *= damping;
    }
  }

  void render(Canvas canvas, double cameraX, bool highQuality) {
    for (var i = 0; i < capacity; i++) {
      final p = particles[i];
      if (p == null || p.life <= 0) continue;
      final alpha = (p.life / p.maxLife).clamp(0.0, 1.0).toDouble();
      final pos = Offset(p.position.x - cameraX, p.position.y);
      final radius = (1.2 + 2.4 * alpha) * (highQuality ? 1.0 : 0.8);
      canvas.drawCircle(pos, radius, Paint()..color = p.color.withOpacity(alpha));
    }
  }
}

