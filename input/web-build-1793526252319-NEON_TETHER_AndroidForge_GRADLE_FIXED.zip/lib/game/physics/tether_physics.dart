import 'dart:math' as math;
import 'package:flame/components.dart';
import 'player_body.dart';

/// Deterministic fixed-step pendulum solver. The cable is a unilateral distance
/// constraint: it can go slack, but can never stretch beyond its current length.
class TetherPhysics {
  TetherPhysics({this.gravity = 880, this.airDrag = 0.035});

  final double gravity;
  final double airDrag;

  void step({
    required PlayerBody body,
    required double dt,
    Vector2? anchor,
    double? ropeLength,
  }) {
    body.velocity.y += gravity * dt;

    // Integrate free-flight first; constraint projection below converts the
    // motion into a pendulum while preserving tangential velocity.
    body.position.x += body.velocity.x * dt;
    body.position.y += body.velocity.y * dt;

    if (anchor != null && ropeLength != null) {
      final dx = body.position.x - anchor.x;
      final dy = body.position.y - anchor.y;
      final distance = math.sqrt(dx * dx + dy * dy);
      final nextLength = ropeLength.clamp(86.0, 460.0).toDouble();
      if (distance > nextLength && distance > 0.0001) {
        final nx = dx / distance;
        final ny = dy / distance;
        body.position
          ..x = anchor.x + nx * nextLength
          ..y = anchor.y + ny * nextLength;

        // Remove only outward radial velocity. Inward/tangential momentum stays.
        final radialSpeed = body.velocity.x * nx + body.velocity.y * ny;
        if (radialSpeed > 0) {
          body.velocity.x -= nx * radialSpeed;
          body.velocity.y -= ny * radialSpeed;
        }
      }
    }

    final dragFactor = (1 - airDrag * dt).clamp(0.0, 1.0).toDouble();
    body.velocity.x *= dragFactor;
    body.velocity.y *= dragFactor;

    // Numerical safety cap; normal play remains below this threshold.
    final speedSquared = body.velocity.x * body.velocity.x + body.velocity.y * body.velocity.y;
    const maxSpeed = 1250.0;
    if (speedSquared > maxSpeed * maxSpeed) {
      final scale = maxSpeed / math.sqrt(speedSquared);
      body.velocity.x *= scale;
      body.velocity.y *= scale;
    }
  }
}

