import 'package:flame/components.dart';

class PlayerBody {
  PlayerBody({required this.position, required this.velocity});

  Vector2 position;
  Vector2 velocity;
  double radius = 11;
  bool invulnerable = false;
  double invulnerabilityTimer = 0;
}
