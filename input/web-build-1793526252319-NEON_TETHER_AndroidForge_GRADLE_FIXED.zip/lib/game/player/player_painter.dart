import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../../core/palette.dart';

class PlayerPainter {
  static void draw(Canvas canvas, Offset center, double radius, Color color,
      {double glow = 1, double blink = 0}) {
    final c = color.withOpacity((1 - blink * 0.55).clamp(0.2, 1.0).toDouble());
    if (glow > 0) {
      canvas.drawCircle(
        center,
        radius * 2.9,
        Paint()
          ..color = c.withOpacity(0.09 * glow)
          ..maskFilter = const ui.MaskFilter.blur(ui.BlurStyle.normal, 20),
      );
      canvas.drawCircle(
        center,
        radius * 1.65,
        Paint()
          ..color = c.withOpacity(0.2 * glow)
          ..maskFilter = const ui.MaskFilter.blur(ui.BlurStyle.normal, 8),
      );
    }
    canvas.drawCircle(center, radius, Paint()..color = const Color(0xFF07101C));
    canvas.drawCircle(
      center,
      radius * 0.78,
      Paint()
        ..color = c
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2,
    );
    final path = Path()
      ..moveTo(center.dx, center.dy - radius * 0.5)
      ..lineTo(center.dx + radius * 0.5, center.dy)
      ..lineTo(center.dx, center.dy + radius * 0.5)
      ..lineTo(center.dx - radius * 0.5, center.dy)
      ..close();
    canvas.drawPath(path, Paint()..color = NeonPalette.white);
    canvas.drawCircle(center, radius * 0.16, Paint()..color = c);
  }
}
