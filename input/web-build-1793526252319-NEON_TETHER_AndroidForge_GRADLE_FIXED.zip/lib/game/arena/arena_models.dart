import 'package:flame/components.dart';

enum AnchorKind { standard, boost, fragile }

class AnchorNode {
  AnchorNode({required this.id, required this.position, this.kind = AnchorKind.standard});
  final int id;
  final Vector2 position;
  final AnchorKind kind;
  double pulse = 0;
}

class Hazard {
  Hazard({required this.position, required this.radius, this.velocityX = 0});
  final Vector2 position;
  final double radius;
  final double velocityX;
}

class TrailPoint {
  TrailPoint(this.position, this.life);
  final Vector2 position;
  double life;
}
