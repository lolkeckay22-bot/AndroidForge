import 'package:flutter/material.dart';
import '../core/palette.dart';
import '../settings/game_settings.dart';
import '../statistics/game_statistics.dart';
import 'neon_backdrop.dart';

class CustomizationScreen extends StatefulWidget {
  const CustomizationScreen({super.key, required this.settings, required this.stats});
  final GameSettings settings;
  final GameStatistics stats;

  @override
  State<CustomizationScreen> createState() => _CustomizationScreenState();
}

class _CustomizationScreenState extends State<CustomizationScreen> {
  final _skins = const <(String, String, Color, int)>[
    ('cyan', 'ION CYAN', NeonPalette.cyan, 0),
    ('pink', 'PULSE PINK', NeonPalette.pink, 0),
    ('blue', 'VECTOR BLUE', NeonPalette.blue, 1000),
    ('violet', 'NOVA VIOLET', NeonPalette.violet, 2500),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: NeonPalette.background,
        appBar: AppBar(title: const Text('CUSTOMIZATION', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 14)), backgroundColor: Colors.transparent, foregroundColor: NeonPalette.white, elevation: 0),
        body: NeonBackdrop(child: SafeArea(top: false, child: ListView(padding: const EdgeInsets.all(20), children: [
          const Text('CORE COLOR', style: TextStyle(color: NeonPalette.muted, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 2)),
          const SizedBox(height: 12),
          for (final skin in _skins) _skinTile(skin),
          const SizedBox(height: 12),
          const Text('Некоторые цвета открываются за общий набранный счёт. Прогресс сохраняется локально.', style: TextStyle(color: NeonPalette.muted, fontSize: 11, height: 1.4)),
        ]))),
      );

  Widget _skinTile((String, String, Color, int) skin) {
    final (id, label, color, unlockScore) = skin;
    final unlocked = widget.stats.totalScore >= unlockScore;
    final selected = widget.settings.skin == id;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: unlocked ? () async { setState(() => widget.settings.skin = id); await widget.settings.save(); } : null,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: NeonPalette.surface.withOpacity(.9), borderRadius: BorderRadius.circular(16), border: Border.all(color: selected ? color.withOpacity(.8) : color.withOpacity(.22))),
          child: Row(children: [
            Container(width: 42, height: 42, decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(.15), border: Border.all(color: color, width: 2), boxShadow: [BoxShadow(color: color.withOpacity(.18), blurRadius: 12)]), child: Icon(Icons.brightness_1_rounded, size: 13, color: color)),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: NeonPalette.white, fontWeight: FontWeight.w900, letterSpacing: 1)), const SizedBox(height: 3), Text(unlocked ? (selected ? 'ACTIVE' : 'UNLOCKED') : 'Нужно набрать $unlockScore очков', style: TextStyle(color: unlocked ? color : NeonPalette.muted, fontSize: 10, fontWeight: FontWeight.w700))])),
            Icon(unlocked ? (selected ? Icons.check_circle_rounded : Icons.circle_outlined) : Icons.lock_outline_rounded, color: unlocked ? color : NeonPalette.muted),
          ]),
        ),
      ),
    );
  }
}
