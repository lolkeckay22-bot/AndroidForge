import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../audio/audio_service.dart';
import '../core/game_mode.dart';
import '../core/palette.dart';
import '../game/neon_tether_game.dart';
import '../settings/game_settings.dart';
import '../statistics/game_statistics.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.mode, required this.settings, required this.audio, required this.stats});
  final GameMode mode;
  final GameSettings settings;
  final AudioService audio;
  final GameStatistics stats;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late final NeonTetherGame _game;
  late GameStatistics _stats = widget.stats;
  bool _resultDialogShown = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _game = NeonTetherGame(
      mode: widget.mode,
      settings: widget.settings,
      onRunEnded: _handleRunEnded,
      onEffect: (name) => widget.audio.play(name),
    );
  }

  @override
  void dispose() {
    _game.disposeHud();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _handleRunEnded(GameResult result) {
    if (_resultDialogShown) return;
    _resultDialogShown = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final modeKey = widget.mode == GameMode.swingMaster ? 'swing' : 'survival';
      _stats = await _stats.record(mode: modeKey, score: result.score, distance: result.distance);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => _ResultDialog(
          result: result,
          best: widget.mode == GameMode.swingMaster ? _stats.bestSwing : _stats.bestSurvival,
          onReplay: () {
            _game.restart();
            _resultDialogShown = false;
            Navigator.of(dialogContext).pop();
          },
          onMenu: () {
            Navigator.of(dialogContext).pop();
            Navigator.of(context).pop();
          },
        ),
      );
    });
  }

  Future<void> _pause() async {
    if (_game.isFinished || _game.isPaused) return;
    _game.pause();
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => _PauseDialog(
        onResume: () {
          _game.resume();
          Navigator.of(dialogContext).pop();
        },
        onRestart: () {
          _game.restart();
          Navigator.of(dialogContext).pop();
        },
        onMenu: () {
          Navigator.of(dialogContext).pop();
          Navigator.of(context).pop();
        },
      ),
    );
  }

  Future<bool> _handleBack() async {
    await _pause();
    return false;
  }

  @override
  Widget build(BuildContext context) => WillPopScope(
        onWillPop: _handleBack,
        child: Scaffold(
          backgroundColor: NeonPalette.background,
          body: Stack(
            fit: StackFit.expand,
            children: [
              Listener(
                behavior: HitTestBehavior.opaque,
                onPointerDown: (event) => _game.pointerDown(event.localPosition),
                onPointerMove: (event) => _game.pointerMove(event.localPosition),
                onPointerUp: (_) => _game.pointerUp(),
                onPointerCancel: (_) => _game.pointerUp(),
                child: GameWidget<NeonTetherGame>(game: _game),
              ),
              SafeArea(
                child: Column(
                  children: [
                    _HudBar(game: _game, mode: widget.mode, onPause: _pause, onRestart: _game.restart),
                    const Spacer(),
                    IgnorePointer(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(28, 0, 28, 16),
                        child: Column(children: [
                          ValueListenableBuilder<GameHudState>(
                            valueListenable: _game.hud,
                            builder: (_, hud, __) => Text(
                              hud.hooked ? 'TETHER LOCKED  •  УДЕРЖИВАЙ УЗЕЛ' : 'КАСАНИЕ ПО УЗЛУ — ЗАЦЕПИТЬСЯ  /  ОТПУСТИ — ПОЛЕТЕТЬ',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: hud.hooked ? NeonPalette.cyan : NeonPalette.muted, fontSize: 8.5, fontWeight: FontWeight.w900, letterSpacing: 1.15, shadows: const [Shadow(color: Colors.black, blurRadius: 8)]),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(height: 1, width: 72, color: NeonPalette.cyan.withOpacity(.35)),
                        ]),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}

class _HudBar extends StatelessWidget {
  const _HudBar({required this.game, required this.mode, required this.onPause, required this.onRestart});
  final NeonTetherGame game;
  final GameMode mode;
  final VoidCallback onPause;
  final VoidCallback onRestart;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(13, 10, 13, 0),
        child: Row(children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
              decoration: BoxDecoration(color: const Color(0xD10A1222), borderRadius: BorderRadius.circular(13), border: Border.all(color: NeonPalette.blue.withOpacity(.28))),
              child: ValueListenableBuilder<GameHudState>(
                valueListenable: game.hud,
                builder: (_, hud, __) => Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(mode.title, style: const TextStyle(color: NeonPalette.cyan, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
                    const SizedBox(height: 4),
                    Text(mode == GameMode.cableMaster ? 'PRACTICE' : 'SCORE  ${hud.score}', style: const TextStyle(color: NeonPalette.white, fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: .6)),
                  ])),
                  Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text(_formatTime(hud.elapsed), style: const TextStyle(color: NeonPalette.white, fontSize: 13, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 5),
                    if (mode == GameMode.survival)
                      Row(children: List.generate(3, (index) => Padding(padding: const EdgeInsets.only(left: 3), child: Icon(Icons.favorite_rounded, size: 11, color: index < hud.lives ? NeonPalette.pink : const Color(0xFF374052)))))
                    else
                      Text('${hud.speed.round()} u/s', style: const TextStyle(color: NeonPalette.muted, fontSize: 9, fontWeight: FontWeight.w800)),
                  ]),
                ]),
              ),
            ),
          ),
          const SizedBox(width: 8),
          _HudButton(icon: Icons.refresh_rounded, onTap: onRestart, color: NeonPalette.pink),
          const SizedBox(width: 7),
          _HudButton(icon: Icons.pause_rounded, onTap: onPause, color: NeonPalette.cyan),
        ]),
      );

  static String _formatTime(double seconds) {
    final total = seconds.floor();
    final minutes = (total ~/ 60).toString().padLeft(2, '0');
    final secs = (total % 60).toString().padLeft(2, '0');
    return '$minutes:$secs';
  }
}

class _HudButton extends StatelessWidget {
  const _HudButton({required this.icon, required this.onTap, required this.color});
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(width: 42, height: 43, decoration: BoxDecoration(color: const Color(0xDD0D1728), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(.38))), child: Icon(icon, color: color, size: 19)),
      );
}

class _PauseDialog extends StatelessWidget {
  const _PauseDialog({required this.onResume, required this.onRestart, required this.onMenu});
  final VoidCallback onResume;
  final VoidCallback onRestart;
  final VoidCallback onMenu;
  @override
  Widget build(BuildContext context) => _ArcadeDialog(
        eyebrow: 'SESSION PAUSED',
        title: 'PAUSE',
        accent: NeonPalette.cyan,
        actions: [
          _DialogButton(label: 'CONTINUE', icon: Icons.play_arrow_rounded, color: NeonPalette.cyan, onTap: onResume),
          _DialogButton(label: 'RESTART', icon: Icons.refresh_rounded, color: NeonPalette.pink, onTap: onRestart),
          _DialogButton(label: 'MAIN MENU', icon: Icons.home_rounded, color: NeonPalette.violet, onTap: onMenu),
        ],
      );
}

class _ResultDialog extends StatelessWidget {
  const _ResultDialog({required this.result, required this.best, required this.onReplay, required this.onMenu});
  final GameResult result;
  final int best;
  final VoidCallback onReplay;
  final VoidCallback onMenu;
  @override
  Widget build(BuildContext context) => _ArcadeDialog(
        eyebrow: 'RUN COMPLETE',
        title: 'SIGNAL LOST',
        accent: NeonPalette.pink,
        extra: Column(children: [
          Text(result.score.toString(), style: const TextStyle(color: NeonPalette.white, fontSize: 45, fontWeight: FontWeight.w900, height: 1)),
          const Text('FINAL SCORE', style: TextStyle(color: NeonPalette.muted, letterSpacing: 2, fontSize: 9, fontWeight: FontWeight.w900)),
          const SizedBox(height: 16),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _ResultMetric(label: 'TIME', value: '${result.elapsed.floor()}s'),
            _ResultMetric(label: 'DISTANCE', value: '${(result.distance / 1000).toStringAsFixed(2)} km'),
            _ResultMetric(label: 'BEST', value: best.toString()),
          ]),
          const SizedBox(height: 18),
        ]),
        actions: [
          _DialogButton(label: 'PLAY AGAIN', icon: Icons.replay_rounded, color: NeonPalette.cyan, onTap: onReplay),
          _DialogButton(label: 'MAIN MENU', icon: Icons.home_rounded, color: NeonPalette.violet, onTap: onMenu),
        ],
      );
}

class _ResultMetric extends StatelessWidget {
  const _ResultMetric({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Column(children: [Text(value, style: const TextStyle(color: NeonPalette.white, fontSize: 15, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(label, style: const TextStyle(color: NeonPalette.muted, fontSize: 8, fontWeight: FontWeight.w800, letterSpacing: 1))]);
}

class _ArcadeDialog extends StatelessWidget {
  const _ArcadeDialog({required this.eyebrow, required this.title, required this.accent, required this.actions, this.extra});
  final String eyebrow;
  final String title;
  final Color accent;
  final List<Widget> actions;
  final Widget? extra;
  @override
  Widget build(BuildContext context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 20),
          decoration: BoxDecoration(color: const Color(0xFF10192A), borderRadius: BorderRadius.circular(24), border: Border.all(color: accent.withOpacity(.5)), boxShadow: [BoxShadow(color: accent.withOpacity(.12), blurRadius: 30)]),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 36, height: 3, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(4))),
            const SizedBox(height: 19),
            Text(eyebrow, style: TextStyle(color: accent, fontSize: 9, letterSpacing: 2.2, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(title, style: const TextStyle(color: NeonPalette.white, fontSize: 26, letterSpacing: 2, fontWeight: FontWeight.w900)),
            if (extra != null) ...[const SizedBox(height: 17), extra!],
            for (final action in actions) Padding(padding: const EdgeInsets.only(top: 9), child: action),
          ]),
        ),
      );
}

class _DialogButton extends StatelessWidget {
  const _DialogButton({required this.label, required this.icon, required this.color, required this.onTap});
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        height: 47,
        child: OutlinedButton.icon(
          onPressed: onTap,
          icon: Icon(icon, size: 18),
          label: Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          style: OutlinedButton.styleFrom(foregroundColor: color, side: BorderSide(color: color.withOpacity(.5)), backgroundColor: color.withOpacity(.07), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))),
        ),
      );
}
