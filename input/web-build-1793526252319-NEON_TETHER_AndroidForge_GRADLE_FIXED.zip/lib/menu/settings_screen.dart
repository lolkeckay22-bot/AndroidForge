import 'package:flutter/material.dart';
import '../audio/audio_service.dart';
import '../core/frame_rate_service.dart';
import '../core/palette.dart';
import '../settings/game_settings.dart';
import 'neon_backdrop.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.settings, required this.audio});
  final GameSettings settings;
  final AudioService audio;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  GameSettings get s => widget.settings;

  Future<void> _save() async => s.save();

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: NeonPalette.background,
        appBar: AppBar(title: const Text('SETTINGS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 14)), backgroundColor: Colors.transparent, foregroundColor: NeonPalette.white, elevation: 0),
        body: NeonBackdrop(child: SafeArea(top: false, child: ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 30), children: [
          _Group(title: 'AUDIO', child: Column(children: [
            Row(children: [const Icon(Icons.volume_up_rounded, color: NeonPalette.cyan), const SizedBox(width: 10), const Expanded(child: Text('Master volume', style: TextStyle(color: NeonPalette.white, fontWeight: FontWeight.w700))), Text('${(s.masterVolume * 100).round()}%', style: const TextStyle(color: NeonPalette.cyan, fontWeight: FontWeight.w900))]),
            Slider(value: s.masterVolume, onChanged: (v) { setState(() => s.masterVolume = v); _save(); }, onChangeEnd: (_) => widget.audio.syncMusic(), activeColor: NeonPalette.cyan, inactiveColor: NeonPalette.surfaceLight),
            _ToggleRow(title: 'Music', subtitle: 'Фоновая музыка', value: s.musicEnabled, onChanged: (v) { setState(() => s.musicEnabled = v); _save(); widget.audio.syncMusic(); }),
            _ToggleRow(title: 'Sound effects', subtitle: 'Зацепление, отпускание и столкновения', value: s.sfxEnabled, onChanged: (v) { setState(() => s.sfxEnabled = v); _save(); }),
          ])),
          const SizedBox(height: 14),
          _Group(title: 'VISUALS', child: Column(children: [
            _ToggleRow(title: 'High quality effects', subtitle: 'Свечение, частицы и мягкие следы', value: s.highEffects, onChanged: (v) { setState(() => s.highEffects = v); _save(); }),
          ])),
          const SizedBox(height: 14),
          _Group(title: 'CONTROLS', child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const Expanded(child: Text('Sensitivity', style: TextStyle(color: NeonPalette.white, fontWeight: FontWeight.w700))), Text('${s.sensitivity.toStringAsFixed(1)}×', style: const TextStyle(color: NeonPalette.cyan, fontWeight: FontWeight.w900))]),
            Slider(value: s.sensitivity, min: .6, max: 1.6, divisions: 10, onChanged: (v) { setState(() => s.sensitivity = v); _save(); }, activeColor: NeonPalette.cyan, inactiveColor: NeonPalette.surfaceLight),
            const Text('Выбор узла определяется точностью касания; чувствительность влияет на допуск выбора рядом с точкой.', style: TextStyle(color: NeonPalette.muted, fontSize: 11, height: 1.4)),
          ])),
          const SizedBox(height: 14),
          _Group(title: 'FRAME RATE', child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Preferred display refresh', style: TextStyle(color: NeonPalette.white, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            SegmentedButton<int>(
              segments: const [ButtonSegment(value: 60, label: Text('60 Hz')), ButtonSegment(value: 90, label: Text('90 Hz')), ButtonSegment(value: 120, label: Text('120 Hz'))],
              selected: {s.targetFps},
              onSelectionChanged: (v) { setState(() => s.targetFps = v.first); _save(); FrameRateService.apply(s.targetFps); },
              style: ButtonStyle(foregroundColor: WidgetStateProperty.all(NeonPalette.white), backgroundColor: WidgetStateProperty.resolveWith((states) => states.contains(WidgetState.selected) ? NeonPalette.cyan.withOpacity(.18) : NeonPalette.surface), side: WidgetStateProperty.all(const BorderSide(color: Color(0x5548D8F4))), textStyle: WidgetStateProperty.all(const TextStyle(fontSize: 11, fontWeight: FontWeight.w800))),
            ),
            const SizedBox(height: 8),
            const Text('Физика всегда рассчитывается с фиксированным шагом 120 Гц. Android получает запрос предпочтительной частоты; доступный режим и фактическую частоту выбирает система.', style: TextStyle(color: NeonPalette.muted, fontSize: 11, height: 1.4)),
          ])),
          const SizedBox(height: 24),
          const Center(child: Text('НАСТРОЙКИ СОХРАНЯЮТСЯ АВТОМАТИЧЕСКИ', style: TextStyle(color: NeonPalette.muted, fontSize: 9, letterSpacing: 1.0))),
        ]))),
      );
}

class _Group extends StatelessWidget {
  const _Group({required this.title, required this.child});
  final String title;
  final Widget child;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: NeonPalette.surface.withOpacity(.9), borderRadius: BorderRadius.circular(18), border: Border.all(color: NeonPalette.blue.withOpacity(.2))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: NeonPalette.cyan, fontSize: 9, letterSpacing: 2, fontWeight: FontWeight.w900)), const SizedBox(height: 13), child]),
      );
}

class _ToggleRow extends StatelessWidget {
  const _ToggleRow({required this.title, required this.subtitle, required this.value, required this.onChanged});
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: NeonPalette.white, fontWeight: FontWeight.w700, fontSize: 13)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: NeonPalette.muted, fontSize: 10))])), Switch(value: value, onChanged: onChanged, activeColor: NeonPalette.cyan, activeTrackColor: NeonPalette.cyan.withOpacity(.3), inactiveTrackColor: NeonPalette.surfaceLight)]),
      );
}
