import 'package:flutter/material.dart';
import '../audio/audio_service.dart';
import '../core/game_mode.dart';
import '../core/palette.dart';
import '../settings/game_settings.dart';
import '../statistics/game_statistics.dart';
import '../ui/neon_button.dart';
import 'customization_screen.dart';
import 'neon_backdrop.dart';
import 'settings_screen.dart';
import 'statistics_screen.dart';
import 'game_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.settings});
  final GameSettings settings;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late final AudioService _audio = AudioService(widget.settings);
  late final AnimationController _pulse = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
  GameStatistics _stats = const GameStatistics();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _stats = await GameStatistics.load();
    await _audio.initialize();
    if (mounted) setState(() {});
  }

  Future<void> _play(GameMode mode) async {
    await _audio.play('ui');
    await _audio.syncMusic();
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => GameScreen(mode: mode, settings: widget.settings, audio: _audio, stats: _stats),
    ));
    _stats = await GameStatistics.load();
    if (mounted) setState(() {});
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => SettingsScreen(settings: widget.settings, audio: _audio)));
    if (mounted) setState(() {});
  }

  Future<void> _openStats() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => StatisticsScreen(stats: _stats)));
  }

  Future<void> _openCustomization() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => CustomizationScreen(settings: widget.settings, stats: _stats),
    ));
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: NeonPalette.background,
        body: NeonBackdrop(
          child: SafeArea(
            child: LayoutBuilder(builder: (context, constraints) {
              return SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(22, 18, 22, 22),
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: constraints.maxHeight - 40),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(children: [
                        const _TopTag(label: 'NEON ARCADE // 01'),
                        const Spacer(),
                        AnimatedBuilder(
                          animation: _pulse,
                          builder: (_, __) => Container(
                            width: 9,
                            height: 9,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: NeonPalette.green.withOpacity(.45 + _pulse.value * .55),
                              boxShadow: [BoxShadow(color: NeonPalette.green.withOpacity(.28 + _pulse.value * .25), blurRadius: 12)],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Text('SYSTEM READY', style: TextStyle(color: NeonPalette.muted, fontSize: 9, letterSpacing: 1.4, fontWeight: FontWeight.w700)),
                      ]),
                      const SizedBox(height: 32),
                      const Text('NEON /', style: TextStyle(color: NeonPalette.cyan, fontSize: 43, height: .95, fontWeight: FontWeight.w900, letterSpacing: 3)),
                      const Text('TETHER', style: TextStyle(color: NeonPalette.white, fontSize: 53, height: 1.0, fontWeight: FontWeight.w900, letterSpacing: 2.8)),
                      const SizedBox(height: 11),
                      const Text('GRAPPLE. SWING. RELEASE.', style: TextStyle(color: NeonPalette.pink, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 2.4)),
                      const SizedBox(height: 25),
                      Container(
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color: const Color(0xB20D1729),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: NeonPalette.blue.withOpacity(.25)),
                        ),
                        child: Row(children: [
                          const Icon(Icons.scatter_plot_rounded, color: NeonPalette.cyan, size: 25),
                          const SizedBox(width: 12),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            const Text('MOMENTUM IS EVERYTHING', style: TextStyle(color: NeonPalette.white, fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: 1.1)),
                            const SizedBox(height: 5),
                            Text('Цепляйся за узел, удерживай маятник и отпускай трос на пике скорости.',
                                style: TextStyle(color: NeonPalette.muted.withOpacity(.95), fontSize: 11, height: 1.35)),
                          ])),
                        ]),
                      ),
                      const SizedBox(height: 23),
                      const _SectionLabel(label: 'SELECT YOUR RUN'),
                      const SizedBox(height: 10),
                      NeonButton(title: 'CABLE MASTER', subtitle: GameMode.cableMaster.subtitle, color: NeonPalette.cyan, icon: Icons.all_inclusive_rounded, onTap: () => _play(GameMode.cableMaster)),
                      const SizedBox(height: 10),
                      NeonButton(title: 'SWING MASTER', subtitle: GameMode.swingMaster.subtitle, color: NeonPalette.pink, icon: Icons.speed_rounded, onTap: () => _play(GameMode.swingMaster)),
                      const SizedBox(height: 10),
                      NeonButton(title: 'SURVIVAL', subtitle: GameMode.survival.subtitle, color: NeonPalette.violet, icon: Icons.favorite_rounded, onTap: () => _play(GameMode.survival)),
                      const SizedBox(height: 22),
                      const _SectionLabel(label: 'PERSONALIZE & TRACK'),
                      const SizedBox(height: 10),
                      Row(children: [
                        Expanded(child: NeonAction(label: 'SETTINGS', icon: Icons.tune_rounded, onTap: _openSettings)),
                        const SizedBox(width: 9),
                        Expanded(child: NeonAction(label: 'STATS', icon: Icons.insights_rounded, onTap: _openStats, color: NeonPalette.pink)),
                        const SizedBox(width: 9),
                        Expanded(child: NeonAction(label: 'SKINS', icon: Icons.palette_outlined, onTap: _openCustomization, color: NeonPalette.violet)),
                      ]),
                      const SizedBox(height: 17),
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        _MiniStat(label: 'BEST SWING', value: _stats.bestSwing.toString()),
                        _MiniStat(label: 'BEST SURVIVAL', value: _stats.bestSurvival.toString()),
                        _MiniStat(label: 'RUNS', value: _stats.totalRuns.toString()),
                      ]),
                      const SizedBox(height: 18),
                      const Center(child: Text('BUILD 1.0  •  OFFLINE ARCADE', style: TextStyle(color: Color(0xFF52617C), fontSize: 9, letterSpacing: 1.5))),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      );
}

class _TopTag extends StatelessWidget {
  const _TopTag({required this.label});
  final String label;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(color: NeonPalette.surface, borderRadius: BorderRadius.circular(7), border: Border.all(color: NeonPalette.blue.withOpacity(.25))),
        child: Text(label, style: const TextStyle(color: NeonPalette.muted, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.1)),
      );
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel({required this.label});
  final String label;
  @override
  Widget build(BuildContext context) => Text(label, style: const TextStyle(color: NeonPalette.muted, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 2.0));
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Column(children: [
        Text(value, style: const TextStyle(color: NeonPalette.white, fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(color: NeonPalette.muted, fontSize: 7.5, letterSpacing: .7, fontWeight: FontWeight.w700)),
      ]);
}
