import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../core/palette.dart';

class NeonBackdrop extends StatelessWidget {
  const NeonBackdrop({super.key, this.child});
  final Widget? child;

  @override
  Widget build(BuildContext context) => Stack(
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF090F20), NeonPalette.background, Color(0xFF100D22)],
              ),
            ),
          ),
          const CustomPaint(painter: _BackdropPainter()),
          if (child != null) child!,
        ],
      );
}

class _BackdropPainter extends CustomPainter {
  const _BackdropPainter();
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = const Color(0xFF39516E).withOpacity(.13)
      ..strokeWidth = .7;
    for (var x = 0.0; x < size.width; x += 38) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (var y = 0.0; y < size.height; y += 38) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final nodes = <Offset>[
      Offset(size.width * .12, size.height * .17),
      Offset(size.width * .78, size.height * .13),
      Offset(size.width * .88, size.height * .53),
      Offset(size.width * .24, size.height * .71),
      Offset(size.width * .66, size.height * .89),
    ];
    final line = Paint()
      ..color = NeonPalette.cyan.withOpacity(.18)
      ..strokeWidth = 1.1;
    for (var i = 0; i < nodes.length - 1; i++) {
      canvas.drawLine(nodes[i], nodes[i + 1], line);
    }
    for (var i = 0; i < nodes.length; i++) {
      final color = i.isEven ? NeonPalette.cyan : NeonPalette.pink;
      canvas.drawCircle(nodes[i], 15, Paint()
        ..color = color.withOpacity(.07)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14));
      canvas.drawCircle(nodes[i], 4, Paint()..color = color.withOpacity(.7));
      canvas.drawCircle(nodes[i], 8, Paint()
        ..color = color.withOpacity(.3)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1);
    }
    final glow = Paint()
      ..shader = RadialGradient(
        colors: [NeonPalette.violet.withOpacity(.12), Colors.transparent],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * .74, size.height * .4),
        radius: math.max(size.width, size.height).toDouble() * .62,
      ));
    canvas.drawRect(Offset.zero & size, glow);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
