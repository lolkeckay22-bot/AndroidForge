import 'package:flutter/material.dart';
import '../core/palette.dart';
import '../statistics/game_statistics.dart';
import 'neon_backdrop.dart';

class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key, required this.stats});
  final GameStatistics stats;
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: NeonPalette.background,
        appBar: AppBar(title: const Text('STATISTICS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 14)), backgroundColor: Colors.transparent, foregroundColor: NeonPalette.white, elevation: 0),
        body: NeonBackdrop(child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
          _StatCard(label: 'SWING MASTER RECORD', value: stats.bestSwing.toString(), icon: Icons.speed_rounded, color: NeonPalette.pink),
          const SizedBox(height: 12),
          _StatCard(label: 'SURVIVAL RECORD', value: stats.bestSurvival.toString(), icon: Icons.favorite_rounded, color: NeonPalette.violet),
          const SizedBox(height: 12),
          Row(children: [Expanded(child: _StatCard(label: 'TOTAL RUNS', value: stats.totalRuns.toString(), icon: Icons.replay_rounded, color: NeonPalette.cyan)), const SizedBox(width: 12), Expanded(child: _StatCard(label: 'TOTAL SCORE', value: stats.totalScore.toString(), icon: Icons.bolt_rounded, color: NeonPalette.blue))]),
          const SizedBox(height: 12),
          _StatCard(label: 'TRAVEL DISTANCE', value: '${(stats.totalDistance / 1000).toStringAsFixed(1)} km', icon: Icons.route_rounded, color: NeonPalette.green),
          const Spacer(),
          const Text('Локальная статистика хранится на этом устройстве.', style: TextStyle(color: NeonPalette.muted, fontSize: 11)),
        ])))),
      );
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.value, required this.icon, required this.color});
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(color: NeonPalette.surface.withOpacity(.92), borderRadius: BorderRadius.circular(17), border: Border.all(color: color.withOpacity(.28))),
        child: Row(children: [Icon(icon, color: color, size: 24), const SizedBox(width: 13), Expanded(child: Text(label, style: const TextStyle(color: NeonPalette.muted, fontSize: 9, letterSpacing: 1.1, fontWeight: FontWeight.w800))), Text(value, style: const TextStyle(color: NeonPalette.white, fontSize: 19, fontWeight: FontWeight.w900))]),
      );
}
