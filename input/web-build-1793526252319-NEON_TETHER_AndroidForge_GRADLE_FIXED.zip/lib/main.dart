import 'package:flutter/material.dart';
import 'core/palette.dart';
import 'core/frame_rate_service.dart';
import 'menu/home_screen.dart';
import 'settings/game_settings.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = await GameSettings.load();
  await FrameRateService.apply(settings.targetFps);
  runApp(NeonTetherApp(settings: settings));
}

class NeonTetherApp extends StatelessWidget {
  const NeonTetherApp({super.key, required this.settings});
  final GameSettings settings;

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NEON / TETHER',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: NeonPalette.background,
          colorScheme: const ColorScheme.dark(primary: NeonPalette.cyan, secondary: NeonPalette.pink, surface: NeonPalette.surface),
          fontFamily: 'Roboto',
          sliderTheme: const SliderThemeData(showValueIndicator: ShowValueIndicator.never),
        ),
        home: HomeScreen(settings: settings),
      );
}
