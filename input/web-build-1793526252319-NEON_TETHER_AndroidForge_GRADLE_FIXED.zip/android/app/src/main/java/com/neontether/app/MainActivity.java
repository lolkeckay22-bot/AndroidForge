package com.neontether.app;

import android.view.WindowManager;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "neon_tether/frame_rate";

    @Override
    public void configureFlutterEngine(FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
                .setMethodCallHandler((call, result) -> {
                    if (!"setFrameRate".equals(call.method)) {
                        result.notImplemented();
                        return;
                    }
                    Integer fps = call.argument("fps");
                    if (fps == null || (fps != 60 && fps != 90 && fps != 120)) {
                        result.error("INVALID_FPS", "Expected 60, 90 or 120", null);
                        return;
                    }
                    WindowManager.LayoutParams params = getWindow().getAttributes();
                    params.preferredRefreshRate = fps.floatValue();
                    getWindow().setAttributes(params);
                    result.success(true);
                });
    }
}
