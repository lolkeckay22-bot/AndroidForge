@echo off
setlocal
set "APP_HOME=%~dp0"
set "WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar"
set "WRAPPER_URL=https://services.gradle.org/distributions/gradle-8.14.3-wrapper.jar"
set "EXPECTED_SHA256=7d3a4ac4de1c32b59bc6a4eb8ecb8e612ccd0cf1ae1e99f66902da64df296172"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=$env:WRAPPER_JAR; $h=(Get-FileHash -Algorithm SHA256 -LiteralPath $p -ErrorAction SilentlyContinue).Hash; if ($h -ne $env:EXPECTED_SHA256) { Invoke-WebRequest -UseBasicParsing -Uri $env:WRAPPER_URL -OutFile ($p + '.download'); $h=(Get-FileHash -Algorithm SHA256 -LiteralPath ($p + '.download')).Hash; if ($h -ne $env:EXPECTED_SHA256) { Remove-Item ($p + '.download') -Force; exit 2 }; Move-Item ($p + '.download') $p -Force }"
if errorlevel 1 exit /b 1
java %JAVA_OPTS% -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
