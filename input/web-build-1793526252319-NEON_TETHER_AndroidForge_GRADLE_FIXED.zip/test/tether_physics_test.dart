import 'package:flame/components.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:neon_tether/game/physics/player_body.dart';
import 'package:neon_tether/game/physics/tether_physics.dart';

void main() {
  group('TetherPhysics', () {
    test('a taut cable never stretches beyond its maximum length', () {
      final body = PlayerBody(position: Vector2(120, 0), velocity: Vector2(0, 0));
      final solver = TetherPhysics(gravity: 900, airDrag: 0);
      final anchor = Vector2(0, 0);

      for (var i = 0; i < 300; i++) {
        solver.step(body: body, dt: 1 / 120, anchor: anchor, ropeLength: 120);
        expect((body.position - anchor).length, lessThanOrEqualTo(120.0001));
      }
    });

    test('gravity creates a swing while tangential momentum is retained', () {
      final body = PlayerBody(position: Vector2(100, 0), velocity: Vector2(0, 0));
      final solver = TetherPhysics(gravity: 500, airDrag: 0);
      final anchor = Vector2.zero();

      for (var i = 0; i < 120; i++) {
        solver.step(body: body, dt: 1 / 120, anchor: anchor, ropeLength: 100);
      }

      expect(body.velocity.length, greaterThan(40));
      expect((body.position - anchor).length, closeTo(100, 0.02));
    });

    test('releasing does not zero the player velocity', () {
      final body = PlayerBody(position: Vector2(0, 0), velocity: Vector2(360, -110));
      final solver = TetherPhysics(gravity: 0, airDrag: 0);
      final before = body.velocity.length;
      solver.step(body: body, dt: 1 / 120);
      expect(body.velocity.length, closeTo(before, 0.001));
      expect(body.position.x, greaterThan(0));
    });
  });
}
