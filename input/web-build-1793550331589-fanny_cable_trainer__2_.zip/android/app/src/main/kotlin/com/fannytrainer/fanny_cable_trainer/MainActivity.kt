package com.fannytrainer.fanny_cable_trainer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
