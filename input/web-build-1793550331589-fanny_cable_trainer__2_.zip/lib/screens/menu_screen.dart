import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../game/fanny_game.dart' show fmtTime;
import '../game/maps.dart';
import '../settings.dart';
import 'game_screen.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  double? _bestRace;
  int? _bestArena;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        _bestRace = p.getDouble('best_race');
        _bestArena = p.getInt('best_arena');
      });
    } catch (_) {}
  }

  Future<void> _play(GameMode m) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => GameScreen(mode: m)),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0E1A1F), Color(0xFF14323C)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 14),
            child: Column(
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'FANNY CABLE TRAINER',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const Text('Звук', style: TextStyle(color: Colors.white70)),
                    Switch(
                      value: Settings.sound,
                      onChanged: (v) async {
                        await Settings.setSound(v);
                        if (mounted) setState(() {});
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: Row(
                    children: [
                      _ModeCard(
                        icon: Icons.park,
                        color: const Color(0xFF66BB6A),
                        title: 'Тренировка',
                        desc: 'Лесная поляна, манекены и свободная практика. Без таймера.',
                        best: null,
                        onTap: () => _play(GameMode.training),
                      ),
                      _ModeCard(
                        icon: Icons.flag,
                        color: const Color(0xFFFFCA28),
                        title: 'Гонка',
                        desc: 'Лабиринт: пролети 8 чекпоинтов как можно быстрее.',
                        best: _bestRace == null ? 'Рекорд: —' : 'Рекорд: ${fmtTime(_bestRace!)}',
                        onTap: () => _play(GameMode.race),
                      ),
                      _ModeCard(
                        icon: Icons.sports_mma,
                        color: const Color(0xFFEF5350),
                        title: 'Арена',
                        desc: 'Колизей: 90 секунд, бей манекены рывками и таранами.',
                        best: _bestArena == null ? 'Рекорд: —' : 'Рекорд: $_bestArena',
                        onTap: () => _play(GameMode.arena),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.desc,
    required this.best,
    required this.onTap,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String desc;
  final String? best;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: color, width: 2),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icon, color: color, size: 34),
                const SizedBox(height: 6),
                Text(
                  title,
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: color),
                ),
                const SizedBox(height: 4),
                Expanded(
                  child: Text(
                    desc,
                    overflow: TextOverflow.fade,
                    style: const TextStyle(fontSize: 13, color: Colors.white70),
                  ),
                ),
                if (best != null)
                  Text(best!, style: const TextStyle(fontSize: 13, color: Colors.white)),
                const SizedBox(height: 6),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Text(
                    'ИГРАТЬ',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
