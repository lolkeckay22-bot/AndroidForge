import 'dart:math' as math;

import 'package:flame/extensions.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../game/fanny_game.dart';
import '../game/maps.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.mode});

  final GameMode mode;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late final FannyGame game;

  @override
  void initState() {
    super.initState();
    game = FannyGame(mode: widget.mode);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) game.setPaused(true);
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            Positioned.fill(child: GameWidget<FannyGame>(game: game)),
            Positioned.fill(
              child: ControlsLayer(
                game: game,
                onExit: () => Navigator.of(context).pop(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ===========================================================================
//  Слой управления + HUD
// ===========================================================================
class ControlsLayer extends StatelessWidget {
  const ControlsLayer({super.key, required this.game, required this.onExit});

  final FannyGame game;
  final VoidCallback onExit;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: LayoutBuilder(
        builder: (context, c) {
          final w = c.maxWidth;
          return Stack(
            children: [
              Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                width: w * 0.45,
                child: JoystickArea(key: const ValueKey('stick'), game: game),
              ),
              Positioned.fill(
                child: ValueListenableBuilder<int>(
                  valueListenable: game.hud,
                  builder: (context, _, __) => _HudStack(game: game, onExit: onExit),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _HudStack extends StatelessWidget {
  const _HudStack({required this.game, required this.onExit});

  final FannyGame game;
  final VoidCallback onExit;

  String _modeInfo() {
    final g = game;
    switch (g.mode) {
      case GameMode.training:
        return 'ТРЕНИРОВКА   комбо x${g.combo}   убито ${g.kills}';
      case GameMode.race:
        final total = g.map.checkpoints.length;
        final cp = math.min(g.nextCheckpoint + 1, total);
        return 'ЧЕКПОИНТ $cp/$total     ${fmtTime(g.elapsed)}';
      case GameMode.arena:
        return '${fmtTime(g.timeLeft)}     ОЧКИ ${g.score}     КОМБО x${g.combo}';
    }
  }

  Widget _bar(double frac, Color color, double width) {
    final f = math.max(0.0, math.min(1.0, frac));
    return Container(
      width: width,
      height: 12,
      decoration: BoxDecoration(
        color: Colors.white12,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Align(
        alignment: Alignment.centerLeft,
        child: FractionallySizedBox(
          widthFactor: f,
          child: Container(
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(6),
            ),
          ),
        ),
      ),
    );
  }

  Widget _panel(String title, String body, List<Widget> buttons) {
    return Container(
      color: Colors.black54,
      child: Center(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
            decoration: BoxDecoration(
              color: const Color(0xFF14232A),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.cyanAccent.withOpacity(0.6), width: 2),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    color: Colors.cyanAccent,
                  ),
                ),
                if (body.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    body,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ],
                const SizedBox(height: 12),
                Row(mainAxisSize: MainAxisSize.min, children: buttons),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _btn(String text, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: ElevatedButton(onPressed: onTap, child: Text(text)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final g = game;
    final showHint = g.phase == GamePhase.playing && g.elapsed < 9 && g.mode != GameMode.arena;

    return Stack(
      children: [
        // энергия + скорость (слева сверху)
        Positioned(
          left: 14,
          top: 8,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text('ЭНЕРГИЯ ', style: TextStyle(fontSize: 11, color: Colors.white70)),
                  _bar(
                    g.energy / FannyGame.maxEnergy,
                    g.energy >= FannyGame.cableCost ? Colors.cyanAccent : Colors.deepOrangeAccent,
                    150,
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'СКОРОСТЬ ${g.speedNow.round()}',
                style: const TextStyle(fontSize: 12, color: Colors.white70),
              ),
            ],
          ),
        ),
        // инфо режима (центр сверху)
        Positioned(
          top: 8,
          left: 0,
          right: 0,
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.black38,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                _modeInfo(),
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
        // пауза
        Positioned(
          right: 8,
          top: 2,
          child: IconButton(
            iconSize: 30,
            color: Colors.white70,
            icon: const Icon(Icons.pause_circle_outline),
            onPressed: () => g.setPaused(true),
          ),
        ),
        // подсказка
        if (showHint)
          const Positioned(
            left: 0,
            right: 0,
            bottom: 6,
            child: Center(
              child: Text(
                'Кнопка ТРОС: тапни или потяни для прицела и отпусти. Тросы по цепочке = скорость.',
                style: TextStyle(fontSize: 12, color: Colors.white54),
              ),
            ),
          ),
        // кнопки скиллов
        Positioned(
          right: 22,
          bottom: 20,
          child: SkillButton(
            key: const ValueKey('cable'),
            size: 104,
            label: 'ТРОС',
            sub: 'скилл 2',
            color: Colors.cyanAccent,
            ready: g.cableReady,
            onAim: (d) => g.aimCable = d,
            onCast: (d) => g.castCable(d),
          ),
        ),
        Positioned(
          right: 150,
          bottom: 14,
          child: SkillButton(
            key: const ValueKey('dash'),
            size: 78,
            label: 'РЫВОК',
            sub: 'x${g.dashCharges}',
            color: Colors.amber,
            ready: g.dashReady,
            onAim: (d) => g.aimDash = d,
            onCast: (d) => g.castDash(d),
          ),
        ),
        // обратный отсчёт
        if (g.phase == GamePhase.countdown)
          Center(
            child: Text(
              g.countdown.ceil().toString(),
              style: const TextStyle(
                fontSize: 96,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
          ),
        // пауза
        if (g.phase == GamePhase.paused)
          Positioned.fill(
            child: _panel('ПАУЗА', '', [
              _btn('ПРОДОЛЖИТЬ', () => g.setPaused(false)),
              _btn('РЕСТАРТ', () {
                g.resetRun();
              }),
              _btn('В МЕНЮ', onExit),
            ]),
          ),
        // результат
        if (g.phase == GamePhase.finished)
          Positioned.fill(
            child: _panel(g.resultTitle, g.resultBody, [
              _btn('ЕЩЁ РАЗ', () {
                g.resetRun();
              }),
              _btn('В МЕНЮ', onExit),
            ]),
          ),
      ],
    );
  }
}

// ===========================================================================
//  Плавающий джойстик (левая половина экрана)
// ===========================================================================
class JoystickArea extends StatefulWidget {
  const JoystickArea({super.key, required this.game});

  final FannyGame game;

  @override
  State<JoystickArea> createState() => _JoystickAreaState();
}

class _JoystickAreaState extends State<JoystickArea> {
  static const double radius = 62;
  int? _ptr;
  Offset? _origin;
  Offset _knob = Offset.zero;

  void _apply(Offset p) {
    var d = p - _origin!;
    final len = d.distance;
    if (len > radius) d = d * (radius / len);
    widget.game.moveInput.setValues(d.dx / radius, d.dy / radius);
    setState(() => _knob = d);
  }

  void _end(PointerEvent e) {
    if (e.pointer != _ptr) return;
    _ptr = null;
    _origin = null;
    widget.game.moveInput.setZero();
    setState(() => _knob = Offset.zero);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final idle = Offset(math.min(120.0, c.maxWidth * 0.5), c.maxHeight - 100);
        return Listener(
          behavior: HitTestBehavior.translucent,
          onPointerDown: (e) {
            if (_ptr != null) return;
            _ptr = e.pointer;
            _origin = e.localPosition;
            _apply(e.localPosition);
          },
          onPointerMove: (e) {
            if (e.pointer == _ptr) _apply(e.localPosition);
          },
          onPointerUp: _end,
          onPointerCancel: _end,
          child: CustomPaint(
            size: Size.infinite,
            painter: _StickPainter(_origin ?? idle, _knob, _ptr != null),
          ),
        );
      },
    );
  }
}

class _StickPainter extends CustomPainter {
  _StickPainter(this.origin, this.knob, this.active);

  final Offset origin;
  final Offset knob;
  final bool active;

  @override
  void paint(Canvas canvas, Size size) {
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..color = Colors.white.withOpacity(active ? 0.45 : 0.2);
    canvas.drawCircle(origin, _JoystickAreaState.radius, base);
    final k = Paint()..color = Colors.white.withOpacity(active ? 0.5 : 0.22);
    canvas.drawCircle(origin + knob, 28, k);
  }

  @override
  bool shouldRepaint(covariant _StickPainter old) =>
      old.origin != origin || old.knob != knob || old.active != active;
}

// ===========================================================================
//  Кнопка скилла: тап = каст в сторону движения, drag = прицел, отпустил = каст
// ===========================================================================
class SkillButton extends StatefulWidget {
  const SkillButton({
    super.key,
    required this.size,
    required this.label,
    required this.sub,
    required this.color,
    required this.ready,
    required this.onAim,
    required this.onCast,
  });

  final double size;
  final String label;
  final String sub;
  final Color color;
  final double ready;
  final ValueChanged<Vector2?> onAim;
  final ValueChanged<Vector2?> onCast;

  @override
  State<SkillButton> createState() => _SkillButtonState();
}

class _SkillButtonState extends State<SkillButton> {
  int? _ptr;
  bool _down = false;
  Vector2? _dir;

  void _move(Offset local) {
    final c = Offset(widget.size / 2, widget.size / 2);
    final d = local - c;
    if (d.distance > widget.size * 0.22) {
      _dir = Vector2(d.dx, d.dy)..normalize();
    } else {
      _dir = null;
    }
    widget.onAim(_dir);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    return Listener(
      onPointerDown: (e) {
        if (_ptr != null) return;
        _ptr = e.pointer;
        setState(() => _down = true);
        _move(e.localPosition);
      },
      onPointerMove: (e) {
        if (e.pointer == _ptr) _move(e.localPosition);
      },
      onPointerUp: (e) {
        if (e.pointer != _ptr) return;
        _ptr = null;
        final d = _dir;
        _dir = null;
        setState(() => _down = false);
        widget.onAim(null);
        widget.onCast(d);
      },
      onPointerCancel: (e) {
        if (e.pointer != _ptr) return;
        _ptr = null;
        _dir = null;
        setState(() => _down = false);
        widget.onAim(null);
      },
      child: Transform.scale(
        scale: _down ? 0.92 : 1.0,
        child: SizedBox(
          width: s,
          height: s,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: s,
                height: s,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.color.withOpacity(_down ? 0.4 : 0.2),
                  border: Border.all(color: widget.color.withOpacity(0.5), width: 3),
                ),
              ),
              SizedBox(
                width: s - 4,
                height: s - 4,
                child: CircularProgressIndicator(
                  value: widget.ready,
                  strokeWidth: 5,
                  color: widget.color,
                  backgroundColor: Colors.transparent,
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    widget.label,
                    style: TextStyle(
                      fontSize: s > 90 ? 20 : 14,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    widget.sub,
                    style: const TextStyle(fontSize: 11, color: Colors.white70),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
