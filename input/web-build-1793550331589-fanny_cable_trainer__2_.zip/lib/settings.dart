import 'package:shared_preferences/shared_preferences.dart';

class Settings {
  static bool sound = true;

  static Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      sound = p.getBool('sound') ?? true;
    } catch (_) {}
  }

  static Future<void> setSound(bool v) async {
    sound = v;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool('sound', v);
    } catch (_) {}
  }
}
