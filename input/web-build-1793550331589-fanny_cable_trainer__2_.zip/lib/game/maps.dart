import 'dart:math' as math;
import 'dart:ui' show Offset, Rect;

import 'package:flame/extensions.dart';
import 'package:flame/game.dart';

enum GameMode { training, race, arena }

/// Круглая колонна (препятствие).
class Pillar {
  const Pillar(this.x, this.y, this.r);
  final double x;
  final double y;
  final double r;
}

class MapData {
  MapData({
    required this.name,
    required this.width,
    required this.height,
    required this.rects,
    required this.pillars,
    required this.spawn,
    List<Vector2>? checkpoints,
  }) : checkpoints = checkpoints ?? <Vector2>[];

  final String name;
  final double width;
  final double height;
  final List<Rect> rects;
  final List<Pillar> pillars;
  final Vector2 spawn;
  final List<Vector2> checkpoints;
}

MapData buildMap(GameMode mode) {
  switch (mode) {
    case GameMode.training:
      return _training();
    case GameMode.race:
      return _race();
    case GameMode.arena:
      return _arena();
  }
}

List<Rect> _border(double w, double h) {
  const t = 300.0;
  return <Rect>[
    Rect.fromLTWH(-t, -t, w + 2 * t, t),
    Rect.fromLTWH(-t, h, w + 2 * t, t),
    Rect.fromLTWH(-t, 0, t, h),
    Rect.fromLTWH(w, 0, t, h),
  ];
}

/// Режим 1: свободная тренировка. Большая "лесная" поляна со стенами и колоннами.
MapData _training() {
  const w = 3400.0;
  const h = 2200.0;
  final rng = math.Random(21);
  final rects = _border(w, h);
  final pillars = <Pillar>[];
  final boxes = <Rect>[];
  final spawnZone = Rect.fromCenter(
    center: const Offset(w / 2, h / 2),
    width: 560,
    height: 560,
  );

  var tries = 0;
  while (boxes.length < 30 && tries < 4000) {
    tries++;
    if (rng.nextDouble() < 0.4) {
      final r = 45 + rng.nextDouble() * 70;
      final x = 200 + r + rng.nextDouble() * (w - 400 - 2 * r);
      final y = 200 + r + rng.nextDouble() * (h - 400 - 2 * r);
      final bb = Rect.fromCircle(center: Offset(x, y), radius: r + 100);
      if (bb.overlaps(spawnZone) || boxes.any((b) => b.overlaps(bb))) continue;
      boxes.add(bb);
      pillars.add(Pillar(x, y, r));
    } else {
      final bw = 120 + rng.nextDouble() * 260;
      final bh = 100 + rng.nextDouble() * 220;
      final x = 180 + rng.nextDouble() * (w - 360 - bw);
      final y = 180 + rng.nextDouble() * (h - 360 - bh);
      final bb = Rect.fromLTWH(x - 100, y - 100, bw + 200, bh + 200);
      if (bb.overlaps(spawnZone) || boxes.any((b) => b.overlaps(bb))) continue;
      boxes.add(bb);
      rects.add(Rect.fromLTWH(x, y, bw, bh));
    }
  }

  return MapData(
    name: 'Лесная поляна',
    width: w,
    height: h,
    rects: rects,
    pillars: pillars,
    spawn: Vector2(w / 2, h / 2),
  );
}

/// Режим 2: гонка по чекпоинтам. Лабиринт, который генерируется из фиксированного seed.
MapData _race() {
  const cols = 8;
  const rows = 5;
  const tile = 200.0;
  const gw = cols * 2 + 1;
  const gh = rows * 2 + 1;

  final grid = List.generate(gh, (_) => List<bool>.filled(gw, true)); // true = стена
  final rng = math.Random(7);
  final visited = List.generate(rows, (_) => List<bool>.filled(cols, false));
  const dirs = <List<int>>[
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
  ];

  final stack = <List<int>>[
    [0, 0],
  ];
  visited[0][0] = true;
  grid[1][1] = false;
  while (stack.isNotEmpty) {
    final cur = stack.last;
    final cx = cur[0];
    final cy = cur[1];
    final nbrs = <List<int>>[];
    for (final d in dirs) {
      final nx = cx + d[0];
      final ny = cy + d[1];
      if (nx < 0 || ny < 0 || nx >= cols || ny >= rows || visited[ny][nx]) {
        continue;
      }
      nbrs.add([nx, ny]);
    }
    if (nbrs.isEmpty) {
      stack.removeLast();
      continue;
    }
    final n = nbrs[rng.nextInt(nbrs.length)];
    visited[n[1]][n[0]] = true;
    grid[n[1] * 2 + 1][n[0] * 2 + 1] = false;
    grid[cy + n[1] + 1][cx + n[0] + 1] = false;
    stack.add(n);
  }

  // Ломаем часть стен, чтобы появились петли и обходы для тросов.
  for (var y = 1; y < gh - 1; y++) {
    for (var x = 1; x < gw - 1; x++) {
      final between = (x.isOdd && y.isEven) || (x.isEven && y.isOdd);
      if (between && grid[y][x] && rng.nextDouble() < 0.24) {
        grid[y][x] = false;
      }
    }
  }

  // BFS от старта, чтобы расставить чекпоинты по возрастанию расстояния.
  final dist = List.generate(gh, (_) => List<int>.filled(gw, -1));
  final q = <List<int>>[
    [1, 1],
  ];
  dist[1][1] = 0;
  var head = 0;
  while (head < q.length) {
    final c = q[head++];
    for (final d in dirs) {
      final nx = c[0] + d[0];
      final ny = c[1] + d[1];
      if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
      if (grid[ny][nx] || dist[ny][nx] >= 0) continue;
      dist[ny][nx] = dist[c[1]][c[0]] + 1;
      q.add([nx, ny]);
    }
  }

  final cells = <List<int>>[];
  for (var cy = 0; cy < rows; cy++) {
    for (var cx = 0; cx < cols; cx++) {
      cells.add([cx * 2 + 1, cy * 2 + 1]);
    }
  }
  cells.sort((a, b) => dist[a[1]][a[0]].compareTo(dist[b[1]][b[0]]));

  const count = 8;
  final cps = <Vector2>[];
  final used = <int>{};
  for (var i = 1; i <= count; i++) {
    var idx = ((cells.length - 1) * i / count).round();
    while (used.contains(idx) && idx < cells.length - 1) {
      idx++;
    }
    used.add(idx);
    final c = cells[idx];
    cps.add(Vector2((c[0] + 0.5) * tile, (c[1] + 0.5) * tile));
  }

  final rects = <Rect>[];
  for (var y = 0; y < gh; y++) {
    var x = 0;
    while (x < gw) {
      if (!grid[y][x]) {
        x++;
        continue;
      }
      var x2 = x;
      while (x2 < gw && grid[y][x2]) {
        x2++;
      }
      rects.add(Rect.fromLTWH(x * tile, y * tile, (x2 - x) * tile, tile));
      x = x2;
    }
  }

  return MapData(
    name: 'Лабиринт',
    width: gw * tile,
    height: gh * tile,
    rects: rects,
    pillars: <Pillar>[],
    spawn: Vector2(1.5 * tile, 1.5 * tile),
    checkpoints: cps,
  );
}

/// Режим 3: арена "Колизей" с кольцами колонн. Охота на манекены.
MapData _arena() {
  const w = 2800.0;
  const h = 2800.0;
  const cx = w / 2;
  const cy = h / 2;
  final rects = _border(w, h);
  final pillars = <Pillar>[];

  for (var i = 0; i < 8; i++) {
    final a = i * math.pi / 4 + math.pi / 8;
    pillars.add(Pillar(cx + math.cos(a) * 520, cy + math.sin(a) * 520, 70));
  }
  for (var i = 0; i < 12; i++) {
    final a = i * math.pi / 6;
    pillars.add(Pillar(cx + math.cos(a) * 1020, cy + math.sin(a) * 1020, 58));
  }

  const s = 260.0;
  const m = 260.0;
  rects.add(Rect.fromLTWH(m, m, s, s));
  rects.add(Rect.fromLTWH(w - m - s, m, s, s));
  rects.add(Rect.fromLTWH(m, h - m - s, s, s));
  rects.add(Rect.fromLTWH(w - m - s, h - m - s, s, s));

  rects.add(Rect.fromCenter(center: const Offset(cx + 760, cy), width: 120, height: 300));
  rects.add(Rect.fromCenter(center: const Offset(cx - 760, cy), width: 120, height: 300));
  rects.add(Rect.fromCenter(center: const Offset(cx, cy + 760), width: 300, height: 120));
  rects.add(Rect.fromCenter(center: const Offset(cx, cy - 760), width: 300, height: 120));

  return MapData(
    name: 'Колизей',
    width: w,
    height: h,
    rects: rects,
    pillars: pillars,
    spawn: Vector2(cx, cy),
  );
}
