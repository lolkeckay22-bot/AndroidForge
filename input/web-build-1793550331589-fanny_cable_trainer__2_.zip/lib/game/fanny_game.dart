import 'dart:math' as math;

import 'package:flame/components.dart';
import 'package:flame/extensions.dart';
import 'package:flame/game.dart';
import 'package:flame_audio/flame_audio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../settings.dart';
import 'maps.dart';

enum GamePhase { countdown, playing, paused, finished }

enum CableState { none, flying, attached, missed }

class WallHit {
  const WallHit(this.t, this.nx, this.ny);
  final double t;
  final double nx;
  final double ny;
}

class Dummy {
  Dummy(this.pos, this.maxHp) : hp = maxHp;
  final Vector2 pos;
  final Vector2 vel = Vector2.zero();
  final Vector2 knock = Vector2.zero();
  final double maxHp;
  double hp;
  final double r = 26;
  double flash = 0;
  double wanderT = 0;
  double ramCd = 0;
  double respawn = 0;
  int lastDashId = -1;
  bool dead = false;
}

class Fx {
  Fx(this.pos, double l, {this.text, this.color = Colors.white, this.ring = false})
      : life = l,
        maxLife = l;
  final Vector2 pos;
  double life;
  final double maxLife;
  final String? text;
  final Color color;
  final bool ring;
}

String fmtTime(double s) {
  final m = s ~/ 60;
  final sec = s - m * 60;
  return '${m.toString().padLeft(2, '0')}:${sec.toStringAsFixed(1).padLeft(4, '0')}';
}

Offset _o(Vector2 v) => Offset(v.x, v.y);

class FannyGame extends FlameGame {
  FannyGame({required this.mode});

  final GameMode mode;
  late final MapData map = buildMap(mode);
  final math.Random _rng = math.Random();
  final ValueNotifier<int> hud = ValueNotifier<int>(0);
  bool _ready = false;

  // ---- константы (подгоняй под свой вкус) ----
  static const double playerR = 18;
  static const double walkSpeed = 270;
  static const double maxEnergy = 100;
  static const double cableCost = 16;
  static const double energyRegen = 13;
  static const double cableRange = 560;
  static const double cableSpeed = 3600;
  static const double pullAccel = 5200;
  static const double pullMax = 1300;
  static const double dashSpeed = 1650;
  static const double dashDuration = 0.2;
  static const int maxDash = 2;
  static const double dashRechargeTime = 4.0;
  static const double arenaDuration = 90;
  static const double checkpointRadius = 75;

  // ---- ввод ----
  final Vector2 moveInput = Vector2.zero();
  Vector2? aimCable;
  Vector2? aimDash;

  // ---- состояние раунда ----
  GamePhase phase = GamePhase.countdown;
  double countdown = 3;
  int _lastCountInt = 4;
  double elapsed = 0;
  double timeLeft = arenaDuration;
  int score = 0;
  int kills = 0;
  int combo = 0;
  int bestCombo = 0;
  double comboTimer = 0;
  double maxSpeed = 0;
  int cablesUsed = 0;
  int nextCheckpoint = 0;
  String resultTitle = '';
  String resultBody = '';
  bool newRecord = false;
  double? bestRace;
  int? bestArena;

  // ---- игрок ----
  final Vector2 pos = Vector2.zero();
  final Vector2 vel = Vector2.zero();
  final Vector2 facing = Vector2(1, 0);
  double energy = maxEnergy;
  int dashCharges = maxDash;
  double dashRecharge = 0;
  double dashTime = 0;
  double dashCd = 0;
  int dashId = 0;
  final Vector2 dashDir = Vector2(1, 0);

  // ---- трос ----
  CableState cableState = CableState.none;
  final Vector2 cableOrigin = Vector2.zero();
  final Vector2 cableDir = Vector2(1, 0);
  double cableLen = 0;
  double cableTip = 0;
  bool cableHasHit = false;
  double _hitNx = 0;
  double _hitNy = 0;
  final Vector2 cableAnchor = Vector2.zero();
  double cableCd = 0;
  double cableTime = 0;
  double _missTimer = 0;
  double _wallSfxCd = 0;

  // ---- прочее ----
  final List<Dummy> dummies = <Dummy>[];
  final List<Fx> fx = <Fx>[];
  final List<Vector2> trail = <Vector2>[];
  double _trailTimer = 0;
  final Vector2 _cam = Vector2.zero();
  double _zoomH = 640;

  double get speedNow => vel.length;
  double get cableReady => math.min(1.0, energy / cableCost);
  double get dashReady =>
      dashCharges > 0 ? 1.0 : math.max(0.0, 1.0 - dashRecharge / dashRechargeTime);
  bool get movingDummies => mode == GameMode.arena;

  @override
  Future<void> onLoad() async {
    world.add(GameLayer(this));
    try {
      await FlameAudio.audioCache.loadAll(<String>[
        'cable.wav',
        'anchor.wav',
        'dash.wav',
        'hit.wav',
        'kill.wav',
        'checkpoint.wav',
        'finish.wav',
        'empty.wav',
        'thud.wav',
        'beep.wav',
        'go.wav',
      ]);
    } catch (_) {}
    await _loadBest();
    resetRun();
    _ready = true;
  }

  Future<void> _loadBest() async {
    try {
      final p = await SharedPreferences.getInstance();
      bestRace = p.getDouble('best_race');
      bestArena = p.getInt('best_arena');
    } catch (_) {}
  }

  Future<void> _saveRace(double t) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setDouble('best_race', t);
    } catch (_) {}
  }

  Future<void> _saveArena(int s) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('best_arena', s);
    } catch (_) {}
  }

  Future<void> _sfx(String name, [double volume = 0.7]) async {
    if (!Settings.sound) return;
    try {
      await FlameAudio.play(name, volume: volume);
    } catch (_) {}
  }

  // ======================================================================
  //  Сброс / пауза
  // ======================================================================
  void resetRun() {
    pos.setFrom(map.spawn);
    vel.setZero();
    facing.setValues(1, 0);
    energy = maxEnergy;
    dashCharges = maxDash;
    dashRecharge = 0;
    dashTime = 0;
    dashCd = 0;
    dashId = 0;
    cableState = CableState.none;
    cableCd = 0;
    aimCable = null;
    aimDash = null;
    fx.clear();
    trail.clear();
    score = 0;
    kills = 0;
    combo = 0;
    bestCombo = 0;
    comboTimer = 0;
    maxSpeed = 0;
    cablesUsed = 0;
    nextCheckpoint = 0;
    elapsed = 0;
    timeLeft = arenaDuration;
    newRecord = false;
    resultTitle = '';
    resultBody = '';
    dummies.clear();
    if (mode == GameMode.training) {
      for (var i = 0; i < 5; i++) {
        dummies.add(Dummy(_randomFreePoint(26, 250, 1100), 500));
      }
    } else if (mode == GameMode.arena) {
      for (var i = 0; i < 7; i++) {
        dummies.add(Dummy(_randomFreePoint(26, 350, 1800), 420));
      }
    }
    if (mode == GameMode.training) {
      phase = GamePhase.playing;
    } else {
      phase = GamePhase.countdown;
      countdown = 3;
      _lastCountInt = 4;
    }
    _cam.setFrom(pos);
    camera.viewfinder.position = _cam.clone();
  }

  void setPaused(bool p) {
    if (p && phase == GamePhase.playing) {
      phase = GamePhase.paused;
      moveInput.setZero();
      aimCable = null;
      aimDash = null;
    } else if (!p && phase == GamePhase.paused) {
      phase = GamePhase.playing;
    }
  }

  // ======================================================================
  //  Главный цикл
  // ======================================================================
  @override
  void update(double dt) {
    super.update(dt);
    if (!_ready) return;
    dt = math.min(dt, 1 / 30);
    _updateFx(dt);

    if (phase == GamePhase.countdown) {
      countdown -= dt;
      final ci = countdown.ceil();
      if (ci != _lastCountInt && ci > 0) {
        _lastCountInt = ci;
        _sfx('beep.wav', 0.5);
      }
      if (countdown <= 0) {
        phase = GamePhase.playing;
        _sfx('go.wav', 0.6);
      }
    } else if (phase == GamePhase.playing) {
      _step(dt);
    }

    _updateCamera(dt);
    hud.value++;
  }

  void _step(double dt) {
    elapsed += dt;
    _stepSkills(dt);
    _stepCable(dt);
    _stepMovement(dt);
    _integrate(dt);
    _stepDummies(dt);
    _stepTrail(dt);
    maxSpeed = math.max(maxSpeed, vel.length);
    _stepModeLogic(dt);
  }

  void _stepSkills(double dt) {
    energy = math.min(maxEnergy, energy + energyRegen * dt);
    if (cableCd > 0) cableCd -= dt;
    if (dashCd > 0) dashCd -= dt;
    if (_wallSfxCd > 0) _wallSfxCd -= dt;
    if (dashCharges < maxDash) {
      dashRecharge -= dt;
      if (dashRecharge <= 0) {
        dashCharges++;
        dashRecharge = dashCharges < maxDash ? dashRechargeTime : 0;
      }
    }
    if (comboTimer > 0) {
      comboTimer -= dt;
      if (comboTimer <= 0) combo = 0;
    }
  }

  Vector2 _inputVec() {
    final l = moveInput.length;
    if (l < 0.15) return Vector2.zero();
    return moveInput * (math.min(1.0, l) / l);
  }

  Vector2 _defaultAim() {
    final i = _inputVec();
    if (i.length2 > 0.01) return i.normalized();
    return facing.clone();
  }

  // ----------------------------------------------------------------------
  //  Трос (2-й скилл Фанни)
  // ----------------------------------------------------------------------
  void castCable(Vector2? dir) {
    if (phase != GamePhase.playing) return;
    if (cableCd > 0) return;
    if (energy < cableCost) {
      _sfx('empty.wav', 0.5);
      fx.add(Fx(pos.clone(), 0.8, text: 'Нет энергии', color: Colors.orangeAccent));
      return;
    }
    final d = dir != null ? dir.normalized() : _defaultAim();
    energy -= cableCost;
    cableCd = 0.22;
    cablesUsed++;
    dashTime = 0;
    cableOrigin.setFrom(pos);
    cableDir.setFrom(d);
    facing.setFrom(d);
    final hit = raycast(pos, d, cableRange);
    cableHasHit = hit != null;
    cableLen = hit?.t ?? cableRange;
    _hitNx = hit?.nx ?? 0;
    _hitNy = hit?.ny ?? 0;
    cableTip = 0;
    cableState = CableState.flying;
    _sfx('cable.wav', 0.55);
  }

  void _detach() {
    cableState = CableState.none;
  }

  void _stepCable(double dt) {
    if (cableState == CableState.flying) {
      cableTip += cableSpeed * dt;
      if (cableTip >= cableLen) {
        if (cableHasHit) {
          cableAnchor
            ..setFrom(cableOrigin)
            ..addScaled(cableDir, cableLen)
            ..x += _hitNx * 0.6
            ..y += _hitNy * 0.6;
          cableState = CableState.attached;
          cableTime = 0;
          final toA = cableAnchor - pos;
          if (toA.length2 > 1) {
            vel.addScaled(toA.normalized(), 350);
          }
          fx.add(Fx(cableAnchor.clone(), 0.4, ring: true, color: Colors.cyanAccent));
          _sfx('anchor.wav', 0.6);
        } else {
          cableState = CableState.missed;
          _missTimer = 0.12;
        }
      }
    } else if (cableState == CableState.missed) {
      _missTimer -= dt;
      if (_missTimer <= 0) cableState = CableState.none;
    } else if (cableState == CableState.attached) {
      cableTime += dt;
      final toA = cableAnchor - pos;
      final dist = toA.length;
      if (cableTime > 1.6) {
        _detach();
        return;
      }
      if (dist < playerR + 10) {
        _detach(); // прилетели к стене, инерция остаётся
        return;
      }
      final dir = toA / dist;
      final block = raycast(pos, dir, dist - 2);
      if (block != null) {
        _detach(); // трос перерезан препятствием
        fx.add(Fx(pos.clone(), 0.6, text: 'Трос обрезан', color: Colors.white70));
        return;
      }
      vel.addScaled(dir, pullAccel * dt);
      final sp = vel.length;
      if (sp > pullMax) vel.scale(pullMax / sp);
      // гасим боковую составляющую, чтобы полёт выпрямлялся, но оставался слинг-эффект
      final along = vel.dot(dir);
      final vn = dir * along;
      final vt = vel - vn;
      final damp = math.exp(-2.6 * dt);
      vel
        ..setFrom(vn)
        ..addScaled(vt, damp);
      final inp = _inputVec();
      vel.addScaled(inp, 380 * dt);
      facing.setFrom(dir);
    }
  }

  // ----------------------------------------------------------------------
  //  Торнадо (1-й скилл Фанни, рывок)
  // ----------------------------------------------------------------------
  void castDash(Vector2? dir) {
    if (phase != GamePhase.playing) return;
    if (dashCharges <= 0 || dashCd > 0) return;
    final d = dir != null ? dir.normalized() : _defaultAim();
    if (dashCharges == maxDash) dashRecharge = dashRechargeTime;
    dashCharges--;
    dashCd = 0.3;
    dashTime = dashDuration;
    dashDir.setFrom(d);
    facing.setFrom(d);
    dashId++;
    _detach();
    _sfx('dash.wav', 0.6);
  }

  // ----------------------------------------------------------------------
  //  Движение
  // ----------------------------------------------------------------------
  void _stepMovement(double dt) {
    if (cableState == CableState.attached) return;
    if (dashTime > 0) {
      vel.setFrom(dashDir * dashSpeed);
      dashTime -= dt;
      if (dashTime <= 0) {
        vel.setFrom(dashDir * 560);
      }
      return;
    }
    final inp = _inputVec();
    if (inp.length2 > 0) {
      facing.setFrom(inp.normalized());
    }
    final spd = vel.length;
    if (spd > walkSpeed * 1.05) {
      // инерция после троса/рывка: плавно затухает до скорости ходьбы
      final newSpd = walkSpeed + (spd - walkSpeed) * math.exp(-1.6 * dt);
      vel.scale(newSpd / spd);
      vel.addScaled(inp, 700 * dt);
    } else {
      final desired = inp * walkSpeed;
      final diff = desired - vel;
      final dl = diff.length;
      final maxD = (inp.length2 > 0 ? 3200 : 2600) * dt;
      if (dl <= maxD) {
        vel.setFrom(desired);
      } else {
        vel.addScaled(diff, maxD / dl);
      }
    }
  }

  void _integrate(double dt) {
    final speed = vel.length;
    final steps = math.max(1, (speed * dt / 10).ceil());
    final sdt = dt / steps;
    for (var i = 0; i < steps; i++) {
      pos.addScaled(vel, sdt);
      _pushOut(pos, playerR, vel, onHit: _onWallHit);
    }
  }

  void _onWallHit(double impact) {
    if (impact > 450 && _wallSfxCd <= 0) {
      _wallSfxCd = 0.25;
      _sfx('thud.wav', math.min(0.8, impact / 1400));
      fx.add(Fx(pos.clone() + facing * playerR, 0.3, ring: true, color: Colors.white54));
    }
  }

  void _stepTrail(double dt) {
    _trailTimer -= dt;
    if (_trailTimer > 0) return;
    _trailTimer = 0.025;
    if (vel.length > 450) {
      trail.add(pos.clone());
      if (trail.length > 14) trail.removeAt(0);
    } else if (trail.isNotEmpty) {
      trail.removeAt(0);
    }
  }

  // ----------------------------------------------------------------------
  //  Манекены
  // ----------------------------------------------------------------------
  void _stepDummies(double dt) {
    for (final d in dummies) {
      if (d.dead) {
        d.respawn -= dt;
        if (d.respawn <= 0) _respawnDummy(d);
        continue;
      }
      d.flash = math.max(0, d.flash - dt * 4);
      d.ramCd -= dt;
      d.knock.scale(math.exp(-6 * dt));

      if (movingDummies) {
        d.wanderT -= dt;
        if (d.wanderT <= 0) {
          final a = _rng.nextDouble() * math.pi * 2;
          final s = 60 + _rng.nextDouble() * 60;
          d.vel.setValues(math.cos(a) * s, math.sin(a) * s);
          d.wanderT = 1.2 + _rng.nextDouble() * 2.0;
        }
      }
      d.pos.addScaled(d.vel + d.knock, dt);
      if (_pushOut(d.pos, d.r, null)) {
        d.wanderT = 0;
        d.vel.scale(-1);
      }

      final dist = d.pos.distanceTo(pos);
      if (dist < d.r + playerR + 6) {
        if (dashTime > 0 && d.lastDashId != dashId) {
          d.lastDashId = dashId;
          _hitDummy(d, 160);
        } else if (vel.length > 750 && d.ramCd <= 0) {
          d.ramCd = 0.5;
          _hitDummy(d, 90);
        }
      }
    }
  }

  void _hitDummy(Dummy d, double dmg) {
    d.hp -= dmg;
    d.flash = 1;
    combo++;
    comboTimer = 3;
    bestCombo = math.max(bestCombo, combo);
    energy = math.min(maxEnergy, energy + 8);
    final away = d.pos - pos;
    if (away.length2 > 1) d.knock.addScaled(away.normalized(), 380);
    fx.add(Fx(d.pos.clone(), 0.7, text: '-${dmg.round()}', color: Colors.amberAccent));
    if (d.hp <= 0) {
      d.dead = true;
      d.respawn = mode == GameMode.arena ? 1.2 : 2.5;
      kills++;
      score += 100 + 25 * math.min(combo, 10);
      fx.add(Fx(d.pos.clone(), 0.6, ring: true, color: Colors.redAccent));
      fx.add(Fx(d.pos.clone() + Vector2(0, -30), 0.9, text: 'УБИТ!', color: Colors.redAccent));
      _sfx('kill.wav', 0.7);
    } else {
      _sfx('hit.wav', 0.6);
    }
  }

  void _respawnDummy(Dummy d) {
    final p = _randomFreePoint(d.r, 350, 1800);
    d.pos.setFrom(p);
    d.hp = d.maxHp;
    d.dead = false;
    d.knock.setZero();
    d.vel.setZero();
    d.lastDashId = -1;
  }

  // ----------------------------------------------------------------------
  //  Логика режимов
  // ----------------------------------------------------------------------
  void _stepModeLogic(double dt) {
    if (mode == GameMode.race) {
      if (nextCheckpoint < map.checkpoints.length) {
        final cp = map.checkpoints[nextCheckpoint];
        if (pos.distanceTo(cp) < checkpointRadius + playerR) {
          nextCheckpoint++;
          fx.add(Fx(cp.clone(), 0.6, ring: true, color: Colors.amberAccent));
          if (nextCheckpoint >= map.checkpoints.length) {
            _finishRace();
          } else {
            _sfx('checkpoint.wav', 0.7);
          }
        }
      }
    } else if (mode == GameMode.arena) {
      timeLeft -= dt;
      if (timeLeft <= 0) {
        timeLeft = 0;
        _finishArena();
      }
    }
  }

  void _finishRace() {
    phase = GamePhase.finished;
    moveInput.setZero();
    final t = elapsed;
    newRecord = bestRace == null || t < bestRace!;
    if (newRecord) {
      bestRace = t;
      _saveRace(t);
    }
    resultTitle = newRecord ? 'НОВЫЙ РЕКОРД!' : 'ФИНИШ!';
    resultBody = 'Время: ${fmtTime(t)}\n'
        'Лучшее: ${fmtTime(bestRace!)}\n'
        'Тросов выпущено: $cablesUsed\n'
        'Макс. скорость: ${maxSpeed.round()}';
    _sfx('finish.wav', 0.8);
  }

  void _finishArena() {
    phase = GamePhase.finished;
    moveInput.setZero();
    newRecord = bestArena == null || score > bestArena!;
    if (newRecord) {
      bestArena = score;
      _saveArena(score);
    }
    resultTitle = newRecord ? 'НОВЫЙ РЕКОРД!' : 'ВРЕМЯ ВЫШЛО';
    resultBody = 'Очки: $score\n'
        'Убито: $kills\n'
        'Лучшее комбо: x$bestCombo\n'
        'Рекорд: ${bestArena ?? 0}';
    _sfx('finish.wav', 0.8);
  }

  // ----------------------------------------------------------------------
  //  Камера и эффекты
  // ----------------------------------------------------------------------
  void _updateCamera(double dt) {
    if (size.y <= 0) return;
    final target = pos + vel * 0.18;
    final k = math.min(1.0, dt * 7);
    _cam.x += (target.x - _cam.x) * k;
    _cam.y += (target.y - _cam.y) * k;
    camera.viewfinder.position = _cam.clone();
    final desiredH = 620 + math.min(vel.length, 1300) * 0.12;
    _zoomH += (desiredH - _zoomH) * math.min(1.0, dt * 3);
    camera.viewfinder.zoom = size.y / _zoomH;
  }

  void _updateFx(double dt) {
    for (final f in fx) {
      f.life -= dt;
      if (f.text != null) f.pos.y -= 40 * dt;
    }
    fx.removeWhere((f) => f.life <= 0);
  }

  // ======================================================================
  //  Геометрия
  // ======================================================================
  WallHit? raycast(Vector2 o, Vector2 d, double maxT) {
    var bestT = maxT;
    double bnx = 0;
    double bny = 0;
    var found = false;

    for (final r in map.rects) {
      var tNear = double.negativeInfinity;
      var tFar = double.infinity;
      var nx = 0.0;
      var ny = 0.0;
      var miss = false;

      if (d.x.abs() < 1e-9) {
        if (o.x < r.left || o.x > r.right) miss = true;
      } else {
        var t1 = (r.left - o.x) / d.x;
        var t2 = (r.right - o.x) / d.x;
        var n = -1.0;
        if (t1 > t2) {
          final tmp = t1;
          t1 = t2;
          t2 = tmp;
          n = 1.0;
        }
        if (t1 > tNear) {
          tNear = t1;
          nx = n;
          ny = 0;
        }
        if (t2 < tFar) tFar = t2;
      }
      if (miss) continue;

      if (d.y.abs() < 1e-9) {
        if (o.y < r.top || o.y > r.bottom) continue;
      } else {
        var t1 = (r.top - o.y) / d.y;
        var t2 = (r.bottom - o.y) / d.y;
        var n = -1.0;
        if (t1 > t2) {
          final tmp = t1;
          t1 = t2;
          t2 = tmp;
          n = 1.0;
        }
        if (t1 > tNear) {
          tNear = t1;
          nx = 0;
          ny = n;
        }
        if (t2 < tFar) tFar = t2;
      }

      if (tNear > tFar || tFar < 0 || tNear < 0) continue;
      if (tNear < bestT) {
        bestT = tNear;
        bnx = nx;
        bny = ny;
        found = true;
      }
    }

    for (final p in map.pillars) {
      final mx = o.x - p.x;
      final my = o.y - p.y;
      final b = mx * d.x + my * d.y;
      final c = mx * mx + my * my - p.r * p.r;
      if (c > 0 && b > 0) continue;
      final disc = b * b - c;
      if (disc < 0) continue;
      final t = -b - math.sqrt(disc);
      if (t < 0 || t >= bestT) continue;
      bestT = t;
      final hx = o.x + d.x * t - p.x;
      final hy = o.y + d.y * t - p.y;
      final hl = math.sqrt(hx * hx + hy * hy);
      bnx = hx / hl;
      bny = hy / hl;
      found = true;
    }

    if (!found) return null;
    return WallHit(bestT, bnx, bny);
  }

  /// Выталкивает круг из стен. Если передан [v] — гасит скорость вдоль нормали.
  bool _pushOut(Vector2 p, double r, Vector2? v, {void Function(double impact)? onHit}) {
    var hit = false;
    for (var pass = 0; pass < 2; pass++) {
      for (final rc in map.rects) {
        if (p.x < rc.left - r || p.x > rc.right + r || p.y < rc.top - r || p.y > rc.bottom + r) {
          continue;
        }
        final cx = math.max(rc.left, math.min(rc.right, p.x));
        final cy = math.max(rc.top, math.min(rc.bottom, p.y));
        final dx = p.x - cx;
        final dy = p.y - cy;
        final d2 = dx * dx + dy * dy;
        if (d2 >= r * r) continue;
        double nx;
        double ny;
        double pen;
        if (d2 > 1e-9) {
          final dd = math.sqrt(d2);
          nx = dx / dd;
          ny = dy / dd;
          pen = r - dd;
        } else {
          final l = p.x - rc.left;
          final rr = rc.right - p.x;
          final t = p.y - rc.top;
          final b = rc.bottom - p.y;
          final m = math.min(math.min(l, rr), math.min(t, b));
          if (m == l) {
            nx = -1;
            ny = 0;
          } else if (m == rr) {
            nx = 1;
            ny = 0;
          } else if (m == t) {
            nx = 0;
            ny = -1;
          } else {
            nx = 0;
            ny = 1;
          }
          pen = m + r;
        }
        p.x += nx * pen;
        p.y += ny * pen;
        hit = true;
        if (v != null) {
          final vn = v.x * nx + v.y * ny;
          if (vn < 0) {
            v.x -= vn * nx;
            v.y -= vn * ny;
            onHit?.call(-vn);
          }
        }
      }
      for (final pl in map.pillars) {
        final dx = p.x - pl.x;
        final dy = p.y - pl.y;
        final minD = r + pl.r;
        final d2 = dx * dx + dy * dy;
        if (d2 >= minD * minD) continue;
        final dd = math.sqrt(d2);
        double nx = 1;
        double ny = 0;
        if (dd > 1e-6) {
          nx = dx / dd;
          ny = dy / dd;
        }
        final pen = minD - dd;
        p.x += nx * pen;
        p.y += ny * pen;
        hit = true;
        if (v != null) {
          final vn = v.x * nx + v.y * ny;
          if (vn < 0) {
            v.x -= vn * nx;
            v.y -= vn * ny;
            onHit?.call(-vn);
          }
        }
      }
    }
    return hit;
  }

  bool _circleBlocked(Vector2 p, double r) {
    for (final rc in map.rects) {
      final cx = math.max(rc.left, math.min(rc.right, p.x));
      final cy = math.max(rc.top, math.min(rc.bottom, p.y));
      final dx = p.x - cx;
      final dy = p.y - cy;
      if (dx * dx + dy * dy < r * r) return true;
    }
    for (final pl in map.pillars) {
      final dx = p.x - pl.x;
      final dy = p.y - pl.y;
      final m = r + pl.r;
      if (dx * dx + dy * dy < m * m) return true;
    }
    return false;
  }

  Vector2 _randomFreePoint(double r, double minD, double maxD) {
    for (var i = 0; i < 300; i++) {
      final p = Vector2(
        150 + _rng.nextDouble() * (map.width - 300),
        150 + _rng.nextDouble() * (map.height - 300),
      );
      final d = p.distanceTo(map.spawn);
      if (d < minD || d > maxD) continue;
      if (_circleBlocked(p, r + 30)) continue;
      return p;
    }
    return map.spawn + Vector2(minD + 60, 0);
  }
}

// ==========================================================================
//  Отрисовка мира
// ==========================================================================
class GameLayer extends Component {
  GameLayer(this.g);
  final FannyGame g;

  final Paint _p = Paint();
  final TextPainter _tp = TextPainter(textDirection: TextDirection.ltr);

  void _text(Canvas c, String s, Offset center, double size, Color color) {
    _tp.text = TextSpan(
      text: s,
      style: TextStyle(color: color, fontSize: size, fontWeight: FontWeight.bold),
    );
    _tp.layout();
    _tp.paint(c, center - Offset(_tp.width / 2, _tp.height / 2));
  }

  @override
  void render(Canvas canvas) {
    final m = g.map;

    // пол
    _p
      ..style = PaintingStyle.fill
      ..color = const Color(0xFF15242A);
    canvas.drawRect(Rect.fromLTWH(0, 0, m.width, m.height), _p);

    // сетка
    _p
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..color = const Color(0x12FFFFFF);
    for (double x = 0; x <= m.width; x += 200) {
      canvas.drawLine(Offset(x, 0), Offset(x, m.height), _p);
    }
    for (double y = 0; y <= m.height; y += 200) {
      canvas.drawLine(Offset(0, y), Offset(m.width, y), _p);
    }

    // стены
    for (final r in m.rects) {
      _p
        ..style = PaintingStyle.fill
        ..color = const Color(0xFF2E4048);
      canvas.drawRect(r, _p);
      _p
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = const Color(0xFF5A7684);
      canvas.drawRect(r.deflate(2), _p);
    }
    for (final pl in m.pillars) {
      _p
        ..style = PaintingStyle.fill
        ..color = const Color(0xFF365060);
      canvas.drawCircle(Offset(pl.x, pl.y), pl.r, _p);
      _p
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = const Color(0xFF6F90A0);
      canvas.drawCircle(Offset(pl.x, pl.y), pl.r - 2, _p);
    }

    _renderCheckpoints(canvas);
    _renderDummies(canvas);
    _renderAimGuides(canvas);
    _renderTrail(canvas);
    _renderCable(canvas);
    _renderPlayer(canvas);
    _renderFx(canvas);
  }

  void _renderCheckpoints(Canvas canvas) {
    if (g.mode != GameMode.race) return;
    final cps = g.map.checkpoints;
    for (var i = g.nextCheckpoint; i < cps.length && i <= g.nextCheckpoint + 1; i++) {
      final active = i == g.nextCheckpoint;
      final c = _o(cps[i]);
      _p
        ..style = PaintingStyle.fill
        ..color = active ? const Color(0x33FFC107) : const Color(0x14FFFFFF);
      canvas.drawCircle(c, FannyGame.checkpointRadius, _p);
      _p
        ..style = PaintingStyle.stroke
        ..strokeWidth = active ? 6 : 3
        ..color = active ? const Color(0xFFFFC107) : const Color(0x55FFFFFF);
      canvas.drawCircle(c, FannyGame.checkpointRadius, _p);
      _text(canvas, i == cps.length - 1 ? 'F' : '${i + 1}', c, 44,
          active ? const Color(0xFFFFC107) : const Color(0x66FFFFFF));
    }
    if (g.nextCheckpoint < cps.length) {
      final to = cps[g.nextCheckpoint] - g.pos;
      if (to.length > 120) {
        final dir = to.normalized();
        final perp = Vector2(-dir.y, dir.x);
        final base = g.pos + dir * 62;
        final tip = base + dir * 16;
        final a = base + perp * 8;
        final b = base - perp * 8;
        final path = Path()
          ..moveTo(tip.x, tip.y)
          ..lineTo(a.x, a.y)
          ..lineTo(b.x, b.y)
          ..close();
        _p
          ..style = PaintingStyle.fill
          ..color = const Color(0xFFFFC107);
        canvas.drawPath(path, _p);
      }
    }
  }

  void _renderDummies(Canvas canvas) {
    for (final d in g.dummies) {
      if (d.dead) continue;
      final c = _o(d.pos);
      _p
        ..style = PaintingStyle.fill
        ..color = Color.lerp(const Color(0xFFE53935), Colors.white, d.flash)!;
      canvas.drawCircle(c, d.r, _p);
      _p
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = const Color(0xFF8E0000);
      canvas.drawCircle(c, d.r, _p);
      // HP-бар
      final frac = math.max(0.0, d.hp / d.maxHp);
      final bar = Rect.fromCenter(center: c + Offset(0, -d.r - 12), width: 54, height: 7);
      _p
        ..style = PaintingStyle.fill
        ..color = const Color(0x88000000);
      canvas.drawRect(bar, _p);
      _p.color = const Color(0xFF66BB6A);
      canvas.drawRect(Rect.fromLTWH(bar.left, bar.top, bar.width * frac, bar.height), _p);
    }
  }

  void _renderAimGuides(Canvas canvas) {
    final ac = g.aimCable;
    if (ac != null) {
      final h = g.raycast(g.pos, ac, FannyGame.cableRange);
      final len = h?.t ?? FannyGame.cableRange;
      final end = g.pos + ac * len;
      _p
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 4
        ..color = h != null ? const Color(0xAA26C6DA) : const Color(0x55FFFFFF);
      canvas.drawLine(_o(g.pos), _o(end), _p);
      if (h != null) {
        canvas.drawCircle(_o(end), 10, _p);
      }
    }
    final ad = g.aimDash;
    if (ad != null) {
      final end = g.pos + ad * (FannyGame.dashSpeed * FannyGame.dashDuration);
      _p
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = FannyGame.playerR * 2
        ..color = const Color(0x44FFB300);
      canvas.drawLine(_o(g.pos), _o(end), _p);
    }
    _p.strokeCap = StrokeCap.butt;
  }

  void _renderTrail(Canvas canvas) {
    final n = g.trail.length;
    for (var i = 0; i < n; i++) {
      final f = (i + 1) / (n + 1);
      _p
        ..style = PaintingStyle.fill
        ..color = Color.fromRGBO(255, 255, 255, 0.28 * f);
      canvas.drawCircle(_o(g.trail[i]), FannyGame.playerR * (0.45 + 0.5 * f), _p);
    }
  }

  void _renderCable(Canvas canvas) {
    Vector2? end;
    var alpha = 1.0;
    switch (g.cableState) {
      case CableState.flying:
        end = g.cableOrigin + g.cableDir * math.min(g.cableTip, g.cableLen);
        break;
      case CableState.attached:
        end = g.cableAnchor;
        break;
      case CableState.missed:
        end = g.cableOrigin + g.cableDir * g.cableLen;
        alpha = 0.5;
        break;
      case CableState.none:
        break;
    }
    if (end == null) return;
    _p
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 7
      ..color = Color.fromRGBO(38, 198, 218, 0.35 * alpha);
    canvas.drawLine(_o(g.pos), _o(end), _p);
    _p
      ..strokeWidth = 2.5
      ..color = Color.fromRGBO(255, 255, 255, alpha);
    canvas.drawLine(_o(g.pos), _o(end), _p);
    _p
      ..style = PaintingStyle.fill
      ..color = Color.fromRGBO(128, 222, 234, alpha);
    canvas.drawCircle(_o(end), 7, _p);
    _p.strokeCap = StrokeCap.butt;
  }

  void _renderPlayer(Canvas canvas) {
    final c = _o(g.pos);
    final dashing = g.dashTime > 0;
    _p
      ..style = PaintingStyle.fill
      ..color = dashing ? const Color(0x55FFB300) : const Color(0x22FFFFFF);
    canvas.drawCircle(c, FannyGame.playerR + 9, _p);
    _p.color = Colors.white;
    canvas.drawCircle(c, FannyGame.playerR, _p);
    _p.color = const Color(0xFF78909C);
    canvas.drawCircle(c + _o(g.facing) * 10, 5, _p);
    // кольцо энергии
    _p
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..color = g.energy >= FannyGame.cableCost
          ? const Color(0xFF26C6DA)
          : const Color(0xFFFF7043);
    final frac = g.energy / FannyGame.maxEnergy;
    canvas.drawArc(
      Rect.fromCircle(center: c, radius: FannyGame.playerR + 6),
      -math.pi / 2,
      math.pi * 2 * frac,
      false,
      _p,
    );
    _p.strokeCap = StrokeCap.butt;
  }

  void _renderFx(Canvas canvas) {
    for (final f in g.fx) {
      final t = 1 - f.life / f.maxLife;
      final a = math.max(0.0, 1 - t);
      if (f.ring) {
        _p
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4
          ..color = f.color.withOpacity(a);
        canvas.drawCircle(_o(f.pos), 10 + 60 * t, _p);
      } else if (f.text != null) {
        _text(canvas, f.text!, _o(f.pos), 22, f.color.withOpacity(a));
      }
    }
  }
}
